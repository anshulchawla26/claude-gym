export default function RichText({ heading, content }: { heading?: string; content: string }) {
  const paragraphs = content.split(/\n\s*\n/).filter(Boolean);

  return (
    <section className="section-spacing">
      <div className="max-w-3xl mx-auto px-6 md:px-8">
        {heading && <h1 className="font-heading-theme uppercase text-4xl md:text-5xl mb-8">{heading}</h1>}
        <div className="text-text-muted space-y-4 leading-relaxed">
          {paragraphs.map((p, i) => (
            <p key={i} className="whitespace-pre-line">
              {p}
            </p>
          ))}
        </div>
      </div>
    </section>
  );
}
