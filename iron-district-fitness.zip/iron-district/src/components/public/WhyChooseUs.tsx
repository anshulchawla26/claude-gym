export interface FeatureCard {
  icon?: string;
  title: string;
  description: string;
}

export default function WhyChooseUs({ data }: { data: { heading?: string; cards: FeatureCard[] } }) {
  const cards = data?.cards || [];
  if (cards.length === 0) return null;

  return (
    <section className="section-spacing bg-surface/40">
      <div className="max-w-container mx-auto px-6 md:px-8">
        {data.heading && (
          <h2 className="font-heading-theme uppercase text-4xl md:text-5xl mb-12 text-center">{data.heading}</h2>
        )}
        <div className="grid md:grid-cols-3 gap-6">
          {cards.map((card, i) => (
            <div key={i} className="card-surface p-8 hover:border-accent transition-colors">
              {card.icon && <div className="text-3xl mb-4">{card.icon}</div>}
              <h3 className="font-heading-theme uppercase text-xl mb-3">{card.title}</h3>
              <p className="text-text-muted leading-relaxed">{card.description}</p>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}
