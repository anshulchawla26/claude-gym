import Link from "next/link";

export default function Footer({
  gymName,
  description,
  navItems,
  phone,
  email,
  address,
  instagram,
  facebook,
  youtube,
  copyrightText
}: {
  gymName: string;
  description: string;
  navItems: { id: string; label: string; url: string }[];
  phone: string;
  email: string;
  address: string;
  instagram?: string | null;
  facebook?: string | null;
  youtube?: string | null;
  copyrightText: string;
}) {
  return (
    <footer className="border-t border-border-base bg-surface/40 pt-16 pb-8">
      <div className="max-w-container mx-auto px-6 md:px-8 grid md:grid-cols-4 gap-10">
        <div>
          <div className="font-heading-theme uppercase text-2xl mb-3">{gymName}</div>
          <p className="text-text-muted text-sm leading-relaxed">{description}</p>
          <div className="flex gap-4 mt-4 text-sm">
            {instagram && (
              <a href={instagram} target="_blank" rel="noopener noreferrer" className="hover:text-accent">
                Instagram
              </a>
            )}
            {facebook && (
              <a href={facebook} target="_blank" rel="noopener noreferrer" className="hover:text-accent">
                Facebook
              </a>
            )}
            {youtube && (
              <a href={youtube} target="_blank" rel="noopener noreferrer" className="hover:text-accent">
                YouTube
              </a>
            )}
          </div>
        </div>

        <div>
          <h4 className="font-heading-theme uppercase mb-3">Navigate</h4>
          <ul className="space-y-2 text-sm text-text-muted">
            {navItems.map((item) => (
              <li key={item.id}>
                <Link href={item.url} className="hover:text-accent">
                  {item.label}
                </Link>
              </li>
            ))}
          </ul>
        </div>

        <div>
          <h4 className="font-heading-theme uppercase mb-3">Contact</h4>
          <ul className="space-y-2 text-sm text-text-muted">
            <li>{address}</li>
            <li>{phone}</li>
            <li>{email}</li>
          </ul>
        </div>

        <div>
          <h4 className="font-heading-theme uppercase mb-3">Legal</h4>
          <ul className="space-y-2 text-sm text-text-muted">
            <li>
              <Link href="/privacy-policy" className="hover:text-accent">
                Privacy Policy
              </Link>
            </li>
            <li>
              <Link href="/terms" className="hover:text-accent">
                Terms &amp; Conditions
              </Link>
            </li>
          </ul>
        </div>
      </div>

      <div className="max-w-container mx-auto px-6 md:px-8 mt-10 pt-6 border-t border-border-base text-xs text-text-muted">
        © {new Date().getFullYear()} {copyrightText}
      </div>
    </footer>
  );
}
