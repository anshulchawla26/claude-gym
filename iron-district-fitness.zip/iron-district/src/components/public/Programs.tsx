import Image from "next/image";
import Link from "next/link";

export interface ProgramItem {
  id: string;
  name: string;
  slug: string;
  shortDesc: string;
  image: string | null;
  icon: string;
  ctaText: string;
  ctaLink: string;
}

export default function Programs({ heading, programs }: { heading?: string; programs: ProgramItem[] }) {
  if (programs.length === 0) return null;

  return (
    <section id="programs" className="section-spacing">
      <div className="max-w-container mx-auto px-6 md:px-8">
        <h2 className="font-heading-theme uppercase text-4xl md:text-5xl mb-12 text-center">
          {heading || "Our Programs"}
        </h2>
        <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-6">
          {programs.map((program) => (
            <Link
              key={program.id}
              href={`/programs/${program.slug}`}
              className="group card-surface overflow-hidden hover:border-accent transition-colors"
            >
              <div className="relative h-56 bg-secondary">
                {program.image && (
                  <Image
                    src={program.image}
                    alt={program.name}
                    fill
                    className="object-cover group-hover:scale-105 transition-transform duration-500"
                  />
                )}
              </div>
              <div className="p-6">
                <div className="text-2xl mb-2">{program.icon}</div>
                <h3 className="font-heading-theme uppercase text-xl mb-2">{program.name}</h3>
                <p className="text-text-muted text-sm leading-relaxed mb-4">{program.shortDesc}</p>
                <span className="text-accent text-sm uppercase tracking-wide">{program.ctaText} →</span>
              </div>
            </Link>
          ))}
        </div>
      </div>
    </section>
  );
}
