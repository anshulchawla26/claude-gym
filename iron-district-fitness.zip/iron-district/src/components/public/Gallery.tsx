"use client";

import { useState } from "react";
import Image from "next/image";

export interface GalleryImageItem {
  id: string;
  image: string;
  caption: string | null;
  category: string;
}

export default function Gallery({ heading, items }: { heading?: string; items: GalleryImageItem[] }) {
  const categories = ["All", ...Array.from(new Set(items.map((i) => i.category)))];
  const [active, setActive] = useState("All");

  if (items.length === 0) return null;

  const filtered = active === "All" ? items : items.filter((i) => i.category === active);

  return (
    <section id="gallery" className="section-spacing bg-surface/40">
      <div className="max-w-container mx-auto px-6 md:px-8">
        <h2 className="font-heading-theme uppercase text-4xl md:text-5xl mb-8 text-center">
          {heading || "Gallery"}
        </h2>

        {categories.length > 2 && (
          <div className="flex justify-center gap-3 mb-8 flex-wrap">
            {categories.map((c) => (
              <button
                key={c}
                onClick={() => setActive(c)}
                className={`px-4 py-2 text-sm uppercase rounded-button border transition-colors ${
                  active === c ? "bg-accent text-primary border-accent" : "border-border-base text-text-muted hover:border-accent"
                }`}
              >
                {c}
              </button>
            ))}
          </div>
        )}

        <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-4">
          {filtered.map((img) => (
            <div key={img.id} className="relative aspect-square rounded-card overflow-hidden group">
              <Image src={img.image} alt={img.caption || ""} fill className="object-cover group-hover:scale-105 transition-transform duration-500" />
              {img.caption && (
                <div className="absolute inset-x-0 bottom-0 bg-gradient-to-t from-black/80 to-transparent p-3 opacity-0 group-hover:opacity-100 transition-opacity">
                  <p className="text-xs">{img.caption}</p>
                </div>
              )}
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}
