"use client";

import { useEffect, useState } from "react";
import Link from "next/link";
import Image from "next/image";
import JoinNowButton from "./JoinNowButton";

interface NavItem {
  id: string;
  label: string;
  url: string;
}

export default function Header({
  gymName,
  logoUrl,
  navItems,
  sticky = true
}: {
  gymName: string;
  logoUrl?: string | null;
  navItems: NavItem[];
  sticky?: boolean;
}) {
  const [scrolled, setScrolled] = useState(false);
  const [mobileOpen, setMobileOpen] = useState(false);

  useEffect(() => {
    function onScroll() {
      setScrolled(window.scrollY > 20);
    }
    window.addEventListener("scroll", onScroll);
    return () => window.removeEventListener("scroll", onScroll);
  }, []);

  return (
    <header
      className={`${sticky ? "sticky" : "relative"} top-0 z-50 w-full transition-all duration-300 ${
        scrolled ? "bg-background/90 backdrop-blur-md border-b border-border-base" : "bg-transparent"
      }`}
    >
      <div className="max-w-container mx-auto px-4 md:px-8 flex items-center justify-between h-20">
        <Link href="/" className="flex items-center gap-2">
          {logoUrl ? (
            <Image src={logoUrl} alt={gymName} width={40} height={40} className="object-contain" />
          ) : (
            <span className="text-2xl">🏋️</span>
          )}
          <span className="font-heading-theme text-xl md:text-2xl uppercase tracking-wide">{gymName}</span>
        </Link>

        <nav className="hidden lg:flex items-center gap-8">
          {navItems.map((item) => (
            <Link
              key={item.id}
              href={item.url}
              className="text-sm uppercase tracking-wide text-text-muted hover:text-text-base transition-colors"
            >
              {item.label}
            </Link>
          ))}
        </nav>

        <div className="hidden lg:block">
          <JoinNowButton />
        </div>

        <button
          className="lg:hidden text-2xl"
          aria-label="Toggle menu"
          onClick={() => setMobileOpen((v) => !v)}
        >
          {mobileOpen ? "✕" : "☰"}
        </button>
      </div>

      {mobileOpen && (
        <div className="lg:hidden bg-background border-t border-border-base px-4 pb-6 pt-2 flex flex-col gap-4 animate-fade-up">
          {navItems.map((item) => (
            <Link
              key={item.id}
              href={item.url}
              onClick={() => setMobileOpen(false)}
              className="text-base uppercase tracking-wide py-2 border-b border-border-base"
            >
              {item.label}
            </Link>
          ))}
          <JoinNowButton className="w-full text-center mt-2" />
        </div>
      )}
    </header>
  );
}
