import Image from "next/image";

export interface TransformationItem {
  id: string;
  beforeImage: string;
  afterImage: string;
  memberName: string;
  goal: string;
  duration: string;
  description: string | null;
}

export default function Transformations({
  heading,
  items
}: {
  heading?: string;
  items: TransformationItem[];
}) {
  if (items.length === 0) return null;

  return (
    <section id="transformations" className="section-spacing bg-surface/40">
      <div className="max-w-container mx-auto px-6 md:px-8">
        <h2 className="font-heading-theme uppercase text-4xl md:text-5xl mb-12 text-center">
          {heading || "Real Transformations"}
        </h2>
        <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-6">
          {items.map((t) => (
            <div key={t.id} className="card-surface overflow-hidden">
              <div className="grid grid-cols-2">
                <div className="relative aspect-square">
                  <Image src={t.beforeImage} alt={`${t.memberName} before`} fill className="object-cover" />
                  <span className="absolute bottom-2 left-2 text-xs bg-black/70 px-2 py-1 rounded-base">Before</span>
                </div>
                <div className="relative aspect-square">
                  <Image src={t.afterImage} alt={`${t.memberName} after`} fill className="object-cover" />
                  <span className="absolute bottom-2 left-2 text-xs bg-black/70 px-2 py-1 rounded-base">After</span>
                </div>
              </div>
              <div className="p-5">
                <h3 className="font-heading-theme uppercase text-lg">{t.memberName}</h3>
                <p className="text-text-muted text-sm">
                  {t.goal} · {t.duration}
                </p>
                {t.description && <p className="text-text-muted text-sm mt-2">{t.description}</p>}
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}
