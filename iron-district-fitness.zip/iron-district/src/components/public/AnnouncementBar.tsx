"use client";

import { useState } from "react";
import { useJoinNow } from "./JoinNowContext";

export default function AnnouncementBar({
  text,
  linkText,
  linkUrl,
  background,
  textColor
}: {
  text: string;
  linkText: string;
  linkUrl: string;
  background: string;
  textColor: string;
}) {
  const [dismissed, setDismissed] = useState(false);
  const { open } = useJoinNow();

  if (dismissed) return null;

  return (
    <div style={{ backgroundColor: background, color: textColor }} className="relative text-sm">
      <div className="max-w-container mx-auto px-4 py-2 flex items-center justify-center gap-2 text-center">
        <span>{text}</span>
        {linkUrl === "#join-now" ? (
          <button onClick={open} className="font-semibold underline">
            {linkText}
          </button>
        ) : (
          <a href={linkUrl} className="font-semibold underline">
            {linkText}
          </a>
        )}
      </div>
      <button
        onClick={() => setDismissed(true)}
        aria-label="Dismiss"
        className="absolute right-3 top-1/2 -translate-y-1/2 opacity-70 hover:opacity-100"
      >
        ✕
      </button>
    </div>
  );
}
