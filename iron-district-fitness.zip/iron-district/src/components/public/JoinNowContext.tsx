"use client";

import { createContext, useContext, useState, ReactNode } from "react";

interface JoinNowContextValue {
  isOpen: boolean;
  open: () => void;
  close: () => void;
}

const JoinNowContext = createContext<JoinNowContextValue | null>(null);

export function JoinNowProvider({ children }: { children: ReactNode }) {
  const [isOpen, setIsOpen] = useState(false);
  return (
    <JoinNowContext.Provider value={{ isOpen, open: () => setIsOpen(true), close: () => setIsOpen(false) }}>
      {children}
    </JoinNowContext.Provider>
  );
}

export function useJoinNow() {
  const ctx = useContext(JoinNowContext);
  if (!ctx) throw new Error("useJoinNow must be used within JoinNowProvider");
  return ctx;
}
