import Image from "next/image";
import JoinNowButton from "./JoinNowButton";
import Link from "next/link";

export interface HeroData {
  heading: string;
  subheading: string;
  backgroundImage?: string;
  backgroundVideo?: string;
  overlayOpacity?: number;
  align?: "left" | "center" | "right";
  primaryButtonText?: string;
  primaryButtonLink?: string;
  secondaryButtonText?: string;
  secondaryButtonLink?: string;
  secondaryButtonVisible?: boolean;
}

export default function Hero({ data }: { data: HeroData }) {
  const alignClass =
    data.align === "left" ? "items-start text-left" : data.align === "right" ? "items-end text-right" : "items-center text-center";

  return (
    <section id="home" className="relative min-h-[92vh] flex items-center overflow-hidden">
      <div className="absolute inset-0">
        {data.backgroundVideo ? (
          <video
            src={data.backgroundVideo}
            autoPlay
            muted
            loop
            playsInline
            className="w-full h-full object-cover"
          />
        ) : data.backgroundImage ? (
          <Image src={data.backgroundImage} alt="" fill priority className="object-cover" />
        ) : (
          <div className="w-full h-full bg-gradient-to-br from-surface to-background" />
        )}
        <div
          className="absolute inset-0 bg-black"
          style={{ opacity: (data.overlayOpacity ?? 55) / 100 }}
        />
      </div>

      <div className={`relative z-10 max-w-container mx-auto px-6 md:px-8 flex flex-col ${alignClass} gap-6 w-full`}>
        <h1 className="font-heading-theme uppercase text-5xl md:text-7xl lg:text-8xl leading-[0.95] max-w-4xl animate-fade-up">
          {data.heading}
        </h1>
        <p className="text-text-muted text-lg md:text-xl max-w-xl animate-fade-up">{data.subheading}</p>
        <div className="flex flex-wrap gap-4 mt-2 animate-fade-up">
          <JoinNowButton label={data.primaryButtonText || "JOIN NOW"} />
          {data.secondaryButtonVisible !== false && data.secondaryButtonText && (
            <Link href={data.secondaryButtonLink || "#programs"} className="btn-outline px-6 py-3 font-heading-theme uppercase text-sm md:text-base">
              {data.secondaryButtonText}
            </Link>
          )}
        </div>
      </div>
    </section>
  );
}
