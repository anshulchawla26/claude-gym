"use client";

import { useJoinNow } from "./JoinNowContext";
import clsx from "clsx";

export default function JoinNowButton({
  label = "JOIN NOW",
  variant = "solid",
  className
}: {
  label?: string;
  variant?: "solid" | "outline";
  className?: string;
}) {
  const { open } = useJoinNow();
  return (
    <button
      onClick={open}
      className={clsx(
        "px-6 py-3 font-heading-theme uppercase tracking-wide text-sm md:text-base transition-all",
        variant === "solid" ? "btn-primary" : "btn-outline",
        className
      )}
    >
      {label}
    </button>
  );
}
