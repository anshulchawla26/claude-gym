import Image from "next/image";

export interface FacilityItem {
  id: string;
  name: string;
  description: string;
  image: string | null;
  icon: string;
}

export default function Facilities({ heading, facilities }: { heading?: string; facilities: FacilityItem[] }) {
  if (facilities.length === 0) return null;

  return (
    <section id="facilities" className="section-spacing bg-surface/40">
      <div className="max-w-container mx-auto px-6 md:px-8">
        <h2 className="font-heading-theme uppercase text-4xl md:text-5xl mb-12 text-center">
          {heading || "World-Class Facilities"}
        </h2>
        <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-6">
          {facilities.map((f) => (
            <div key={f.id} className="card-surface overflow-hidden">
              <div className="relative h-40 bg-secondary">
                {f.image && <Image src={f.image} alt={f.name} fill className="object-cover" />}
              </div>
              <div className="p-5">
                <div className="text-2xl mb-2">{f.icon}</div>
                <h3 className="font-heading-theme uppercase text-lg mb-1">{f.name}</h3>
                <p className="text-text-muted text-sm">{f.description}</p>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}
