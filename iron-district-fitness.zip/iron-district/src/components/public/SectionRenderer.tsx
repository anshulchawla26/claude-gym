import { prisma } from "@/lib/prisma";
import type { PageSection } from "@prisma/client";
import Hero, { HeroData } from "./Hero";
import Stats from "./Stats";
import About, { AboutData } from "./About";
import WhyChooseUs from "./WhyChooseUs";
import Programs from "./Programs";
import Facilities from "./Facilities";
import Trainers from "./Trainers";
import Transformations from "./Transformations";
import Testimonials from "./Testimonials";
import Gallery from "./Gallery";
import CTA, { CTAData } from "./CTA";
import Location from "./Location";
import FAQAccordion from "./FAQAccordion";
import RichText from "./RichText";
import { getSiteSettings } from "@/lib/site-data";

function safeParse<T>(json: string, fallback: T): T {
  try {
    return JSON.parse(json);
  } catch {
    return fallback;
  }
}

const DATA_DRIVEN_TYPES = new Set(["programs", "facilities", "trainers", "transformations", "testimonials", "gallery", "faq", "location"]);

export default async function SectionRenderer({ sections }: { sections: PageSection[] }) {
  const visible = sections.filter((s) => s.visible).sort((a, b) => a.order - b.order);
  const neededTypes = new Set(visible.map((s) => s.type));

  const needsAny = Array.from(neededTypes).some((t) => DATA_DRIVEN_TYPES.has(t));
  const [programs, trainers, facilities, transformations, testimonials, gallery, faqs, site] = needsAny
    ? await Promise.all([
        neededTypes.has("programs") ? prisma.program.findMany({ where: { visible: true }, orderBy: { order: "asc" } }) : [],
        neededTypes.has("trainers") ? prisma.trainer.findMany({ where: { visible: true }, orderBy: { order: "asc" } }) : [],
        neededTypes.has("facilities") ? prisma.facility.findMany({ where: { visible: true }, orderBy: { order: "asc" } }) : [],
        neededTypes.has("transformations")
          ? prisma.transformation.findMany({ where: { visible: true }, orderBy: { order: "asc" } })
          : [],
        neededTypes.has("testimonials") ? prisma.testimonial.findMany({ where: { visible: true }, orderBy: { order: "asc" } }) : [],
        neededTypes.has("gallery") ? prisma.galleryItem.findMany({ where: { visible: true }, orderBy: { order: "asc" } }) : [],
        neededTypes.has("faq") ? prisma.fAQ.findMany({ where: { visible: true }, orderBy: { order: "asc" } }) : [],
        neededTypes.has("location") ? getSiteSettings() : null
      ])
    : [[], [], [], [], [], [], [], null];

  return (
    <>
      {visible.map((section) => {
        const data = safeParse<any>(section.data, {});

        switch (section.type) {
          case "hero":
            return <Hero key={section.id} data={data as HeroData} />;
          case "stats":
            return <Stats key={section.id} data={data} />;
          case "about":
            return <About key={section.id} data={data as AboutData} />;
          case "whyChooseUs":
            return <WhyChooseUs key={section.id} data={data} />;
          case "richtext":
            return <RichText key={section.id} heading={data.heading} content={data.content ?? ""} />;
          case "programs":
            return (
              <Programs
                key={section.id}
                heading={data.heading}
                programs={(programs as any[]).map((p) => ({
                  id: p.id,
                  name: p.name,
                  slug: p.slug,
                  shortDesc: p.shortDesc,
                  image: p.image,
                  icon: p.icon,
                  ctaText: p.ctaText,
                  ctaLink: p.ctaLink
                }))}
              />
            );
          case "facilities":
            return <Facilities key={section.id} heading={data.heading} facilities={facilities as any} />;
          case "trainers":
            return (
              <Trainers
                key={section.id}
                heading={data.heading}
                trainers={(trainers as any[]).map((t) => ({ ...t, specializations: safeParse<string[]>(t.specializations, []) }))}
              />
            );
          case "transformations":
            return <Transformations key={section.id} heading={data.heading} items={transformations as any} />;
          case "testimonials":
            return <Testimonials key={section.id} heading={data.heading} items={testimonials as any} />;
          case "gallery":
            return <Gallery key={section.id} heading={data.heading} items={gallery as any} />;
          case "faq":
            return <FAQAccordion key={section.id} heading={data.heading} items={faqs as any} />;
          case "cta":
            return <CTA key={section.id} data={data as CTAData} />;
          case "location": {
            const s = site as any;
            return (
              <Location
                key={section.id}
                gymName={s?.gymName ?? ""}
                address={s?.address ?? ""}
                phone={s?.phone ?? ""}
                email={s?.email ?? ""}
                whatsapp={s?.whatsapp ?? ""}
                mapEmbedUrl={s?.mapEmbedUrl}
                mapLink={s?.mapLink}
                openingHours={safeParse(s?.openingHours ?? "[]", [])}
              />
            );
          }
          default:
            return null;
        }
      })}
    </>
  );
}
