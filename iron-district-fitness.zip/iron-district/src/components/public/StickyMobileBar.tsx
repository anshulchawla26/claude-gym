"use client";

import { useJoinNow } from "./JoinNowContext";

export default function StickyMobileBar({ phone, whatsapp }: { phone: string; whatsapp: string }) {
  const { open } = useJoinNow();

  return (
    <div className="lg:hidden fixed bottom-0 inset-x-0 z-40 bg-surface border-t border-border-base grid grid-cols-3">
      <a href={`tel:${phone}`} className="flex flex-col items-center justify-center py-3 text-xs gap-1 border-r border-border-base">
        <span className="text-lg">📞</span>
        Call
      </a>
      <a
        href={`https://wa.me/${whatsapp.replace(/[^\d]/g, "")}`}
        target="_blank"
        rel="noopener noreferrer"
        className="flex flex-col items-center justify-center py-3 text-xs gap-1 border-r border-border-base"
      >
        <span className="text-lg">💬</span>
        WhatsApp
      </a>
      <button onClick={open} className="flex flex-col items-center justify-center py-3 text-xs gap-1 bg-accent text-primary font-semibold">
        <span className="text-lg">🔥</span>
        Join Now
      </button>
    </div>
  );
}
