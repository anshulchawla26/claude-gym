export interface OpeningHour {
  day: string;
  hours: string;
}

export default function Location({
  gymName,
  address,
  phone,
  email,
  whatsapp,
  mapEmbedUrl,
  mapLink,
  openingHours
}: {
  gymName: string;
  address: string;
  phone: string;
  email: string;
  whatsapp: string;
  mapEmbedUrl?: string | null;
  mapLink?: string | null;
  openingHours: OpeningHour[];
}) {
  return (
    <section id="contact" className="section-spacing">
      <div className="max-w-container mx-auto px-6 md:px-8 grid md:grid-cols-2 gap-10">
        <div>
          <h2 className="font-heading-theme uppercase text-4xl md:text-5xl mb-6">Visit {gymName}</h2>
          <div className="space-y-4 text-text-muted">
            <p>{address}</p>
            <p>
              📞{" "}
              <a href={`tel:${phone}`} className="hover:text-accent">
                {phone}
              </a>
            </p>
            <p>
              ✉️{" "}
              <a href={`mailto:${email}`} className="hover:text-accent">
                {email}
              </a>
            </p>
            <p>
              💬{" "}
              <a
                href={`https://wa.me/${whatsapp.replace(/[^\d]/g, "")}`}
                target="_blank"
                rel="noopener noreferrer"
                className="hover:text-accent"
              >
                WhatsApp Us
              </a>
            </p>
            {mapLink && (
              <a href={mapLink} target="_blank" rel="noopener noreferrer" className="inline-block text-accent underline text-sm">
                Get Directions →
              </a>
            )}
          </div>

          {openingHours.length > 0 && (
            <div className="mt-8">
              <h3 className="font-heading-theme uppercase text-lg mb-3">Opening Hours</h3>
              <ul className="space-y-1 text-sm text-text-muted">
                {openingHours.map((o) => (
                  <li key={o.day} className="flex justify-between max-w-xs">
                    <span>{o.day}</span>
                    <span>{o.hours}</span>
                  </li>
                ))}
              </ul>
            </div>
          )}
        </div>

        <div className="rounded-card overflow-hidden border border-border-base min-h-[320px]">
          {mapEmbedUrl ? (
            <iframe src={mapEmbedUrl} className="w-full h-full min-h-[320px]" loading="lazy" title="Map location" />
          ) : (
            <div className="w-full h-full min-h-[320px] bg-surface flex items-center justify-center text-text-muted text-sm">
              Map not configured
            </div>
          )}
        </div>
      </div>
    </section>
  );
}
