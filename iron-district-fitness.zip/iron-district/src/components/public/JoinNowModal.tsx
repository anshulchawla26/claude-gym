"use client";

import { useState, FormEvent } from "react";
import { useJoinNow } from "./JoinNowContext";

const GENDER_OPTIONS = ["Male", "Female", "Prefer not to say"];
const GOAL_OPTIONS = [
  "Weight Loss",
  "Muscle Gain",
  "Strength Training",
  "General Fitness",
  "Body Transformation",
  "Personal Training",
  "Other"
];

type Status = "idle" | "submitting" | "success" | "error";

export default function JoinNowModal({ whatsapp }: { whatsapp?: string | null }) {
  const { isOpen, close } = useJoinNow();
  const [status, setStatus] = useState<Status>("idle");
  const [errors, setErrors] = useState<Record<string, string>>({});
  const [errorMessage, setErrorMessage] = useState("");

  if (!isOpen) return null;

  async function handleSubmit(e: FormEvent<HTMLFormElement>) {
    e.preventDefault();
    setStatus("submitting");
    setErrors({});
    setErrorMessage("");

    const form = e.currentTarget;
    const data = {
      fullName: (form.elements.namedItem("fullName") as HTMLInputElement).value,
      mobile: (form.elements.namedItem("mobile") as HTMLInputElement).value,
      email: (form.elements.namedItem("email") as HTMLInputElement).value,
      gender: (form.elements.namedItem("gender") as HTMLSelectElement).value,
      fitnessGoal: (form.elements.namedItem("fitnessGoal") as HTMLSelectElement).value,
      website: (form.elements.namedItem("website") as HTMLInputElement).value // honeypot
    };

    try {
      const res = await fetch("/api/leads", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(data)
      });
      const json = await res.json();

      if (!res.ok) {
        if (json.fieldErrors) setErrors(json.fieldErrors);
        setErrorMessage(json.message || "Something went wrong. Please try again.");
        setStatus("error");
        return;
      }

      setStatus("success");
    } catch {
      setErrorMessage("Network error. Please check your connection and try again.");
      setStatus("error");
    }
  }

  function handleClose() {
    close();
    setStatus("idle");
    setErrors({});
  }

  return (
    <div className="fixed inset-0 z-[100] flex items-center justify-center bg-black/70 p-4" onClick={handleClose}>
      <div
        className="card-surface w-full max-w-md p-6 md:p-8 relative animate-fade-up max-h-[90vh] overflow-y-auto"
        onClick={(e) => e.stopPropagation()}
      >
        <button
          onClick={handleClose}
          aria-label="Close"
          className="absolute top-4 right-4 text-text-muted hover:text-text-base text-xl"
        >
          ×
        </button>

        {status === "success" ? (
          <div className="text-center py-6">
            <div className="text-4xl mb-4">✅</div>
            <h3 className="font-heading-theme text-2xl uppercase mb-3">Thank You!</h3>
            <p className="text-text-muted mb-6">
              Your enquiry has been received. Our fitness team will contact you shortly.
            </p>
            <div className="flex flex-col gap-3">
              {whatsapp && (
                <a
                  href={`https://wa.me/${whatsapp.replace(/[^\d]/g, "")}`}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="btn-primary py-3 rounded-button text-center font-heading-theme uppercase"
                >
                  Message us on WhatsApp
                </a>
              )}
              <button onClick={handleClose} className="btn-outline py-3 rounded-button">
                Close
              </button>
            </div>
          </div>
        ) : (
          <>
            <h3 className="font-heading-theme text-2xl uppercase mb-1">Join Now</h3>
            <p className="text-text-muted text-sm mb-6">
              Tell us about your goals — our team will reach out to get you started.
            </p>

            <form onSubmit={handleSubmit} className="space-y-4" noValidate>
              {/* Honeypot — hidden from real users, anti-spam */}
              <input
                type="text"
                name="website"
                tabIndex={-1}
                autoComplete="off"
                className="hidden"
                aria-hidden="true"
              />

              <div>
                <label className="block text-sm mb-1">Full Name *</label>
                <input
                  name="fullName"
                  required
                  minLength={2}
                  className="w-full bg-background border border-border-base rounded-base px-4 py-2.5 focus:outline-none focus:border-accent"
                />
                {errors.fullName && <p className="text-red-400 text-xs mt-1">{errors.fullName}</p>}
              </div>

              <div>
                <label className="block text-sm mb-1">Mobile Number *</label>
                <input
                  name="mobile"
                  type="tel"
                  required
                  pattern="^\+?[0-9\s-]{7,15}$"
                  className="w-full bg-background border border-border-base rounded-base px-4 py-2.5 focus:outline-none focus:border-accent"
                />
                {errors.mobile && <p className="text-red-400 text-xs mt-1">{errors.mobile}</p>}
              </div>

              <div>
                <label className="block text-sm mb-1">Email Address *</label>
                <input
                  name="email"
                  type="email"
                  required
                  className="w-full bg-background border border-border-base rounded-base px-4 py-2.5 focus:outline-none focus:border-accent"
                />
                {errors.email && <p className="text-red-400 text-xs mt-1">{errors.email}</p>}
              </div>

              <div>
                <label className="block text-sm mb-1">Gender *</label>
                <select
                  name="gender"
                  required
                  defaultValue=""
                  className="w-full bg-background border border-border-base rounded-base px-4 py-2.5 focus:outline-none focus:border-accent"
                >
                  <option value="" disabled>
                    Select gender
                  </option>
                  {GENDER_OPTIONS.map((g) => (
                    <option key={g} value={g}>
                      {g}
                    </option>
                  ))}
                </select>
                {errors.gender && <p className="text-red-400 text-xs mt-1">{errors.gender}</p>}
              </div>

              <div>
                <label className="block text-sm mb-1">Fitness Goal *</label>
                <select
                  name="fitnessGoal"
                  required
                  defaultValue=""
                  className="w-full bg-background border border-border-base rounded-base px-4 py-2.5 focus:outline-none focus:border-accent"
                >
                  <option value="" disabled>
                    Select your goal
                  </option>
                  {GOAL_OPTIONS.map((g) => (
                    <option key={g} value={g}>
                      {g}
                    </option>
                  ))}
                </select>
                {errors.fitnessGoal && <p className="text-red-400 text-xs mt-1">{errors.fitnessGoal}</p>}
              </div>

              {errorMessage && <p className="text-red-400 text-sm">{errorMessage}</p>}

              <button
                type="submit"
                disabled={status === "submitting"}
                className="btn-primary w-full py-3 rounded-button font-heading-theme uppercase disabled:opacity-60"
              >
                {status === "submitting" ? "Submitting..." : "Submit Enquiry"}
              </button>
            </form>
          </>
        )}
      </div>
    </div>
  );
}
