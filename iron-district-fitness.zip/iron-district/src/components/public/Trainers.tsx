import Image from "next/image";

export interface TrainerItem {
  id: string;
  name: string;
  photo: string | null;
  designation: string;
  experienceYears: number;
  bio: string;
  specializations: string[];
  instagram: string | null;
  facebook: string | null;
}

export default function Trainers({ heading, trainers }: { heading?: string; trainers: TrainerItem[] }) {
  if (trainers.length === 0) return null;

  return (
    <section id="trainers" className="section-spacing">
      <div className="max-w-container mx-auto px-6 md:px-8">
        <h2 className="font-heading-theme uppercase text-4xl md:text-5xl mb-12 text-center">
          {heading || "Meet Our Trainers"}
        </h2>
        <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-6">
          {trainers.map((t) => (
            <div key={t.id} className="card-surface overflow-hidden group">
              <div className="relative h-64 bg-secondary">
                {t.photo && (
                  <Image src={t.photo} alt={t.name} fill className="object-cover group-hover:scale-105 transition-transform duration-500" />
                )}
              </div>
              <div className="p-5">
                <h3 className="font-heading-theme uppercase text-lg">{t.name}</h3>
                <p className="text-accent text-xs uppercase tracking-wide mb-2">{t.designation}</p>
                <p className="text-text-muted text-sm mb-3">{t.experienceYears}+ yrs experience</p>
                <div className="flex gap-1 flex-wrap">
                  {t.specializations.slice(0, 3).map((s) => (
                    <span key={s} className="text-xs px-2 py-1 rounded-base border border-border-base text-text-muted">
                      {s}
                    </span>
                  ))}
                </div>
                <div className="flex gap-3 mt-3">
                  {t.instagram && (
                    <a href={t.instagram} target="_blank" rel="noopener noreferrer" className="text-sm text-text-muted hover:text-accent">
                      Instagram
                    </a>
                  )}
                  {t.facebook && (
                    <a href={t.facebook} target="_blank" rel="noopener noreferrer" className="text-sm text-text-muted hover:text-accent">
                      Facebook
                    </a>
                  )}
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}
