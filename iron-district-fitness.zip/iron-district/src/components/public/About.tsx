import Image from "next/image";
import Link from "next/link";

export interface AboutData {
  heading: string;
  description: string;
  image?: string;
  secondaryImage?: string;
  ctaText?: string;
  ctaLink?: string;
}

export default function About({ data }: { data: AboutData }) {
  return (
    <section id="about" className="section-spacing">
      <div className="max-w-container mx-auto px-6 md:px-8 grid md:grid-cols-2 gap-12 items-center">
        <div className="relative">
          {data.image && (
            <div className="relative aspect-[4/5] rounded-card overflow-hidden">
              <Image src={data.image} alt={data.heading} fill className="object-cover" />
            </div>
          )}
          {data.secondaryImage && (
            <div className="hidden md:block absolute -bottom-8 -right-8 w-40 h-40 rounded-card overflow-hidden border-4 border-background">
              <Image src={data.secondaryImage} alt="" fill className="object-cover" />
            </div>
          )}
        </div>
        <div>
          <h2 className="font-heading-theme uppercase text-4xl md:text-5xl mb-6">{data.heading}</h2>
          <p className="text-text-muted text-lg leading-relaxed mb-8 whitespace-pre-line">{data.description}</p>
          {data.ctaText && (
            <Link href={data.ctaLink || "/about"} className="btn-primary inline-block px-6 py-3 font-heading-theme uppercase text-sm">
              {data.ctaText}
            </Link>
          )}
        </div>
      </div>
    </section>
  );
}
