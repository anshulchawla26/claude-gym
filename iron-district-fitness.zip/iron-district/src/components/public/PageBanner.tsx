export default function PageBanner({ title, subtitle }: { title: string; subtitle?: string }) {
  return (
    <section className="py-20 md:py-28 border-b border-border-base bg-surface/40">
      <div className="max-w-container mx-auto px-6 md:px-8 text-center">
        <h1 className="font-heading-theme uppercase text-4xl md:text-6xl mb-3">{title}</h1>
        {subtitle && <p className="text-text-muted text-lg max-w-xl mx-auto">{subtitle}</p>}
      </div>
    </section>
  );
}
