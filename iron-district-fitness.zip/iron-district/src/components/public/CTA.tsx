import Image from "next/image";
import JoinNowButton from "./JoinNowButton";

export interface CTAData {
  heading: string;
  description?: string;
  buttonText?: string;
  backgroundImage?: string;
}

export default function CTA({ data }: { data: CTAData }) {
  return (
    <section id="join-now" className="relative section-spacing overflow-hidden">
      <div className="absolute inset-0">
        {data.backgroundImage ? (
          <Image src={data.backgroundImage} alt="" fill className="object-cover" />
        ) : (
          <div className="w-full h-full bg-secondary" />
        )}
        <div className="absolute inset-0 bg-black/70" />
      </div>
      <div className="relative z-10 max-w-2xl mx-auto px-6 text-center">
        <h2 className="font-heading-theme uppercase text-4xl md:text-5xl mb-4">{data.heading}</h2>
        {data.description && <p className="text-text-muted text-lg mb-8">{data.description}</p>}
        <JoinNowButton label={data.buttonText || "JOIN NOW"} />
      </div>
    </section>
  );
}
