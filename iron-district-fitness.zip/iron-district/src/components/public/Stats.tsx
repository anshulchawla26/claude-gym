export interface StatItem {
  number: string;
  label: string;
  icon?: string;
}

export default function Stats({ data }: { data: { items: StatItem[] } }) {
  const items = data?.items || [];
  if (items.length === 0) return null;

  return (
    <section className="border-y border-border-base bg-surface">
      <div className="max-w-container mx-auto px-6 md:px-8 py-12 grid grid-cols-2 md:grid-cols-4 gap-8 text-center">
        {items.map((item, i) => (
          <div key={i}>
            {item.icon && <div className="text-3xl mb-2">{item.icon}</div>}
            <div className="font-heading-theme text-4xl md:text-5xl text-accent">{item.number}</div>
            <div className="text-text-muted uppercase text-xs md:text-sm tracking-wide mt-1">{item.label}</div>
          </div>
        ))}
      </div>
    </section>
  );
}
