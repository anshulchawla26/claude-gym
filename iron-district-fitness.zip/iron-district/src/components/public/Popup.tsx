"use client";

import { useEffect, useState } from "react";
import Image from "next/image";
import { useJoinNow } from "./JoinNowContext";

interface PopupProps {
  heading: string;
  description: string;
  image?: string | null;
  buttonText: string;
  delaySeconds: number;
  frequency: string;
  desktopVisible: boolean;
  mobileVisible: boolean;
}

const STORAGE_KEY = "idf_popup_shown_at";

export default function Popup(props: PopupProps) {
  const [visible, setVisible] = useState(false);
  const { open: openJoinNow } = useJoinNow();

  useEffect(() => {
    const isMobile = window.innerWidth < 768;
    if (isMobile && !props.mobileVisible) return;
    if (!isMobile && !props.desktopVisible) return;

    if (props.frequency === "once_per_session") {
      try {
        const shown = sessionStorage.getItem(STORAGE_KEY);
        if (shown) return;
      } catch {
        /* storage unavailable — fall through and show anyway */
      }
    }

    const timer = setTimeout(() => {
      setVisible(true);
      try {
        sessionStorage.setItem(STORAGE_KEY, "1");
      } catch {}
    }, props.delaySeconds * 1000);

    return () => clearTimeout(timer);
  }, [props.delaySeconds, props.frequency, props.desktopVisible, props.mobileVisible]);

  if (!visible) return null;

  return (
    <div className="fixed inset-0 z-[90] flex items-center justify-center bg-black/70 p-4" onClick={() => setVisible(false)}>
      <div className="card-surface w-full max-w-sm p-6 text-center relative animate-fade-up" onClick={(e) => e.stopPropagation()}>
        <button
          onClick={() => setVisible(false)}
          aria-label="Close"
          className="absolute top-3 right-3 text-text-muted hover:text-text-base text-xl"
        >
          ×
        </button>
        {props.image && (
          <div className="relative w-full h-32 mb-4 rounded-base overflow-hidden">
            <Image src={props.image} alt="" fill className="object-cover" />
          </div>
        )}
        <h3 className="font-heading-theme uppercase text-2xl mb-2">{props.heading}</h3>
        <p className="text-text-muted mb-6">{props.description}</p>
        <button
          onClick={() => {
            setVisible(false);
            openJoinNow();
          }}
          className="btn-primary w-full py-3 rounded-button font-heading-theme uppercase"
        >
          {props.buttonText}
        </button>
      </div>
    </div>
  );
}
