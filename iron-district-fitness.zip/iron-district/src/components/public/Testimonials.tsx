import Image from "next/image";

export interface TestimonialItem {
  id: string;
  name: string;
  photo: string | null;
  review: string;
  rating: number;
}

export default function Testimonials({ heading, items }: { heading?: string; items: TestimonialItem[] }) {
  if (items.length === 0) return null;

  return (
    <section id="testimonials" className="section-spacing">
      <div className="max-w-container mx-auto px-6 md:px-8">
        <h2 className="font-heading-theme uppercase text-4xl md:text-5xl mb-12 text-center">
          {heading || "What Our Members Say"}
        </h2>
        <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-6">
          {items.map((t) => (
            <div key={t.id} className="card-surface p-6">
              <div className="flex items-center gap-3 mb-4">
                {t.photo && (
                  <div className="relative w-12 h-12 rounded-full overflow-hidden">
                    <Image src={t.photo} alt={t.name} fill className="object-cover" />
                  </div>
                )}
                <div>
                  <div className="font-medium">{t.name}</div>
                  <div className="text-accent text-sm">{"★".repeat(t.rating)}{"☆".repeat(5 - t.rating)}</div>
                </div>
              </div>
              <p className="text-text-muted text-sm leading-relaxed">&ldquo;{t.review}&rdquo;</p>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}
