"use client";

import { useState } from "react";

export interface FAQItem {
  id: string;
  question: string;
  answer: string;
}

export default function FAQAccordion({ heading, items }: { heading?: string; items: FAQItem[] }) {
  const [openId, setOpenId] = useState<string | null>(items[0]?.id ?? null);

  if (items.length === 0) return null;

  return (
    <section id="faq" className="section-spacing bg-surface/40">
      <div className="max-w-3xl mx-auto px-6 md:px-8">
        <h2 className="font-heading-theme uppercase text-4xl md:text-5xl mb-12 text-center">
          {heading || "Frequently Asked Questions"}
        </h2>
        <div className="space-y-3">
          {items.map((item) => {
            const isOpen = openId === item.id;
            return (
              <div key={item.id} className="card-surface overflow-hidden">
                <button
                  onClick={() => setOpenId(isOpen ? null : item.id)}
                  className="w-full flex items-center justify-between p-5 text-left"
                >
                  <span className="font-medium">{item.question}</span>
                  <span className="text-accent text-xl">{isOpen ? "−" : "+"}</span>
                </button>
                {isOpen && <div className="px-5 pb-5 text-text-muted text-sm leading-relaxed">{item.answer}</div>}
              </div>
            );
          })}
        </div>
      </div>
    </section>
  );
}
