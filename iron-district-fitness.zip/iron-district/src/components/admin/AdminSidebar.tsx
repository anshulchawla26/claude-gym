"use client";

import Link from "next/link";
import { usePathname } from "next/navigation";
import clsx from "clsx";

const NAV_GROUPS = [
  {
    label: "Overview",
    items: [{ href: "/admin", label: "Dashboard", icon: "📊" }]
  },
  {
    label: "Website",
    items: [
      { href: "/admin/builder", label: "Website Builder", icon: "🧱" },
      { href: "/admin/pages", label: "Pages", icon: "📄" },
      { href: "/admin/navigation", label: "Navigation", icon: "🧭" },
      { href: "/admin/theme", label: "Theme / Design", icon: "🎨" },
      { href: "/admin/media", label: "Media Library", icon: "🖼️" },
      { href: "/admin/seo", label: "SEO", icon: "🔍" }
    ]
  },
  {
    label: "Content",
    items: [
      { href: "/admin/programs", label: "Programs", icon: "🏋️" },
      { href: "/admin/trainers", label: "Trainers", icon: "🧑‍🏫" },
      { href: "/admin/facilities", label: "Facilities", icon: "🏢" },
      { href: "/admin/testimonials", label: "Testimonials", icon: "💬" },
      { href: "/admin/transformations", label: "Transformations", icon: "🔄" },
      { href: "/admin/gallery", label: "Gallery", icon: "📷" },
      { href: "/admin/faqs", label: "FAQs", icon: "❓" }
    ]
  },
  {
    label: "Leads",
    items: [{ href: "/admin/leads", label: "Leads", icon: "📥" }]
  },
  {
    label: "Marketing",
    items: [
      { href: "/admin/popup", label: "Popup", icon: "🪟" },
      { href: "/admin/announcement", label: "Announcement Bar", icon: "📣" }
    ]
  },
  {
    label: "System",
    items: [
      { href: "/admin/settings", label: "Global Settings", icon: "⚙️" },
      { href: "/admin/notifications", label: "Notifications", icon: "🔔" },
      { href: "/admin/users", label: "Users / Admins", icon: "👤" },
      { href: "/admin/audit-log", label: "Activity Log", icon: "🧾" }
    ]
  }
];

export default function AdminSidebar() {
  const pathname = usePathname();

  return (
    <aside className="hidden lg:flex flex-col w-64 shrink-0 border-r border-neutral-800 bg-neutral-950 h-screen sticky top-0 overflow-y-auto">
      <div className="px-5 py-6 border-b border-neutral-800">
        <div className="font-bold text-lg text-white">Iron District</div>
        <div className="text-xs text-neutral-500 uppercase tracking-wide">Admin Panel</div>
      </div>
      <nav className="flex-1 px-3 py-4 space-y-6">
        {NAV_GROUPS.map((group) => (
          <div key={group.label}>
            <div className="text-[11px] uppercase tracking-wide text-neutral-500 px-3 mb-2">{group.label}</div>
            <div className="space-y-1">
              {group.items.map((item) => {
                const active = pathname === item.href || (item.href !== "/admin" && pathname?.startsWith(item.href));
                return (
                  <Link
                    key={item.href}
                    href={item.href}
                    className={clsx(
                      "flex items-center gap-3 px-3 py-2 rounded-lg text-sm transition-colors",
                      active ? "bg-lime-400 text-black font-medium" : "text-neutral-300 hover:bg-neutral-800"
                    )}
                  >
                    <span>{item.icon}</span>
                    {item.label}
                  </Link>
                );
              })}
            </div>
          </div>
        ))}
      </nav>
    </aside>
  );
}
