"use client";

import { useEffect, useState } from "react";
import toast from "react-hot-toast";
import { FieldConfig, ColumnConfig } from "@/types/admin";
import ImageUploadField from "./ImageUploadField";

interface EntityManagerProps {
  title: string;
  description?: string;
  apiBase: string;
  fields: FieldConfig[];
  columns: ColumnConfig[];
  defaultValues: Record<string, any>;
  orderable?: boolean;
  emptyMessage?: string;
}

export default function EntityManager({
  title,
  description,
  apiBase,
  fields,
  columns,
  defaultValues,
  orderable = true,
  emptyMessage = "Nothing added yet."
}: EntityManagerProps) {
  const [items, setItems] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);
  const [drawerOpen, setDrawerOpen] = useState(false);
  const [editing, setEditing] = useState<any | null>(null);
  const [formData, setFormData] = useState<Record<string, any>>(defaultValues);
  const [saving, setSaving] = useState(false);
  const [deleteTarget, setDeleteTarget] = useState<any | null>(null);

  async function load() {
    setLoading(true);
    try {
      const res = await fetch(apiBase);
      const json = await res.json();
      setItems(json.items || []);
    } catch {
      toast.error(`Failed to load ${title.toLowerCase()}`);
    } finally {
      setLoading(false);
    }
  }

  useEffect(() => {
    load();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [apiBase]);

  function openCreate() {
    setEditing(null);
    setFormData({ ...defaultValues, order: items.length });
    setDrawerOpen(true);
  }

  function openEdit(item: any) {
    setEditing(item);
    const hydrated: Record<string, any> = { ...item };
    for (const f of fields) {
      if (f.type === "tags" && typeof hydrated[f.name] === "string") {
        try {
          hydrated[f.name] = JSON.parse(hydrated[f.name]);
        } catch {
          hydrated[f.name] = [];
        }
      }
    }
    setFormData(hydrated);
    setDrawerOpen(true);
  }

  async function handleSave() {
    setSaving(true);
    try {
      const url = editing ? `${apiBase}/${editing.id}` : apiBase;
      const method = editing ? "PATCH" : "POST";
      const res = await fetch(url, {
        method,
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(formData)
      });
      const json = await res.json();
      if (!res.ok) {
        toast.error(json.message || "Save failed");
        return;
      }
      toast.success(editing ? "Updated" : "Created");
      setDrawerOpen(false);
      load();
    } catch {
      toast.error("Save failed — network error");
    } finally {
      setSaving(false);
    }
  }

  async function handleDelete() {
    if (!deleteTarget) return;
    try {
      const res = await fetch(`${apiBase}/${deleteTarget.id}`, { method: "DELETE" });
      if (!res.ok) {
        const json = await res.json().catch(() => ({}));
        toast.error(json.message || "Delete failed");
        return;
      }
      toast.success("Deleted");
      setDeleteTarget(null);
      load();
    } catch {
      toast.error("Delete failed — network error");
    }
  }

  async function toggleVisible(item: any) {
    await fetch(`${apiBase}/${item.id}`, {
      method: "PATCH",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ visible: !item.visible })
    });
    load();
  }

  async function move(item: any, direction: -1 | 1) {
    const sorted = [...items].sort((a, b) => (a.order ?? 0) - (b.order ?? 0));
    const idx = sorted.findIndex((i) => i.id === item.id);
    const swapIdx = idx + direction;
    if (swapIdx < 0 || swapIdx >= sorted.length) return;

    const a = sorted[idx];
    const b = sorted[swapIdx];

    await Promise.all([
      fetch(`${apiBase}/${a.id}`, {
        method: "PATCH",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ order: b.order })
      }),
      fetch(`${apiBase}/${b.id}`, {
        method: "PATCH",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ order: a.order })
      })
    ]);
    load();
  }

  function updateField(name: string, value: any) {
    setFormData((prev) => ({ ...prev, [name]: value }));
  }

  return (
    <div>
      <div className="flex items-start justify-between mb-6 flex-wrap gap-4">
        <div>
          <h1 className="text-2xl font-bold">{title}</h1>
          {description && <p className="text-neutral-400 text-sm mt-1">{description}</p>}
        </div>
        <button onClick={openCreate} className="bg-lime-400 text-black font-semibold px-4 py-2 rounded-lg hover:bg-lime-300">
          + Add New
        </button>
      </div>

      <div className="bg-neutral-950 border border-neutral-800 rounded-xl overflow-hidden">
        {loading ? (
          <div className="p-10 text-center text-neutral-500">Loading...</div>
        ) : items.length === 0 ? (
          <div className="p-10 text-center text-neutral-500">{emptyMessage}</div>
        ) : (
          <table className="w-full text-sm">
            <thead>
              <tr className="border-b border-neutral-800 text-neutral-400 text-left">
                {orderable && <th className="p-4 w-20">Order</th>}
                {columns.map((col) => (
                  <th key={col.key} className="p-4">
                    {col.label}
                  </th>
                ))}
                <th className="p-4 w-20">Visible</th>
                <th className="p-4 w-36">Actions</th>
              </tr>
            </thead>
            <tbody>
              {[...items]
                .sort((a, b) => (a.order ?? 0) - (b.order ?? 0))
                .map((item) => (
                  <tr key={item.id} className="border-b border-neutral-900 hover:bg-neutral-900/50">
                    {orderable && (
                      <td className="p-4">
                        <div className="flex flex-col gap-1">
                          <button onClick={() => move(item, -1)} className="text-neutral-500 hover:text-white">
                            ▲
                          </button>
                          <button onClick={() => move(item, 1)} className="text-neutral-500 hover:text-white">
                            ▼
                          </button>
                        </div>
                      </td>
                    )}
                    {columns.map((col) => (
                      <td key={col.key} className="p-4 max-w-xs truncate">
                        {col.render ? col.render(item) : String(item[col.key] ?? "")}
                      </td>
                    ))}
                    <td className="p-4">
                      <button
                        onClick={() => toggleVisible(item)}
                        className={`w-10 h-6 rounded-full transition-colors relative ${item.visible ? "bg-lime-400" : "bg-neutral-700"}`}
                      >
                        <span
                          className={`absolute top-0.5 w-5 h-5 bg-white rounded-full transition-transform ${
                            item.visible ? "translate-x-4" : "translate-x-0.5"
                          }`}
                        />
                      </button>
                    </td>
                    <td className="p-4">
                      <div className="flex gap-2">
                        <button onClick={() => openEdit(item)} className="text-neutral-300 hover:text-lime-400">
                          Edit
                        </button>
                        <button onClick={() => setDeleteTarget(item)} className="text-neutral-300 hover:text-red-400">
                          Delete
                        </button>
                      </div>
                    </td>
                  </tr>
                ))}
            </tbody>
          </table>
        )}
      </div>

      {drawerOpen && (
        <div className="fixed inset-0 z-[150] flex justify-end bg-black/60" onClick={() => setDrawerOpen(false)}>
          <div
            className="w-full max-w-lg bg-neutral-950 border-l border-neutral-800 h-full overflow-y-auto p-6"
            onClick={(e) => e.stopPropagation()}
          >
            <div className="flex justify-between items-center mb-6">
              <h2 className="text-lg font-semibold">{editing ? `Edit ${title}` : `Add ${title}`}</h2>
              <button onClick={() => setDrawerOpen(false)} className="text-neutral-400 hover:text-white text-xl">
                ✕
              </button>
            </div>

            <div className="space-y-4">
              {fields.map((field) => (
                <div key={field.name}>
                  {field.type === "text" && (
                    <>
                      <label className="block text-sm mb-1 text-neutral-300">
                        {field.label}
                        {field.required && " *"}
                      </label>
                      <input
                        value={formData[field.name] ?? ""}
                        onChange={(e) => updateField(field.name, e.target.value)}
                        className="w-full bg-neutral-900 border border-neutral-700 rounded-lg px-4 py-2.5 focus:outline-none focus:border-lime-400"
                      />
                    </>
                  )}

                  {field.type === "textarea" && (
                    <>
                      <label className="block text-sm mb-1 text-neutral-300">
                        {field.label}
                        {field.required && " *"}
                      </label>
                      <textarea
                        value={formData[field.name] ?? ""}
                        onChange={(e) => updateField(field.name, e.target.value)}
                        rows={4}
                        className="w-full bg-neutral-900 border border-neutral-700 rounded-lg px-4 py-2.5 focus:outline-none focus:border-lime-400"
                      />
                    </>
                  )}

                  {field.type === "number" && (
                    <>
                      <label className="block text-sm mb-1 text-neutral-300">{field.label}</label>
                      <input
                        type="number"
                        value={formData[field.name] ?? 0}
                        onChange={(e) => updateField(field.name, Number(e.target.value))}
                        className="w-full bg-neutral-900 border border-neutral-700 rounded-lg px-4 py-2.5 focus:outline-none focus:border-lime-400"
                      />
                    </>
                  )}

                  {field.type === "checkbox" && (
                    <label className="flex items-center gap-2 text-sm text-neutral-300">
                      <input
                        type="checkbox"
                        checked={!!formData[field.name]}
                        onChange={(e) => updateField(field.name, e.target.checked)}
                      />
                      {field.label}
                    </label>
                  )}

                  {field.type === "select" && (
                    <>
                      <label className="block text-sm mb-1 text-neutral-300">{field.label}</label>
                      <select
                        value={formData[field.name] ?? ""}
                        onChange={(e) => updateField(field.name, e.target.value)}
                        className="w-full bg-neutral-900 border border-neutral-700 rounded-lg px-4 py-2.5 focus:outline-none focus:border-lime-400"
                      >
                        {field.options?.map((opt) => (
                          <option key={opt} value={opt}>
                            {opt}
                          </option>
                        ))}
                      </select>
                    </>
                  )}

                  {field.type === "image" && (
                    <ImageUploadField
                      label={field.label}
                      value={formData[field.name]}
                      onChange={(url) => updateField(field.name, url)}
                    />
                  )}

                  {field.type === "tags" && (
                    <>
                      <label className="block text-sm mb-1 text-neutral-300">{field.label}</label>
                      <input
                        value={(Array.isArray(formData[field.name]) ? formData[field.name] : []).join(", ")}
                        onChange={(e) =>
                          updateField(
                            field.name,
                            e.target.value.split(",").map((s) => s.trim()).filter(Boolean)
                          )
                        }
                        placeholder="Comma-separated (e.g. Weight Loss, Strength)"
                        className="w-full bg-neutral-900 border border-neutral-700 rounded-lg px-4 py-2.5 focus:outline-none focus:border-lime-400"
                      />
                    </>
                  )}

                  {field.helpText && <p className="text-xs text-neutral-500 mt-1">{field.helpText}</p>}
                </div>
              ))}
            </div>

            <div className="flex gap-3 mt-8">
              <button
                onClick={handleSave}
                disabled={saving}
                className="flex-1 bg-lime-400 text-black font-semibold py-2.5 rounded-lg hover:bg-lime-300 disabled:opacity-60"
              >
                {saving ? "Saving..." : "Save"}
              </button>
              <button onClick={() => setDrawerOpen(false)} className="px-5 py-2.5 rounded-lg border border-neutral-700 text-neutral-300">
                Cancel
              </button>
            </div>
          </div>
        </div>
      )}

      {deleteTarget && (
        <div className="fixed inset-0 z-[200] bg-black/70 flex items-center justify-center p-4" onClick={() => setDeleteTarget(null)}>
          <div className="bg-neutral-950 border border-neutral-800 rounded-xl p-6 max-w-sm w-full" onClick={(e) => e.stopPropagation()}>
            <h3 className="font-semibold mb-2">Delete this item?</h3>
            <p className="text-neutral-400 text-sm mb-6">This action cannot be undone.</p>
            <div className="flex gap-3">
              <button onClick={handleDelete} className="flex-1 bg-red-500 hover:bg-red-400 text-white font-semibold py-2 rounded-lg">
                Delete
              </button>
              <button onClick={() => setDeleteTarget(null)} className="px-4 py-2 rounded-lg border border-neutral-700 text-neutral-300">
                Cancel
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
