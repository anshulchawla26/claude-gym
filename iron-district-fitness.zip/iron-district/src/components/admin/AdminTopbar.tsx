"use client";

import { useSession, signOut } from "next-auth/react";
import Link from "next/link";
import { useState } from "react";
import AdminSidebar from "./AdminSidebar";

export default function AdminTopbar() {
  const { data: session } = useSession();
  const [mobileOpen, setMobileOpen] = useState(false);

  return (
    <>
      <header className="sticky top-0 z-30 bg-neutral-950 border-b border-neutral-800 h-16 flex items-center justify-between px-4 lg:px-8">
        <button className="lg:hidden text-white text-xl" onClick={() => setMobileOpen(true)} aria-label="Open menu">
          ☰
        </button>

        <div className="hidden lg:block text-neutral-400 text-sm">
          Signed in as <span className="text-white font-medium">{session?.user?.name}</span>{" "}
          <span className="ml-2 px-2 py-0.5 rounded-full bg-neutral-800 text-xs uppercase">
            {(session?.user as any)?.role?.replace("_", " ")}
          </span>
        </div>

        <div className="flex items-center gap-4 ml-auto">
          <Link href="/" target="_blank" className="text-sm text-neutral-300 hover:text-lime-400">
            View Site ↗
          </Link>
          <button
            onClick={() => signOut({ callbackUrl: "/admin/login" })}
            className="text-sm bg-neutral-800 hover:bg-neutral-700 px-3 py-1.5 rounded-lg text-white"
          >
            Logout
          </button>
        </div>
      </header>

      {mobileOpen && (
        <div className="fixed inset-0 z-50 lg:hidden">
          <div className="absolute inset-0 bg-black/60" onClick={() => setMobileOpen(false)} />
          <div className="absolute inset-y-0 left-0 w-64 bg-neutral-950">
            <button className="absolute top-4 right-4 text-white text-xl" onClick={() => setMobileOpen(false)}>
              ✕
            </button>
            <AdminSidebar />
          </div>
        </div>
      )}
    </>
  );
}
