"use client";

import { useState } from "react";
import ImageUploadField from "./ImageUploadField";

const SECTION_LABELS: Record<string, string> = {
  hero: "Hero",
  stats: "Stats",
  about: "About",
  whyChooseUs: "Why Choose Us",
  programs: "Programs",
  facilities: "Facilities",
  trainers: "Trainers",
  transformations: "Transformations",
  testimonials: "Testimonials",
  gallery: "Gallery",
  faq: "FAQ",
  cta: "Call To Action",
  location: "Location"
};

export { SECTION_LABELS };

function TextInput({ label, value, onChange, textarea = false }: { label: string; value: string; onChange: (v: string) => void; textarea?: boolean }) {
  return (
    <div>
      <label className="block text-sm mb-1 text-neutral-300">{label}</label>
      {textarea ? (
        <textarea
          value={value ?? ""}
          onChange={(e) => onChange(e.target.value)}
          rows={3}
          className="w-full bg-neutral-900 border border-neutral-700 rounded-lg px-4 py-2.5"
        />
      ) : (
        <input
          value={value ?? ""}
          onChange={(e) => onChange(e.target.value)}
          className="w-full bg-neutral-900 border border-neutral-700 rounded-lg px-4 py-2.5"
        />
      )}
    </div>
  );
}

export default function SectionEditor({
  type,
  initialData,
  onSave,
  onClose
}: {
  type: string;
  initialData: any;
  onSave: (data: any) => void;
  onClose: () => void;
}) {
  const [data, setData] = useState<any>(initialData || {});

  function update(key: string, value: any) {
    setData((prev: any) => ({ ...prev, [key]: value }));
  }

  function updateListItem(key: string, index: number, field: string, value: any) {
    const list = [...(data[key] || [])];
    list[index] = { ...list[index], [field]: value };
    update(key, list);
  }

  function addListItem(key: string, blank: any) {
    update(key, [...(data[key] || []), blank]);
  }

  function removeListItem(key: string, index: number) {
    const list = [...(data[key] || [])];
    list.splice(index, 1);
    update(key, list);
  }

  return (
    <div className="fixed inset-0 z-[180] flex justify-end bg-black/60" onClick={onClose}>
      <div className="w-full max-w-lg bg-neutral-950 border-l border-neutral-800 h-full overflow-y-auto p-6" onClick={(e) => e.stopPropagation()}>
        <div className="flex justify-between items-center mb-6">
          <h2 className="text-lg font-semibold">Edit {SECTION_LABELS[type] || type} Section</h2>
          <button onClick={onClose} className="text-neutral-400 hover:text-white text-xl">
            ✕
          </button>
        </div>

        <div className="space-y-4">
          {type === "hero" && (
            <>
              <TextInput label="Heading" value={data.heading} onChange={(v) => update("heading", v)} />
              <TextInput label="Subheading" value={data.subheading} onChange={(v) => update("subheading", v)} textarea />
              <ImageUploadField label="Background Image" value={data.backgroundImage} onChange={(v) => update("backgroundImage", v)} />
              <TextInput label="Background Video URL (optional, overrides image)" value={data.backgroundVideo} onChange={(v) => update("backgroundVideo", v)} />
              <div>
                <label className="block text-sm mb-1 text-neutral-300">Overlay Opacity: {data.overlayOpacity ?? 55}%</label>
                <input
                  type="range"
                  min={0}
                  max={100}
                  value={data.overlayOpacity ?? 55}
                  onChange={(e) => update("overlayOpacity", Number(e.target.value))}
                  className="w-full"
                />
              </div>
              <div>
                <label className="block text-sm mb-1 text-neutral-300">Text Alignment</label>
                <select value={data.align ?? "center"} onChange={(e) => update("align", e.target.value)} className="w-full bg-neutral-900 border border-neutral-700 rounded-lg px-4 py-2.5">
                  <option value="left">Left</option>
                  <option value="center">Center</option>
                  <option value="right">Right</option>
                </select>
              </div>
              <TextInput label="Primary Button Text" value={data.primaryButtonText} onChange={(v) => update("primaryButtonText", v)} />
              <TextInput label="Secondary Button Text" value={data.secondaryButtonText} onChange={(v) => update("secondaryButtonText", v)} />
              <TextInput label="Secondary Button Link" value={data.secondaryButtonLink} onChange={(v) => update("secondaryButtonLink", v)} />
              <label className="flex items-center gap-2 text-sm text-neutral-300">
                <input type="checkbox" checked={data.secondaryButtonVisible !== false} onChange={(e) => update("secondaryButtonVisible", e.target.checked)} />
                Show secondary button
              </label>
            </>
          )}

          {type === "stats" && (
            <>
              <p className="text-sm text-neutral-400">Add, remove or reorder the numbers shown in the stats bar.</p>
              {(data.items || []).map((item: any, i: number) => (
                <div key={i} className="border border-neutral-800 rounded-lg p-3 space-y-2">
                  <div className="grid grid-cols-3 gap-2">
                    <input placeholder="Icon" value={item.icon ?? ""} onChange={(e) => updateListItem("items", i, "icon", e.target.value)} className="bg-neutral-900 border border-neutral-700 rounded-lg px-2 py-2 text-sm" />
                    <input placeholder="Number" value={item.number ?? ""} onChange={(e) => updateListItem("items", i, "number", e.target.value)} className="bg-neutral-900 border border-neutral-700 rounded-lg px-2 py-2 text-sm" />
                    <input placeholder="Label" value={item.label ?? ""} onChange={(e) => updateListItem("items", i, "label", e.target.value)} className="bg-neutral-900 border border-neutral-700 rounded-lg px-2 py-2 text-sm" />
                  </div>
                  <button onClick={() => removeListItem("items", i)} className="text-xs text-red-400 hover:underline">
                    Remove
                  </button>
                </div>
              ))}
              <button
                onClick={() => addListItem("items", { icon: "💪", number: "0", label: "New Stat" })}
                className="text-sm bg-neutral-800 hover:bg-neutral-700 px-3 py-2 rounded-lg"
              >
                + Add Stat
              </button>
            </>
          )}

          {type === "about" && (
            <>
              <TextInput label="Heading" value={data.heading} onChange={(v) => update("heading", v)} />
              <TextInput label="Description" value={data.description} onChange={(v) => update("description", v)} textarea />
              <ImageUploadField label="Main Image" value={data.image} onChange={(v) => update("image", v)} />
              <ImageUploadField label="Secondary Image (optional)" value={data.secondaryImage} onChange={(v) => update("secondaryImage", v)} />
              <TextInput label="Button Text" value={data.ctaText} onChange={(v) => update("ctaText", v)} />
              <TextInput label="Button Link" value={data.ctaLink} onChange={(v) => update("ctaLink", v)} />
            </>
          )}

          {type === "whyChooseUs" && (
            <>
              <TextInput label="Heading" value={data.heading} onChange={(v) => update("heading", v)} />
              {(data.cards || []).map((card: any, i: number) => (
                <div key={i} className="border border-neutral-800 rounded-lg p-3 space-y-2">
                  <input placeholder="Icon" value={card.icon ?? ""} onChange={(e) => updateListItem("cards", i, "icon", e.target.value)} className="w-full bg-neutral-900 border border-neutral-700 rounded-lg px-2 py-2 text-sm" />
                  <input placeholder="Title" value={card.title ?? ""} onChange={(e) => updateListItem("cards", i, "title", e.target.value)} className="w-full bg-neutral-900 border border-neutral-700 rounded-lg px-2 py-2 text-sm" />
                  <textarea placeholder="Description" value={card.description ?? ""} onChange={(e) => updateListItem("cards", i, "description", e.target.value)} className="w-full bg-neutral-900 border border-neutral-700 rounded-lg px-2 py-2 text-sm" />
                  <button onClick={() => removeListItem("cards", i)} className="text-xs text-red-400 hover:underline">
                    Remove
                  </button>
                </div>
              ))}
              <button
                onClick={() => addListItem("cards", { icon: "⭐", title: "New Feature", description: "" })}
                className="text-sm bg-neutral-800 hover:bg-neutral-700 px-3 py-2 rounded-lg"
              >
                + Add Card
              </button>
            </>
          )}

          {type === "cta" && (
            <>
              <TextInput label="Heading" value={data.heading} onChange={(v) => update("heading", v)} />
              <TextInput label="Description" value={data.description} onChange={(v) => update("description", v)} textarea />
              <TextInput label="Button Text" value={data.buttonText} onChange={(v) => update("buttonText", v)} />
              <ImageUploadField label="Background Image" value={data.backgroundImage} onChange={(v) => update("backgroundImage", v)} />
            </>
          )}

          {["programs", "facilities", "trainers", "transformations", "testimonials", "gallery", "faq", "location"].includes(type) && (
            <>
              <TextInput label="Section Heading (optional override)" value={data.heading} onChange={(v) => update("heading", v)} />
              <p className="text-xs text-neutral-500">
                The items shown here are managed in their own dedicated admin screen (e.g. Programs, Trainers). This section only controls the
                heading, visibility and position on the homepage.
              </p>
            </>
          )}
        </div>

        <div className="flex gap-3 mt-8">
          <button onClick={() => onSave(data)} className="flex-1 bg-lime-400 text-black font-semibold py-2.5 rounded-lg hover:bg-lime-300">
            Save Section
          </button>
          <button onClick={onClose} className="px-5 py-2.5 rounded-lg border border-neutral-700 text-neutral-300">
            Cancel
          </button>
        </div>
      </div>
    </div>
  );
}
