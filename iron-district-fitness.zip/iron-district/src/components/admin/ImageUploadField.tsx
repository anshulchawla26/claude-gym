"use client";

import { useState, useRef } from "react";
import Image from "next/image";
import toast from "react-hot-toast";

interface MediaItem {
  id: string;
  url: string;
  filename: string;
  type: string;
}

export default function ImageUploadField({
  label,
  value,
  onChange
}: {
  label: string;
  value: string | null | undefined;
  onChange: (url: string) => void;
}) {
  const [uploading, setUploading] = useState(false);
  const [pickerOpen, setPickerOpen] = useState(false);
  const [library, setLibrary] = useState<MediaItem[]>([]);
  const [loadingLibrary, setLoadingLibrary] = useState(false);
  const inputRef = useRef<HTMLInputElement>(null);

  async function handleUpload(file: File) {
    setUploading(true);
    const formData = new FormData();
    formData.append("file", file);

    try {
      const res = await fetch("/api/admin/media", { method: "POST", body: formData });
      const json = await res.json();
      if (!res.ok) {
        toast.error(json.message || "Upload failed");
        return;
      }
      onChange(json.url);
      toast.success("Image uploaded");
    } catch {
      toast.error("Upload failed — network error");
    } finally {
      setUploading(false);
    }
  }

  async function openPicker() {
    setPickerOpen(true);
    setLoadingLibrary(true);
    try {
      const res = await fetch("/api/admin/media");
      const json = await res.json();
      setLibrary(json.items || []);
    } catch {
      toast.error("Could not load media library");
    } finally {
      setLoadingLibrary(false);
    }
  }

  return (
    <div>
      <label className="block text-sm mb-1 text-neutral-300">{label}</label>
      <div className="flex items-center gap-3">
        <div className="w-20 h-20 rounded-lg bg-neutral-900 border border-neutral-700 overflow-hidden relative shrink-0">
          {value ? <Image src={value} alt="" fill className="object-cover" /> : null}
        </div>
        <div className="flex flex-col gap-2">
          <input
            ref={inputRef}
            type="file"
            accept="image/*"
            className="hidden"
            onChange={(e) => e.target.files?.[0] && handleUpload(e.target.files[0])}
          />
          <button
            type="button"
            onClick={() => inputRef.current?.click()}
            disabled={uploading}
            className="text-xs bg-neutral-800 hover:bg-neutral-700 px-3 py-1.5 rounded-lg disabled:opacity-60"
          >
            {uploading ? "Uploading..." : "Upload New"}
          </button>
          <button
            type="button"
            onClick={openPicker}
            className="text-xs bg-neutral-800 hover:bg-neutral-700 px-3 py-1.5 rounded-lg"
          >
            Browse Library
          </button>
        </div>
      </div>

      {pickerOpen && (
        <div className="fixed inset-0 z-[200] bg-black/70 flex items-center justify-center p-4" onClick={() => setPickerOpen(false)}>
          <div className="bg-neutral-950 border border-neutral-800 rounded-xl p-6 max-w-2xl w-full max-h-[80vh] overflow-y-auto" onClick={(e) => e.stopPropagation()}>
            <div className="flex justify-between items-center mb-4">
              <h3 className="font-semibold">Media Library</h3>
              <button onClick={() => setPickerOpen(false)} className="text-neutral-400 hover:text-white">✕</button>
            </div>
            {loadingLibrary ? (
              <p className="text-neutral-500 text-sm">Loading...</p>
            ) : library.length === 0 ? (
              <p className="text-neutral-500 text-sm">No media uploaded yet.</p>
            ) : (
              <div className="grid grid-cols-4 gap-3">
                {library.map((item) => (
                  <button
                    key={item.id}
                    onClick={() => {
                      onChange(item.url);
                      setPickerOpen(false);
                    }}
                    className="relative aspect-square rounded-lg overflow-hidden border border-neutral-800 hover:border-lime-400"
                  >
                    <Image src={item.url} alt={item.filename} fill className="object-cover" />
                  </button>
                ))}
              </div>
            )}
          </div>
        </div>
      )}
    </div>
  );
}
