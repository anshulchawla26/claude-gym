import { NextRequest, NextResponse } from "next/server";
import { prisma } from "@/lib/prisma";
import { leadSchema } from "@/lib/validations";
import { notifyNewLead } from "@/lib/notifications";
import { isRateLimited } from "@/lib/rateLimit";
import { getServerSession } from "next-auth";
import { authOptions } from "@/lib/auth";

// POST — public JOIN NOW form submission
export async function POST(req: NextRequest) {
  const ip = req.headers.get("x-forwarded-for") ?? "unknown";

  if (isRateLimited(`lead:${ip}`, 5, 60_000)) {
    return NextResponse.json(
      { message: "Too many submissions. Please wait a moment and try again." },
      { status: 429 }
    );
  }

  const body = await req.json().catch(() => null);
  if (!body) {
    return NextResponse.json({ message: "Invalid request body." }, { status: 400 });
  }

  // Honeypot: real visitors never populate this hidden field.
  if (body.website) {
    return NextResponse.json({ message: "Thank you!" }, { status: 200 });
  }

  const parsed = leadSchema.safeParse(body);
  if (!parsed.success) {
    const fieldErrors: Record<string, string> = {};
    for (const issue of parsed.error.issues) {
      fieldErrors[String(issue.path[0])] = issue.message;
    }
    return NextResponse.json(
      { message: "Please correct the highlighted fields.", fieldErrors },
      { status: 400 }
    );
  }

  const { fullName, mobile, email, gender, fitnessGoal } = parsed.data;

  // Prevent accidental duplicate double-submits: same mobile+email within 2 minutes.
  const recentDuplicate = await prisma.lead.findFirst({
    where: {
      mobile,
      email,
      createdAt: { gte: new Date(Date.now() - 2 * 60 * 1000) }
    }
  });

  if (recentDuplicate) {
    return NextResponse.json({ message: "Thank you! Your enquiry has been received." }, { status: 200 });
  }

  const lead = await prisma.lead.create({
    data: { fullName, mobile, email, gender, fitnessGoal }
  });

  // Fire-and-forget notification attempt — never blocks or fails the lead save.
  notifyNewLead({ name: fullName, mobile, email, gender, fitnessGoal }).catch(() => {});

  return NextResponse.json({ message: "Thank you! Your enquiry has been received.", id: lead.id }, { status: 201 });
}

// GET — admin lead listing with search/filter/pagination
export async function GET(req: NextRequest) {
  const session = await getServerSession(authOptions);
  if (!session) return NextResponse.json({ message: "Unauthorized" }, { status: 401 });

  const { searchParams } = new URL(req.url);
  const search = searchParams.get("search") || "";
  const status = searchParams.get("status") || "";
  const goal = searchParams.get("goal") || "";
  const page = Number(searchParams.get("page") || 1);
  const pageSize = Number(searchParams.get("pageSize") || 20);

  const where: any = {};
  if (status) where.status = status;
  if (goal) where.fitnessGoal = goal;
  if (search) {
    where.OR = [
      { fullName: { contains: search } },
      { mobile: { contains: search } },
      { email: { contains: search } }
    ];
  }

  const [items, total] = await Promise.all([
    prisma.lead.findMany({
      where,
      orderBy: { createdAt: "desc" },
      skip: (page - 1) * pageSize,
      take: pageSize
    }),
    prisma.lead.count({ where })
  ]);

  return NextResponse.json({ items, total, page, pageSize });
}
