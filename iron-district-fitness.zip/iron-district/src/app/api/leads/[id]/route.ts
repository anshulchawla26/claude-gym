import { NextRequest, NextResponse } from "next/server";
import { prisma } from "@/lib/prisma";
import { getServerSession } from "next-auth";
import { authOptions } from "@/lib/auth";
import { logAction } from "@/lib/audit";

export async function PATCH(req: NextRequest, { params }: { params: { id: string } }) {
  const session = await getServerSession(authOptions);
  if (!session) return NextResponse.json({ message: "Unauthorized" }, { status: 401 });

  const body = await req.json().catch(() => ({}));
  const data: any = {};
  if (body.status) data.status = body.status;
  if (typeof body.notes === "string") data.notes = body.notes;

  const lead = await prisma.lead.update({ where: { id: params.id }, data });

  await logAction((session.user as any).id, "lead_status_changed", `Lead ${lead.id} -> ${JSON.stringify(data)}`);

  return NextResponse.json(lead);
}

export async function DELETE(_req: NextRequest, { params }: { params: { id: string } }) {
  const session = await getServerSession(authOptions);
  if (!session) return NextResponse.json({ message: "Unauthorized" }, { status: 401 });
  if ((session.user as any).role === "STAFF") {
    return NextResponse.json({ message: "Forbidden" }, { status: 403 });
  }

  await prisma.lead.delete({ where: { id: params.id } });
  await logAction((session.user as any).id, "lead_deleted", params.id);

  return NextResponse.json({ ok: true });
}
