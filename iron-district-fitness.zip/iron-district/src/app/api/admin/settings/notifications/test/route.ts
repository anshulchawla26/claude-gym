import { NextRequest, NextResponse } from "next/server";
import { getServerSession } from "next-auth";
import { authOptions, roleCan } from "@/lib/auth";
import { prisma } from "@/lib/prisma";
import { sendWhatsAppMessage, renderTemplate } from "@/lib/notifications/whatsapp";
import { sendEmail } from "@/lib/notifications/email";

export async function POST(req: NextRequest) {
  const session = await getServerSession(authOptions);
  if (!session) return NextResponse.json({ message: "Unauthorized" }, { status: 401 });
  if (!roleCan((session.user as any).role, "settings:edit")) {
    return NextResponse.json({ message: "Forbidden" }, { status: 403 });
  }

  const body = await req.json().catch(() => ({}));
  const channel = body.channel as "whatsapp" | "email";

  const settings = await prisma.notificationSettings.findUnique({ where: { id: "default" } });
  if (!settings) return NextResponse.json({ message: "Notification settings not found." }, { status: 404 });

  const testVars = { name: "Test Lead", mobile: "+91 90000 00000", email: "test@example.com", gender: "Male", fitnessGoal: "General Fitness" };

  if (channel === "whatsapp") {
    if (!settings.whatsappEnabled || !settings.whatsappNumber) {
      return NextResponse.json({ sent: false, reason: "disabled", message: "WhatsApp notifications are not enabled or no number is configured." });
    }
    const message = renderTemplate(settings.whatsappTemplate, testVars);
    const result = await sendWhatsAppMessage({ toNumber: settings.whatsappNumber, message, provider: settings.whatsappProvider });
    if (!result.sent && result.reason === "not_configured") {
      return NextResponse.json({ sent: false, reason: "not_configured", message: "WhatsApp notifications are not configured. Add WHATSAPP_API_TOKEN and WHATSAPP_PHONE_NUMBER_ID to your environment." });
    }
    return NextResponse.json(result);
  }

  if (channel === "email") {
    if (!settings.emailEnabled || !settings.destinationEmail) {
      return NextResponse.json({ sent: false, reason: "disabled", message: "Email notifications are not enabled or no destination email is configured." });
    }
    const body2 = renderTemplate(settings.emailTemplate, testVars);
    const result = await sendEmail(settings.destinationEmail, "Test Notification — Iron District Fitness", body2);
    if (!result.sent && result.reason === "not_configured") {
      return NextResponse.json({ sent: false, reason: "not_configured", message: "Email notifications are not configured. Add SMTP_HOST, SMTP_USER and SMTP_PASSWORD to your environment." });
    }
    return NextResponse.json(result);
  }

  return NextResponse.json({ message: "Unknown channel." }, { status: 400 });
}
