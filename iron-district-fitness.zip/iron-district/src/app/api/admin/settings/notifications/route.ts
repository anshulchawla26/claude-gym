import { NextRequest, NextResponse } from "next/server";
import { getServerSession } from "next-auth";
import { authOptions, roleCan } from "@/lib/auth";
import { prisma } from "@/lib/prisma";
import { logAction } from "@/lib/audit";

export async function GET() {
  const session = await getServerSession(authOptions);
  if (!session) return NextResponse.json({ message: "Unauthorized" }, { status: 401 });

  const settings = await prisma.notificationSettings.upsert({ where: { id: "default" }, update: {}, create: { id: "default" } });

  return NextResponse.json({
    ...settings,
    whatsappConfigured: !!(process.env.WHATSAPP_API_TOKEN && process.env.WHATSAPP_PHONE_NUMBER_ID),
    emailConfigured: !!(process.env.SMTP_HOST && process.env.SMTP_USER && process.env.SMTP_PASSWORD)
  });
}

export async function PATCH(req: NextRequest) {
  const session = await getServerSession(authOptions);
  if (!session) return NextResponse.json({ message: "Unauthorized" }, { status: 401 });
  if (!roleCan((session.user as any).role, "settings:edit")) {
    return NextResponse.json({ message: "Forbidden" }, { status: 403 });
  }

  const body = await req.json().catch(() => ({}));
  delete body.id;
  delete body.whatsappConfigured;
  delete body.emailConfigured;

  const settings = await prisma.notificationSettings.upsert({
    where: { id: "default" },
    update: body,
    create: { id: "default", ...body }
  });

  await logAction((session.user as any).id, "notification_settings_updated");
  return NextResponse.json(settings);
}
