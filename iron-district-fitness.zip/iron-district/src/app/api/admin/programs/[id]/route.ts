import { makeItemHandlers } from "@/lib/crud";

export const { PATCH, DELETE } = makeItemHandlers({
  modelName: "program",
  auditLabel: "Program"
});
