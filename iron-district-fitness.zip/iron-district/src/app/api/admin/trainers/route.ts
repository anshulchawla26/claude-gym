import { makeListCreateHandlers } from "@/lib/crud";

export const { GET, POST } = makeListCreateHandlers({
  modelName: "trainer",
  auditLabel: "Trainer",
  jsonArrayFields: ["specializations", "certifications"]
});
