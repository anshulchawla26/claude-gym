import { NextRequest, NextResponse } from "next/server";
import { getServerSession } from "next-auth";
import { authOptions, roleCan } from "@/lib/auth";
import { prisma } from "@/lib/prisma";
import { logAction } from "@/lib/audit";

export async function GET() {
  const session = await getServerSession(authOptions);
  if (!session) return NextResponse.json({ message: "Unauthorized" }, { status: 401 });

  const pages = await prisma.page.findMany({
    orderBy: { createdAt: "asc" },
    include: { sections: { where: { type: "richtext" }, take: 1 } }
  });

  const items = pages.map((p) => {
    const richtext = p.sections[0];
    let content = "";
    if (richtext) {
      try {
        content = JSON.parse(richtext.data).content ?? "";
      } catch {
        content = "";
      }
    }
    return { ...p, sections: undefined, content };
  });

  return NextResponse.json({ items });
}

export async function POST(req: NextRequest) {
  const session = await getServerSession(authOptions);
  if (!session) return NextResponse.json({ message: "Unauthorized" }, { status: 401 });
  if (!roleCan((session.user as any).role, "website:edit")) {
    return NextResponse.json({ message: "Forbidden" }, { status: 403 });
  }

  const body = await req.json().catch(() => ({}));
  if (!body.title || !body.slug) {
    return NextResponse.json({ message: "Title and slug are required." }, { status: 400 });
  }

  const existing = await prisma.page.findUnique({ where: { slug: body.slug } });
  if (existing) return NextResponse.json({ message: "A page with this slug already exists." }, { status: 400 });

  const page = await prisma.page.create({
    data: {
      title: body.title,
      slug: body.slug,
      published: body.published ?? true,
      seoTitle: body.seoTitle,
      seoDescription: body.seoDescription
    }
  });

  if (body.content) {
    await prisma.pageSection.create({
      data: { pageId: page.id, type: "richtext", order: 0, visible: true, data: JSON.stringify({ heading: body.title, content: body.content }) }
    });
  }

  await logAction((session.user as any).id, "page_created", page.slug);

  return NextResponse.json(page, { status: 201 });
}
