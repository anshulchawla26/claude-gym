import { NextRequest, NextResponse } from "next/server";
import { getServerSession } from "next-auth";
import { authOptions, roleCan } from "@/lib/auth";
import { prisma } from "@/lib/prisma";
import { logAction } from "@/lib/audit";

export async function PATCH(req: NextRequest, { params }: { params: { id: string } }) {
  const session = await getServerSession(authOptions);
  if (!session) return NextResponse.json({ message: "Unauthorized" }, { status: 401 });
  if (!roleCan((session.user as any).role, "website:edit")) {
    return NextResponse.json({ message: "Forbidden" }, { status: 403 });
  }

  const body = await req.json().catch(() => ({}));
  const data: any = {};
  for (const key of ["title", "published", "seoTitle", "seoDescription", "ogImage", "canonicalUrl", "robots"]) {
    if (body[key] !== undefined) data[key] = body[key];
  }
  // Slug changes are allowed but must stay unique; system pages keep their slug.
  const page = await prisma.page.findUnique({ where: { id: params.id } });
  if (!page) return NextResponse.json({ message: "Not found" }, { status: 404 });

  if (body.slug && body.slug !== page.slug && !page.isSystem) {
    const clash = await prisma.page.findUnique({ where: { slug: body.slug } });
    if (clash) return NextResponse.json({ message: "A page with this slug already exists." }, { status: 400 });
    data.slug = body.slug;
  }

  const updated = await prisma.page.update({ where: { id: params.id }, data });

  if (typeof body.content === "string") {
    const richtext = await prisma.pageSection.findFirst({ where: { pageId: page.id, type: "richtext" } });
    if (richtext) {
      await prisma.pageSection.update({
        where: { id: richtext.id },
        data: { data: JSON.stringify({ heading: updated.title, content: body.content }) }
      });
    } else {
      await prisma.pageSection.create({
        data: { pageId: page.id, type: "richtext", order: 0, visible: true, data: JSON.stringify({ heading: updated.title, content: body.content }) }
      });
    }
  }

  await logAction((session.user as any).id, "page_updated", updated.slug);

  return NextResponse.json(updated);
}

export async function DELETE(_req: NextRequest, { params }: { params: { id: string } }) {
  const session = await getServerSession(authOptions);
  if (!session) return NextResponse.json({ message: "Unauthorized" }, { status: 401 });
  if (!roleCan((session.user as any).role, "website:edit")) {
    return NextResponse.json({ message: "Forbidden" }, { status: 403 });
  }

  const page = await prisma.page.findUnique({ where: { id: params.id } });
  if (!page) return NextResponse.json({ message: "Not found" }, { status: 404 });
  if (page.isSystem) return NextResponse.json({ message: "System pages cannot be deleted." }, { status: 400 });

  await prisma.page.delete({ where: { id: params.id } });
  await logAction((session.user as any).id, "page_deleted", page.slug);

  return NextResponse.json({ ok: true });
}
