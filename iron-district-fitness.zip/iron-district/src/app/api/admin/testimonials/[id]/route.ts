import { makeItemHandlers } from "@/lib/crud";

export const { PATCH, DELETE } = makeItemHandlers({
  modelName: "testimonial",
  auditLabel: "Testimonial"
});
