import { NextRequest, NextResponse } from "next/server";
import { getServerSession } from "next-auth";
import { authOptions, roleCan } from "@/lib/auth";
import { prisma } from "@/lib/prisma";
import { logAction } from "@/lib/audit";
import { unlink } from "fs/promises";
import path from "path";

export async function DELETE(_req: NextRequest, { params }: { params: { id: string } }) {
  const session = await getServerSession(authOptions);
  if (!session) return NextResponse.json({ message: "Unauthorized" }, { status: 401 });
  if (!roleCan((session.user as any).role, "media:edit")) {
    return NextResponse.json({ message: "Forbidden" }, { status: 403 });
  }

  const media = await prisma.media.findUnique({ where: { id: params.id } });
  if (!media) return NextResponse.json({ message: "Not found" }, { status: 404 });

  await prisma.media.delete({ where: { id: params.id } });

  try {
    if (media.url.startsWith("/uploads/")) {
      await unlink(path.join(process.cwd(), "public", media.url));
    }
  } catch {
    // File already missing on disk — safe to ignore.
  }

  await logAction((session.user as any).id, "media_deleted", params.id);

  return NextResponse.json({ ok: true });
}
