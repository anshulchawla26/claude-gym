import { NextRequest, NextResponse } from "next/server";
import { getServerSession } from "next-auth";
import { authOptions, roleCan } from "@/lib/auth";
import { prisma } from "@/lib/prisma";
import { logAction } from "@/lib/audit";
import { writeFile, mkdir } from "fs/promises";
import path from "path";
import crypto from "crypto";

const UPLOAD_DIR = path.join(process.cwd(), "public", "uploads");
const MAX_SIZE = 15 * 1024 * 1024; // 15MB
const ALLOWED_TYPES = ["image/jpeg", "image/png", "image/webp", "image/gif", "image/svg+xml", "video/mp4", "video/webm"];

export async function GET() {
  const session = await getServerSession(authOptions);
  if (!session) return NextResponse.json({ message: "Unauthorized" }, { status: 401 });

  const items = await prisma.media.findMany({ orderBy: { createdAt: "desc" } });
  return NextResponse.json({ items });
}

export async function POST(req: NextRequest) {
  const session = await getServerSession(authOptions);
  if (!session) return NextResponse.json({ message: "Unauthorized" }, { status: 401 });
  if (!roleCan((session.user as any).role, "media:edit")) {
    return NextResponse.json({ message: "Forbidden" }, { status: 403 });
  }

  const formData = await req.formData().catch(() => null);
  const file = formData?.get("file") as File | null;
  const category = (formData?.get("category") as string) || "General";

  if (!file) return NextResponse.json({ message: "No file provided." }, { status: 400 });

  if (!ALLOWED_TYPES.includes(file.type)) {
    return NextResponse.json({ message: "Unsupported file type." }, { status: 400 });
  }
  if (file.size > MAX_SIZE) {
    return NextResponse.json({ message: "File is too large (15MB max)." }, { status: 400 });
  }

  try {
    await mkdir(UPLOAD_DIR, { recursive: true });

    const ext = path.extname(file.name) || (file.type.startsWith("video") ? ".mp4" : ".jpg");
    const filename = `${Date.now()}-${crypto.randomBytes(6).toString("hex")}${ext}`;
    const filePath = path.join(UPLOAD_DIR, filename);

    const bytes = Buffer.from(await file.arrayBuffer());
    await writeFile(filePath, bytes);

    const media = await prisma.media.create({
      data: {
        url: `/uploads/${filename}`,
        filename: file.name,
        type: file.type.startsWith("video") ? "video" : "image",
        category
      }
    });

    await logAction((session.user as any).id, "media_uploaded", media.id);

    return NextResponse.json(media, { status: 201 });
  } catch (err: any) {
    return NextResponse.json({ message: `Upload failed: ${err?.message ?? "unknown error"}` }, { status: 500 });
  }
}
