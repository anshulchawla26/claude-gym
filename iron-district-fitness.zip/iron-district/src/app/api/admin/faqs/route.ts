import { makeListCreateHandlers } from "@/lib/crud";

export const { GET, POST } = makeListCreateHandlers({
  modelName: "fAQ",
  auditLabel: "FAQ"
});
