import { makeListCreateHandlers } from "@/lib/crud";

export const { GET, POST } = makeListCreateHandlers({
  modelName: "galleryItem",
  auditLabel: "GalleryItem"
});
