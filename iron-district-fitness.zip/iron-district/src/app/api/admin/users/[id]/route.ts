import { NextRequest, NextResponse } from "next/server";
import { getServerSession } from "next-auth";
import { authOptions } from "@/lib/auth";
import { prisma } from "@/lib/prisma";
import { logAction } from "@/lib/audit";
import bcrypt from "bcryptjs";

export async function PATCH(req: NextRequest, { params }: { params: { id: string } }) {
  const session = await getServerSession(authOptions);
  if (!session) return NextResponse.json({ message: "Unauthorized" }, { status: 401 });
  if ((session.user as any).role !== "SUPER_ADMIN") {
    return NextResponse.json({ message: "Only Super Admins can edit users." }, { status: 403 });
  }

  const body = await req.json().catch(() => ({}));
  const data: any = {};
  if (body.name) data.name = body.name;
  if (body.role) data.role = body.role;
  if (typeof body.active === "boolean") data.active = body.active;
  if (body.password) {
    if (body.password.length < 8) return NextResponse.json({ message: "Password must be at least 8 characters." }, { status: 400 });
    data.password = await bcrypt.hash(body.password, 10);
  }

  const user = await prisma.user.update({ where: { id: params.id }, data });
  await logAction((session.user as any).id, "user_updated", user.email);

  return NextResponse.json({ id: user.id, name: user.name, email: user.email, role: user.role, active: user.active });
}

export async function DELETE(_req: NextRequest, { params }: { params: { id: string } }) {
  const session = await getServerSession(authOptions);
  if (!session) return NextResponse.json({ message: "Unauthorized" }, { status: 401 });
  if ((session.user as any).role !== "SUPER_ADMIN") {
    return NextResponse.json({ message: "Only Super Admins can delete users." }, { status: 403 });
  }
  if ((session.user as any).id === params.id) {
    return NextResponse.json({ message: "You cannot delete your own account." }, { status: 400 });
  }

  const user = await prisma.user.delete({ where: { id: params.id } });
  await logAction((session.user as any).id, "user_deleted", user.email);

  return NextResponse.json({ ok: true });
}
