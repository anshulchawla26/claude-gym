import { NextRequest, NextResponse } from "next/server";
import { getServerSession } from "next-auth";
import { authOptions } from "@/lib/auth";
import { prisma } from "@/lib/prisma";
import { logAction } from "@/lib/audit";
import bcrypt from "bcryptjs";

export async function GET() {
  const session = await getServerSession(authOptions);
  if (!session) return NextResponse.json({ message: "Unauthorized" }, { status: 401 });

  const users = await prisma.user.findMany({
    orderBy: { createdAt: "asc" },
    select: { id: true, name: true, email: true, role: true, active: true, createdAt: true }
  });

  return NextResponse.json({ items: users });
}

export async function POST(req: NextRequest) {
  const session = await getServerSession(authOptions);
  if (!session) return NextResponse.json({ message: "Unauthorized" }, { status: 401 });
  if ((session.user as any).role !== "SUPER_ADMIN") {
    return NextResponse.json({ message: "Only Super Admins can create users." }, { status: 403 });
  }

  const body = await req.json().catch(() => ({}));
  if (!body.name || !body.email || !body.password || !body.role) {
    return NextResponse.json({ message: "Name, email, password and role are required." }, { status: 400 });
  }
  if (body.password.length < 8) {
    return NextResponse.json({ message: "Password must be at least 8 characters." }, { status: 400 });
  }

  const existing = await prisma.user.findUnique({ where: { email: body.email.toLowerCase() } });
  if (existing) return NextResponse.json({ message: "A user with this email already exists." }, { status: 400 });

  const hashed = await bcrypt.hash(body.password, 10);

  const user = await prisma.user.create({
    data: { name: body.name, email: body.email.toLowerCase(), password: hashed, role: body.role }
  });

  await logAction((session.user as any).id, "user_created", user.email);

  return NextResponse.json({ id: user.id, name: user.name, email: user.email, role: user.role, active: user.active }, { status: 201 });
}
