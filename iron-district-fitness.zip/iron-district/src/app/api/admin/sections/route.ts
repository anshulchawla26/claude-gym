import { NextRequest, NextResponse } from "next/server";
import { getServerSession } from "next-auth";
import { authOptions, roleCan } from "@/lib/auth";
import { prisma } from "@/lib/prisma";
import { logAction } from "@/lib/audit";

async function getHomePageId() {
  const page = await prisma.page.upsert({
    where: { slug: "home" },
    update: {},
    create: { title: "Home", slug: "home", isSystem: true }
  });
  return page.id;
}

export async function GET() {
  const session = await getServerSession(authOptions);
  if (!session) return NextResponse.json({ message: "Unauthorized" }, { status: 401 });

  const pageId = await getHomePageId();
  const sections = await prisma.pageSection.findMany({ where: { pageId }, orderBy: { order: "asc" } });

  return NextResponse.json({ items: sections });
}

export async function POST(req: NextRequest) {
  const session = await getServerSession(authOptions);
  if (!session) return NextResponse.json({ message: "Unauthorized" }, { status: 401 });
  if (!roleCan((session.user as any).role, "website:edit")) {
    return NextResponse.json({ message: "Forbidden" }, { status: 403 });
  }

  const body = await req.json().catch(() => null);
  if (!body?.type) return NextResponse.json({ message: "Section type is required." }, { status: 400 });

  const pageId = await getHomePageId();
  const count = await prisma.pageSection.count({ where: { pageId } });

  const section = await prisma.pageSection.create({
    data: {
      pageId,
      type: body.type,
      order: count,
      visible: true,
      data: JSON.stringify(body.data ?? {})
    }
  });

  await logAction((session.user as any).id, "section_added", `${body.type} (${section.id})`);

  return NextResponse.json(section, { status: 201 });
}
