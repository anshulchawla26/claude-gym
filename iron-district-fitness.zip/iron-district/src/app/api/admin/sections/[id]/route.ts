import { NextRequest, NextResponse } from "next/server";
import { getServerSession } from "next-auth";
import { authOptions, roleCan } from "@/lib/auth";
import { prisma } from "@/lib/prisma";
import { logAction } from "@/lib/audit";

async function requireEdit() {
  const session = await getServerSession(authOptions);
  if (!session) return { ok: false as const, res: NextResponse.json({ message: "Unauthorized" }, { status: 401 }) };
  if (!roleCan((session.user as any).role, "website:edit")) {
    return { ok: false as const, res: NextResponse.json({ message: "Forbidden" }, { status: 403 }) };
  }
  return { ok: true as const, session };
}

export async function PATCH(req: NextRequest, { params }: { params: { id: string } }) {
  const check = await requireEdit();
  if (!check.ok) return check.res;

  const body = await req.json().catch(() => ({}));
  const data: any = {};
  if (typeof body.visible === "boolean") data.visible = body.visible;
  if (typeof body.order === "number") data.order = body.order;
  if (body.data !== undefined) data.data = JSON.stringify(body.data);

  const section = await prisma.pageSection.update({ where: { id: params.id }, data });
  await logAction((check.session.user as any).id, "section_updated", section.id);

  return NextResponse.json(section);
}

export async function DELETE(_req: NextRequest, { params }: { params: { id: string } }) {
  const check = await requireEdit();
  if (!check.ok) return check.res;

  await prisma.pageSection.delete({ where: { id: params.id } });
  await logAction((check.session.user as any).id, "section_deleted", params.id);

  return NextResponse.json({ ok: true });
}

export async function POST(req: NextRequest, { params }: { params: { id: string } }) {
  // Duplicate a section
  const check = await requireEdit();
  if (!check.ok) return check.res;

  const original = await prisma.pageSection.findUnique({ where: { id: params.id } });
  if (!original) return NextResponse.json({ message: "Not found" }, { status: 404 });

  const count = await prisma.pageSection.count({ where: { pageId: original.pageId } });

  const copy = await prisma.pageSection.create({
    data: {
      pageId: original.pageId,
      type: original.type,
      order: count,
      visible: original.visible,
      data: original.data
    }
  });

  await logAction((check.session.user as any).id, "section_duplicated", `${original.id} -> ${copy.id}`);

  return NextResponse.json(copy, { status: 201 });
}
