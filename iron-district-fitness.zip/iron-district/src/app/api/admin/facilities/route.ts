import { makeListCreateHandlers } from "@/lib/crud";

export const { GET, POST } = makeListCreateHandlers({
  modelName: "facility",
  auditLabel: "Facility"
});
