import { prisma } from "@/lib/prisma";
import PageBanner from "@/components/public/PageBanner";
import Location from "@/components/public/Location";
import FAQAccordion from "@/components/public/FAQAccordion";
import { getSiteSettings } from "@/lib/site-data";

export const metadata = { title: "Contact Us" };

function safeParse<T>(json: string, fallback: T): T {
  try {
    return JSON.parse(json);
  } catch {
    return fallback;
  }
}

export default async function ContactPage() {
  const [site, faqs] = await Promise.all([
    getSiteSettings(),
    prisma.fAQ.findMany({ where: { visible: true }, orderBy: { order: "asc" } })
  ]);

  return (
    <>
      <PageBanner title="Contact Us" subtitle="We'd love to hear from you." />
      <Location
        gymName={site?.gymName ?? "Iron District Fitness"}
        address={site?.address ?? ""}
        phone={site?.phone ?? ""}
        email={site?.email ?? ""}
        whatsapp={site?.whatsapp ?? ""}
        mapEmbedUrl={site?.mapEmbedUrl}
        mapLink={site?.mapLink}
        openingHours={safeParse(site?.openingHours ?? "[]", [])}
      />
      <FAQAccordion heading="Common Questions" items={faqs} />
    </>
  );
}
