import { prisma } from "@/lib/prisma";
import SectionRenderer from "@/components/public/SectionRenderer";

export default async function HomePage() {
  const page = await prisma.page.findUnique({
    where: { slug: "home" },
    include: { sections: true }
  });

  return <SectionRenderer sections={page?.sections ?? []} />;
}
