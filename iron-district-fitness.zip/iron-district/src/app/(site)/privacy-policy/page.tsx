import { prisma } from "@/lib/prisma";
import SectionRenderer from "@/components/public/SectionRenderer";
import { notFound } from "next/navigation";

export const metadata = { title: "Privacy Policy" };

export default async function PrivacyPolicyPage() {
  const page = await prisma.page.findUnique({ where: { slug: "privacy-policy" }, include: { sections: true } });
  if (!page || !page.published) notFound();
  return <SectionRenderer sections={page.sections} />;
}
