import { prisma } from "@/lib/prisma";
import SectionRenderer from "@/components/public/SectionRenderer";
import { notFound } from "next/navigation";

export const metadata = { title: "Terms & Conditions" };

export default async function TermsPage() {
  const page = await prisma.page.findUnique({ where: { slug: "terms" }, include: { sections: true } });
  if (!page || !page.published) notFound();
  return <SectionRenderer sections={page.sections} />;
}
