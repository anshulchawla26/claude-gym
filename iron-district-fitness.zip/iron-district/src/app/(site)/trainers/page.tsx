import { prisma } from "@/lib/prisma";
import PageBanner from "@/components/public/PageBanner";
import Trainers from "@/components/public/Trainers";

export const metadata = { title: "Trainers" };

function safeParse<T>(json: string, fallback: T): T {
  try {
    return JSON.parse(json);
  } catch {
    return fallback;
  }
}

export default async function TrainersPage() {
  const trainers = await prisma.trainer.findMany({ where: { visible: true }, orderBy: { order: "asc" } });

  return (
    <>
      <PageBanner title="Our Trainers" subtitle="Certified coaches dedicated to your progress." />
      <Trainers
        heading="The Team"
        trainers={trainers.map((t) => ({ ...t, specializations: safeParse<string[]>(t.specializations, []) }))}
      />
    </>
  );
}
