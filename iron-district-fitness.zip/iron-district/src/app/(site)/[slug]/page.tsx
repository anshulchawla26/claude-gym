import { prisma } from "@/lib/prisma";
import SectionRenderer from "@/components/public/SectionRenderer";
import { notFound } from "next/navigation";
import type { Metadata } from "next";

const RESERVED_SLUGS = ["about", "programs", "trainers", "gallery", "contact", "privacy-policy", "terms", "admin", "api"];

export async function generateMetadata({ params }: { params: { slug: string } }): Promise<Metadata> {
  const page = await prisma.page.findUnique({ where: { slug: params.slug } });
  return {
    title: page?.seoTitle || page?.title || "Page",
    description: page?.seoDescription || undefined
  };
}

export default async function CustomPage({ params }: { params: { slug: string } }) {
  if (RESERVED_SLUGS.includes(params.slug)) notFound();

  const page = await prisma.page.findUnique({ where: { slug: params.slug }, include: { sections: true } });
  if (!page || !page.published) notFound();

  return <SectionRenderer sections={page.sections} />;
}
