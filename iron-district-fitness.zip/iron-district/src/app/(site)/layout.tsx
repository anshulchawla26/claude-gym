import type { Metadata } from "next";
import "../globals.css";
import { getSiteSettings, getThemeSettings, getNavigation, getPopupSettings, getAnnouncementBar, themeToCssVars } from "@/lib/site-data";
import Header from "@/components/public/Header";
import Footer from "@/components/public/Footer";
import AnnouncementBar from "@/components/public/AnnouncementBar";
import Popup from "@/components/public/Popup";
import StickyMobileBar from "@/components/public/StickyMobileBar";
import JoinNowModal from "@/components/public/JoinNowModal";
import { JoinNowProvider } from "@/components/public/JoinNowContext";

export async function generateMetadata(): Promise<Metadata> {
  const site = await getSiteSettings();
  return {
    title: site ? `${site.gymName} — ${site.tagline}` : "Iron District Fitness",
    description: site?.tagline ?? "Train Hard. Transform Fully.",
    icons: site?.faviconUrl ? [{ rel: "icon", url: site.faviconUrl }] : undefined
  };
}

export default async function RootLayout({ children }: { children: React.ReactNode }) {
  const [site, theme, navItems, popup, announcement] = await Promise.all([
    getSiteSettings(),
    getThemeSettings(),
    getNavigation(),
    getPopupSettings(),
    getAnnouncementBar()
  ]);

  const cssVars = theme ? themeToCssVars(theme) : {};
  const googleFonts = [theme?.headingFont, theme?.bodyFont]
    .filter(Boolean)
    .map((f) => (f as string).replace(/ /g, "+"))
    .join("&family=");

  return (
    <html lang="en">
      <head>
        {googleFonts && (
          <link
            href={`https://fonts.googleapis.com/css2?family=${googleFonts}:wght@400;500;600;700;800&display=swap`}
            rel="stylesheet"
          />
        )}
      </head>
      <body style={cssVars as React.CSSProperties}>
        <JoinNowProvider>
          {announcement?.enabled && (
            <AnnouncementBar
              text={announcement.text}
              linkText={announcement.linkText}
              linkUrl={announcement.linkUrl}
              background={announcement.background}
              textColor={announcement.textColor}
            />
          )}

          <Header gymName={site?.gymName ?? "Iron District Fitness"} logoUrl={site?.logoUrl} navItems={navItems} />

          <main className="pb-16 lg:pb-0">{children}</main>

          <Footer
            gymName={site?.gymName ?? "Iron District Fitness"}
            description={site?.tagline ?? ""}
            navItems={navItems}
            phone={site?.phone ?? ""}
            email={site?.email ?? ""}
            address={site?.address ?? ""}
            instagram={site?.instagram}
            facebook={site?.facebook}
            youtube={site?.youtube}
            copyrightText={site?.copyrightText ?? ""}
          />

          <StickyMobileBar phone={site?.phone ?? ""} whatsapp={site?.whatsapp ?? ""} />

          {popup?.enabled && (
            <Popup
              heading={popup.heading}
              description={popup.description}
              image={popup.image}
              buttonText={popup.buttonText}
              delaySeconds={popup.delaySeconds}
              frequency={popup.frequency}
              desktopVisible={popup.desktopVisible}
              mobileVisible={popup.mobileVisible}
            />
          )}

          <JoinNowModal whatsapp={site?.whatsapp} />
        </JoinNowProvider>
      </body>
    </html>
  );
}
