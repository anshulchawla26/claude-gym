import { prisma } from "@/lib/prisma";
import PageBanner from "@/components/public/PageBanner";
import Programs from "@/components/public/Programs";
import CTA from "@/components/public/CTA";

export const metadata = { title: "Programs" };

export default async function ProgramsPage() {
  const programs = await prisma.program.findMany({ where: { visible: true }, orderBy: { order: "asc" } });

  return (
    <>
      <PageBanner title="Our Programs" subtitle="Structured training paths for every goal, built and run by real coaches." />
      <Programs
        heading="Choose Your Path"
        programs={programs.map((p) => ({
          id: p.id,
          name: p.name,
          slug: p.slug,
          shortDesc: p.shortDesc,
          image: p.image,
          icon: p.icon,
          ctaText: p.ctaText,
          ctaLink: p.ctaLink
        }))}
      />
      <CTA data={{ heading: "Not Sure Where to Start?", description: "Talk to our team and we'll match you to the right program.", buttonText: "JOIN NOW" }} />
    </>
  );
}
