import { prisma } from "@/lib/prisma";
import Image from "next/image";
import { notFound } from "next/navigation";
import JoinNowButton from "@/components/public/JoinNowButton";
import type { Metadata } from "next";

export async function generateMetadata({ params }: { params: { slug: string } }): Promise<Metadata> {
  const program = await prisma.program.findUnique({ where: { slug: params.slug } });
  return { title: program?.name ?? "Program" };
}

export async function generateStaticParams() {
  const programs = await prisma.program.findMany({ where: { visible: true }, select: { slug: true } });
  return programs.map((p) => ({ slug: p.slug }));
}

export default async function ProgramDetailPage({ params }: { params: { slug: string } }) {
  const program = await prisma.program.findUnique({ where: { slug: params.slug } });
  if (!program || !program.visible) notFound();

  return (
    <article>
      <section className="relative h-[50vh] min-h-[320px]">
        {program.image ? (
          <Image src={program.image} alt={program.name} fill className="object-cover" priority />
        ) : (
          <div className="w-full h-full bg-surface" />
        )}
        <div className="absolute inset-0 bg-black/60 flex items-center">
          <div className="max-w-container mx-auto px-6 md:px-8">
            <div className="text-4xl mb-3">{program.icon}</div>
            <h1 className="font-heading-theme uppercase text-4xl md:text-6xl">{program.name}</h1>
          </div>
        </div>
      </section>

      <section className="section-spacing max-w-3xl mx-auto px-6">
        <p className="text-text-muted text-lg leading-relaxed whitespace-pre-line mb-10">{program.fullDesc}</p>
        <JoinNowButton label={program.ctaText || "JOIN NOW"} />
      </section>
    </article>
  );
}
