import { prisma } from "@/lib/prisma";
import PageBanner from "@/components/public/PageBanner";
import Gallery from "@/components/public/Gallery";

export const metadata = { title: "Gallery" };

export default async function GalleryPage() {
  const items = await prisma.galleryItem.findMany({ where: { visible: true }, orderBy: { order: "asc" } });

  return (
    <>
      <PageBanner title="Gallery" subtitle="A look inside the gym." />
      <Gallery heading="Photo Gallery" items={items} />
    </>
  );
}
