import { prisma } from "@/lib/prisma";
import PageBanner from "@/components/public/PageBanner";
import About, { AboutData } from "@/components/public/About";
import WhyChooseUs from "@/components/public/WhyChooseUs";
import Trainers from "@/components/public/Trainers";
import { getSiteSettings } from "@/lib/site-data";

function safeParse<T>(json: string, fallback: T): T {
  try {
    return JSON.parse(json);
  } catch {
    return fallback;
  }
}

export const metadata = { title: "About Us" };

export default async function AboutPage() {
  const [homePage, trainers, site] = await Promise.all([
    prisma.page.findUnique({ where: { slug: "home" }, include: { sections: true } }),
    prisma.trainer.findMany({ where: { visible: true }, orderBy: { order: "asc" } }),
    getSiteSettings()
  ]);

  const aboutSection = homePage?.sections.find((s) => s.type === "about");
  const whySection = homePage?.sections.find((s) => s.type === "whyChooseUs");

  const aboutData: AboutData = aboutSection
    ? safeParse(aboutSection.data, { heading: "About Us", description: "" })
    : { heading: `About ${site?.gymName ?? "Us"}`, description: site?.tagline ?? "" };

  return (
    <>
      <PageBanner title="About Us" subtitle={site?.tagline ?? undefined} />
      <About data={aboutData} />
      {whySection && <WhyChooseUs data={safeParse(whySection.data, { cards: [] })} />}
      <Trainers
        heading="Meet Our Team"
        trainers={trainers.map((t) => ({ ...t, specializations: safeParse<string[]>(t.specializations, []) }))}
      />
    </>
  );
}
