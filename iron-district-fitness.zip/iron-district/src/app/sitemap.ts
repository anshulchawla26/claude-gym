import { MetadataRoute } from "next";
import { prisma } from "@/lib/prisma";

export default async function sitemap(): Promise<MetadataRoute.Sitemap> {
  const base = process.env.NEXTAUTH_URL || "http://localhost:3000";

  const [pages, programs] = await Promise.all([
    prisma.page.findMany({ where: { published: true } }),
    prisma.program.findMany({ where: { visible: true } })
  ]);

  const pageEntries = pages.map((p) => ({
    url: p.slug === "home" ? base : `${base}/${p.slug}`,
    lastModified: p.updatedAt
  }));

  const programEntries = programs.map((p) => ({
    url: `${base}/programs/${p.slug}`,
    lastModified: p.updatedAt
  }));

  return [...pageEntries, ...programEntries];
}
