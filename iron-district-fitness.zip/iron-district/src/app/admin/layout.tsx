import type { Metadata } from "next";
import AdminProviders from "@/components/admin/AdminProviders";
import "../globals.css";

export const metadata: Metadata = {
  title: "Admin — Iron District Fitness",
  robots: "noindex, nofollow"
};

// This is the ROOT layout for everything under /admin (its own <html>/<body>,
// separate from the public site's root layout). It intentionally does NOT
// check auth or render the sidebar — the login page lives directly under
// here (public), while every other admin page lives under the sibling
// (protected) route group, which enforces the session check.
export default function AdminRootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="en" className="dark">
      <body className="bg-neutral-900 text-white font-sans">
        <AdminProviders>{children}</AdminProviders>
      </body>
    </html>
  );
}
