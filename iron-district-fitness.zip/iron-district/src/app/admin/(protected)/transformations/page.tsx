"use client";

import EntityManager from "@/components/admin/EntityManager";

export default function TransformationsAdminPage() {
  return (
    <EntityManager
      title="Transformations"
      description="Before/after member transformations. Hide this section entirely from the Website Builder if you'd rather not show it."
      apiBase="/api/admin/transformations"
      emptyMessage="No transformations added yet."
      defaultValues={{
        beforeImage: "",
        afterImage: "",
        memberName: "",
        goal: "",
        duration: "",
        description: "",
        visible: true
      }}
      columns={[
        { key: "memberName", label: "Member" },
        { key: "goal", label: "Goal" },
        { key: "duration", label: "Duration" }
      ]}
      fields={[
        { name: "memberName", label: "Member Name", type: "text", required: true },
        { name: "beforeImage", label: "Before Image", type: "image", required: true },
        { name: "afterImage", label: "After Image", type: "image", required: true },
        { name: "goal", label: "Goal", type: "text", required: true },
        { name: "duration", label: "Duration", type: "text", required: true, helpText: "e.g. 12 weeks" },
        { name: "description", label: "Description", type: "textarea" },
        { name: "visible", label: "Visible on site", type: "checkbox" }
      ]}
    />
  );
}
