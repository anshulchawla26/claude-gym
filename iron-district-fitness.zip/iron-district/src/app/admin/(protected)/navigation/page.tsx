"use client";

import EntityManager from "@/components/admin/EntityManager";

export default function NavigationAdminPage() {
  return (
    <EntityManager
      title="Navigation"
      description="Header and footer navigation links."
      apiBase="/api/admin/navigation"
      emptyMessage="No navigation items yet."
      defaultValues={{ label: "", url: "/", visible: true }}
      columns={[
        { key: "label", label: "Label" },
        { key: "url", label: "URL" }
      ]}
      fields={[
        { name: "label", label: "Label", type: "text", required: true },
        { name: "url", label: "URL", type: "text", required: true, helpText: "e.g. /programs or #contact" },
        { name: "visible", label: "Visible", type: "checkbox" }
      ]}
    />
  );
}
