"use client";

import { useEffect, useState } from "react";
import toast from "react-hot-toast";
import ImageUploadField from "@/components/admin/ImageUploadField";

interface Page {
  id: string;
  title: string;
  slug: string;
  seoTitle: string | null;
  seoDescription: string | null;
  ogImage: string | null;
  canonicalUrl: string | null;
  robots: string;
}

export default function SEOAdminPage() {
  const [pages, setPages] = useState<Page[]>([]);
  const [active, setActive] = useState<Page | null>(null);
  const [saving, setSaving] = useState(false);

  useEffect(() => {
    fetch("/api/admin/pages")
      .then((r) => r.json())
      .then((json) => setPages(json.items || []));
  }, []);

  function update(key: string, value: any) {
    setActive((prev) => (prev ? { ...prev, [key]: value } : prev));
  }

  async function save() {
    if (!active) return;
    setSaving(true);
    try {
      await fetch(`/api/admin/pages/${active.id}`, {
        method: "PATCH",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          seoTitle: active.seoTitle,
          seoDescription: active.seoDescription,
          ogImage: active.ogImage,
          canonicalUrl: active.canonicalUrl,
          robots: active.robots
        })
      });
      toast.success("SEO settings saved");
      setPages((prev) => prev.map((p) => (p.id === active.id ? active : p)));
    } finally {
      setSaving(false);
    }
  }

  return (
    <div>
      <h1 className="text-2xl font-bold mb-1">SEO</h1>
      <p className="text-neutral-400 text-sm mb-8">Meta tags for search engines and social sharing, per page.</p>

      <div className="grid md:grid-cols-3 gap-6">
        <div className="bg-neutral-950 border border-neutral-800 rounded-xl overflow-hidden">
          {pages.map((page) => (
            <button
              key={page.id}
              onClick={() => setActive(page)}
              className={`w-full text-left px-4 py-3 border-b border-neutral-900 text-sm ${active?.id === page.id ? "bg-neutral-900 text-lime-400" : "hover:bg-neutral-900/50"}`}
            >
              {page.title}
            </button>
          ))}
        </div>

        <div className="md:col-span-2">
          {!active ? (
            <div className="text-neutral-500 text-sm">Select a page to edit its SEO settings.</div>
          ) : (
            <div className="space-y-4 bg-neutral-950 border border-neutral-800 rounded-xl p-6">
              <div>
                <label className="block text-sm mb-1 text-neutral-300">Meta Title</label>
                <input value={active.seoTitle ?? ""} onChange={(e) => update("seoTitle", e.target.value)} className="w-full bg-neutral-900 border border-neutral-700 rounded-lg px-4 py-2.5" />
              </div>
              <div>
                <label className="block text-sm mb-1 text-neutral-300">Meta Description</label>
                <textarea value={active.seoDescription ?? ""} onChange={(e) => update("seoDescription", e.target.value)} rows={3} className="w-full bg-neutral-900 border border-neutral-700 rounded-lg px-4 py-2.5" />
              </div>
              <ImageUploadField label="Open Graph Image" value={active.ogImage} onChange={(v) => update("ogImage", v)} />
              <div>
                <label className="block text-sm mb-1 text-neutral-300">Canonical URL</label>
                <input value={active.canonicalUrl ?? ""} onChange={(e) => update("canonicalUrl", e.target.value)} className="w-full bg-neutral-900 border border-neutral-700 rounded-lg px-4 py-2.5" />
              </div>
              <div>
                <label className="block text-sm mb-1 text-neutral-300">Robots</label>
                <select value={active.robots ?? "index, follow"} onChange={(e) => update("robots", e.target.value)} className="w-full bg-neutral-900 border border-neutral-700 rounded-lg px-4 py-2.5">
                  <option value="index, follow">index, follow</option>
                  <option value="noindex, follow">noindex, follow</option>
                  <option value="index, nofollow">index, nofollow</option>
                  <option value="noindex, nofollow">noindex, nofollow</option>
                </select>
              </div>
              <button onClick={save} disabled={saving} className="bg-lime-400 text-black font-semibold px-6 py-2.5 rounded-lg hover:bg-lime-300 disabled:opacity-60">
                {saving ? "Saving..." : "Save SEO Settings"}
              </button>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
