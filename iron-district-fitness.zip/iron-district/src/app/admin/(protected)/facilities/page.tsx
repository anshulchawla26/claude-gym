"use client";

import EntityManager from "@/components/admin/EntityManager";

export default function FacilitiesAdminPage() {
  return (
    <EntityManager
      title="Facilities"
      description="Gym facilities and amenities shown on the homepage."
      apiBase="/api/admin/facilities"
      emptyMessage="No facilities added yet."
      defaultValues={{ name: "", description: "", image: "", icon: "🏢", visible: true }}
      columns={[
        { key: "name", label: "Name" },
        { key: "description", label: "Description" }
      ]}
      fields={[
        { name: "name", label: "Name", type: "text", required: true },
        { name: "description", label: "Description", type: "textarea", required: true },
        { name: "image", label: "Image", type: "image" },
        { name: "icon", label: "Icon (emoji)", type: "text" },
        { name: "visible", label: "Visible on site", type: "checkbox" }
      ]}
    />
  );
}
