"use client";

import { useEffect, useState } from "react";
import toast from "react-hot-toast";

export default function AnnouncementSettingsPage() {
  const [settings, setSettings] = useState<any>(null);
  const [saving, setSaving] = useState(false);

  useEffect(() => {
    fetch("/api/admin/settings/announcement")
      .then((r) => r.json())
      .then(setSettings);
  }, []);

  function update(key: string, value: any) {
    setSettings((prev: any) => ({ ...prev, [key]: value }));
  }

  async function save() {
    setSaving(true);
    try {
      const res = await fetch("/api/admin/settings/announcement", {
        method: "PATCH",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(settings)
      });
      if (!res.ok) throw new Error();
      toast.success("Announcement bar saved");
    } catch {
      toast.error("Failed to save");
    } finally {
      setSaving(false);
    }
  }

  if (!settings) return <div className="text-neutral-500">Loading...</div>;

  return (
    <div className="max-w-xl space-y-6">
      <div>
        <h1 className="text-2xl font-bold mb-1">Announcement Bar</h1>
        <p className="text-neutral-400 text-sm">A thin banner across the top of the site.</p>
      </div>

      <label className="flex items-center gap-2 text-sm">
        <input type="checkbox" checked={!!settings.enabled} onChange={(e) => update("enabled", e.target.checked)} />
        Enable announcement bar
      </label>

      <div>
        <label className="block text-sm mb-1 text-neutral-300">Text</label>
        <input value={settings.text ?? ""} onChange={(e) => update("text", e.target.value)} className="w-full bg-neutral-900 border border-neutral-700 rounded-lg px-4 py-2.5" />
      </div>
      <div>
        <label className="block text-sm mb-1 text-neutral-300">Link Button Text</label>
        <input value={settings.linkText ?? ""} onChange={(e) => update("linkText", e.target.value)} className="w-full bg-neutral-900 border border-neutral-700 rounded-lg px-4 py-2.5" />
      </div>
      <div>
        <label className="block text-sm mb-1 text-neutral-300">Link URL</label>
        <input value={settings.linkUrl ?? ""} onChange={(e) => update("linkUrl", e.target.value)} placeholder="#join-now" className="w-full bg-neutral-900 border border-neutral-700 rounded-lg px-4 py-2.5" />
        <p className="text-xs text-neutral-500 mt-1">Use #join-now to open the JOIN NOW form directly.</p>
      </div>
      <div className="grid grid-cols-2 gap-4">
        <div>
          <label className="block text-sm mb-1 text-neutral-300">Background Color</label>
          <input type="color" value={settings.background ?? "#e6ff2b"} onChange={(e) => update("background", e.target.value)} className="w-full h-10 rounded bg-transparent border border-neutral-700" />
        </div>
        <div>
          <label className="block text-sm mb-1 text-neutral-300">Text Color</label>
          <input type="color" value={settings.textColor ?? "#0a0a0a"} onChange={(e) => update("textColor", e.target.value)} className="w-full h-10 rounded bg-transparent border border-neutral-700" />
        </div>
      </div>

      <button onClick={save} disabled={saving} className="bg-lime-400 text-black font-semibold px-6 py-2.5 rounded-lg hover:bg-lime-300 disabled:opacity-60">
        {saving ? "Saving..." : "Save Announcement Bar"}
      </button>
    </div>
  );
}
