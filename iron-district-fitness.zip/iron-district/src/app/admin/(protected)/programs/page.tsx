"use client";

import EntityManager from "@/components/admin/EntityManager";

export default function ProgramsAdminPage() {
  return (
    <EntityManager
      title="Programs"
      description="Training programs shown on the homepage and /programs."
      apiBase="/api/admin/programs"
      emptyMessage="No programs added yet."
      defaultValues={{
        name: "",
        slug: "",
        shortDesc: "",
        fullDesc: "",
        image: "",
        icon: "🏋️",
        ctaText: "Learn More",
        ctaLink: "/programs",
        visible: true
      }}
      columns={[
        { key: "name", label: "Name" },
        { key: "slug", label: "Slug" },
        { key: "shortDesc", label: "Short Description" }
      ]}
      fields={[
        { name: "name", label: "Name", type: "text", required: true },
        { name: "slug", label: "Slug (URL)", type: "text", required: true, helpText: "Lowercase, letters/numbers/dashes only, e.g. strength-training" },
        { name: "shortDesc", label: "Short Description", type: "textarea", required: true },
        { name: "fullDesc", label: "Full Description", type: "textarea", required: true },
        { name: "image", label: "Image", type: "image" },
        { name: "icon", label: "Icon (emoji)", type: "text" },
        { name: "ctaText", label: "Button Text", type: "text" },
        { name: "ctaLink", label: "Button Link", type: "text" },
        { name: "visible", label: "Visible on site", type: "checkbox" }
      ]}
    />
  );
}
