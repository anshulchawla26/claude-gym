"use client";

import { useEffect, useRef, useState } from "react";
import Image from "next/image";
import toast from "react-hot-toast";

interface MediaItem {
  id: string;
  url: string;
  filename: string;
  type: string;
  category: string;
  createdAt: string;
}

export default function MediaLibraryPage() {
  const [items, setItems] = useState<MediaItem[]>([]);
  const [loading, setLoading] = useState(true);
  const [search, setSearch] = useState("");
  const [uploading, setUploading] = useState(false);
  const inputRef = useRef<HTMLInputElement>(null);

  async function load() {
    setLoading(true);
    try {
      const res = await fetch("/api/admin/media");
      const json = await res.json();
      setItems(json.items || []);
    } catch {
      toast.error("Failed to load media");
    } finally {
      setLoading(false);
    }
  }

  useEffect(() => {
    load();
  }, []);

  async function handleUpload(files: FileList) {
    setUploading(true);
    for (const file of Array.from(files)) {
      const formData = new FormData();
      formData.append("file", file);
      try {
        const res = await fetch("/api/admin/media", { method: "POST", body: formData });
        if (!res.ok) {
          const json = await res.json();
          toast.error(json.message || `Failed to upload ${file.name}`);
        }
      } catch {
        toast.error(`Failed to upload ${file.name}`);
      }
    }
    setUploading(false);
    load();
  }

  async function handleDelete(item: MediaItem) {
    if (!confirm(`Delete "${item.filename}"? Pages using this image will show a broken image.`)) return;
    const res = await fetch(`/api/admin/media/${item.id}`, { method: "DELETE" });
    if (!res.ok) {
      toast.error("Delete failed");
      return;
    }
    toast.success("Deleted");
    load();
  }

  const filtered = items.filter((i) => i.filename.toLowerCase().includes(search.toLowerCase()));

  return (
    <div>
      <div className="flex items-start justify-between mb-6 flex-wrap gap-4">
        <div>
          <h1 className="text-2xl font-bold">Media Library</h1>
          <p className="text-neutral-400 text-sm mt-1">All images and videos uploaded across the site.</p>
        </div>
        <div>
          <input ref={inputRef} type="file" multiple accept="image/*,video/mp4,video/webm" className="hidden" onChange={(e) => e.target.files && handleUpload(e.target.files)} />
          <button onClick={() => inputRef.current?.click()} disabled={uploading} className="bg-lime-400 text-black font-semibold px-4 py-2 rounded-lg hover:bg-lime-300 disabled:opacity-60">
            {uploading ? "Uploading..." : "+ Upload Media"}
          </button>
        </div>
      </div>

      <input
        value={search}
        onChange={(e) => setSearch(e.target.value)}
        placeholder="Search by filename..."
        className="bg-neutral-900 border border-neutral-700 rounded-lg px-4 py-2 text-sm mb-6 w-full max-w-sm"
      />

      {loading ? (
        <div className="text-neutral-500">Loading...</div>
      ) : filtered.length === 0 ? (
        <div className="text-neutral-500">No media uploaded yet.</div>
      ) : (
        <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-5 gap-4">
          {filtered.map((item) => (
            <div key={item.id} className="bg-neutral-950 border border-neutral-800 rounded-xl overflow-hidden group relative">
              <div className="relative aspect-square bg-neutral-900">
                {item.type === "video" ? (
                  <video src={item.url} className="w-full h-full object-cover" muted />
                ) : (
                  <Image src={item.url} alt={item.filename} fill className="object-cover" />
                )}
              </div>
              <div className="p-2">
                <div className="text-xs truncate">{item.filename}</div>
                <div className="text-[10px] text-neutral-500">{item.category}</div>
              </div>
              <button
                onClick={() => handleDelete(item)}
                className="absolute top-2 right-2 bg-black/70 hover:bg-red-500 text-white text-xs w-6 h-6 rounded-full opacity-0 group-hover:opacity-100 transition-opacity"
              >
                ✕
              </button>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}
