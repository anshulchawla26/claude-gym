"use client";

import EntityManager from "@/components/admin/EntityManager";

export default function FAQsAdminPage() {
  return (
    <EntityManager
      title="FAQs"
      description="Frequently asked questions shown on the homepage and contact page."
      apiBase="/api/admin/faqs"
      emptyMessage="No FAQs added yet."
      defaultValues={{ question: "", answer: "", visible: true }}
      columns={[
        { key: "question", label: "Question" },
        { key: "answer", label: "Answer" }
      ]}
      fields={[
        { name: "question", label: "Question", type: "text", required: true },
        { name: "answer", label: "Answer", type: "textarea", required: true },
        { name: "visible", label: "Visible on site", type: "checkbox" }
      ]}
    />
  );
}
