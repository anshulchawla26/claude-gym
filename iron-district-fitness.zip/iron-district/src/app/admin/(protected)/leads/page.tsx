"use client";

import { useEffect, useState, useCallback } from "react";
import toast from "react-hot-toast";

const STATUSES = ["NEW", "CONTACTED", "FOLLOW_UP", "CONVERTED", "NOT_INTERESTED"];
const GOALS = ["Weight Loss", "Muscle Gain", "Strength Training", "General Fitness", "Body Transformation", "Personal Training", "Other"];

const STATUS_COLORS: Record<string, string> = {
  NEW: "bg-blue-500/20 text-blue-400",
  CONTACTED: "bg-amber-500/20 text-amber-400",
  FOLLOW_UP: "bg-purple-500/20 text-purple-400",
  CONVERTED: "bg-lime-500/20 text-lime-400",
  NOT_INTERESTED: "bg-neutral-700 text-neutral-400"
};

interface Lead {
  id: string;
  fullName: string;
  mobile: string;
  email: string;
  gender: string;
  fitnessGoal: string;
  status: string;
  notes: string | null;
  createdAt: string;
}

export default function LeadsAdminPage() {
  const [leads, setLeads] = useState<Lead[]>([]);
  const [total, setTotal] = useState(0);
  const [page, setPage] = useState(1);
  const [search, setSearch] = useState("");
  const [status, setStatus] = useState("");
  const [goal, setGoal] = useState("");
  const [loading, setLoading] = useState(true);
  const [selected, setSelected] = useState<Lead | null>(null);
  const [notesDraft, setNotesDraft] = useState("");
  const pageSize = 20;

  const load = useCallback(async () => {
    setLoading(true);
    const params = new URLSearchParams({ page: String(page), pageSize: String(pageSize) });
    if (search) params.set("search", search);
    if (status) params.set("status", status);
    if (goal) params.set("goal", goal);

    try {
      const res = await fetch(`/api/leads?${params.toString()}`);
      const json = await res.json();
      setLeads(json.items || []);
      setTotal(json.total || 0);
    } catch {
      toast.error("Failed to load leads");
    } finally {
      setLoading(false);
    }
  }, [page, search, status, goal]);

  useEffect(() => {
    load();
  }, [load]);

  async function updateStatus(lead: Lead, newStatus: string) {
    await fetch(`/api/leads/${lead.id}`, {
      method: "PATCH",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ status: newStatus })
    });
    load();
    if (selected?.id === lead.id) setSelected({ ...lead, status: newStatus });
  }

  async function saveNotes() {
    if (!selected) return;
    await fetch(`/api/leads/${selected.id}`, {
      method: "PATCH",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ notes: notesDraft })
    });
    toast.success("Notes saved");
    load();
  }

  async function deleteLead(id: string) {
    if (!confirm("Delete this lead? This cannot be undone.")) return;
    await fetch(`/api/leads/${id}`, { method: "DELETE" });
    toast.success("Lead deleted");
    setSelected(null);
    load();
  }

  const totalPages = Math.max(1, Math.ceil(total / pageSize));

  return (
    <div>
      <div className="flex items-start justify-between mb-6 flex-wrap gap-4">
        <div>
          <h1 className="text-2xl font-bold">Leads</h1>
          <p className="text-neutral-400 text-sm mt-1">{total} total enquiries</p>
        </div>
        <a href="/api/leads/export" className="bg-lime-400 text-black font-semibold px-4 py-2 rounded-lg hover:bg-lime-300">
          Export CSV
        </a>
      </div>

      <div className="flex flex-wrap gap-3 mb-4">
        <input
          value={search}
          onChange={(e) => {
            setSearch(e.target.value);
            setPage(1);
          }}
          placeholder="Search name, mobile, email..."
          className="bg-neutral-900 border border-neutral-700 rounded-lg px-4 py-2 text-sm flex-1 min-w-[200px]"
        />
        <select
          value={status}
          onChange={(e) => {
            setStatus(e.target.value);
            setPage(1);
          }}
          className="bg-neutral-900 border border-neutral-700 rounded-lg px-4 py-2 text-sm"
        >
          <option value="">All Statuses</option>
          {STATUSES.map((s) => (
            <option key={s} value={s}>
              {s.replace("_", " ")}
            </option>
          ))}
        </select>
        <select
          value={goal}
          onChange={(e) => {
            setGoal(e.target.value);
            setPage(1);
          }}
          className="bg-neutral-900 border border-neutral-700 rounded-lg px-4 py-2 text-sm"
        >
          <option value="">All Goals</option>
          {GOALS.map((g) => (
            <option key={g} value={g}>
              {g}
            </option>
          ))}
        </select>
      </div>

      <div className="bg-neutral-950 border border-neutral-800 rounded-xl overflow-hidden overflow-x-auto">
        {loading ? (
          <div className="p-10 text-center text-neutral-500">Loading...</div>
        ) : leads.length === 0 ? (
          <div className="p-10 text-center text-neutral-500">No enquiries yet.</div>
        ) : (
          <table className="w-full text-sm min-w-[800px]">
            <thead>
              <tr className="border-b border-neutral-800 text-neutral-400 text-left">
                <th className="p-4">Name</th>
                <th className="p-4">Mobile</th>
                <th className="p-4">Email</th>
                <th className="p-4">Goal</th>
                <th className="p-4">Date</th>
                <th className="p-4">Status</th>
                <th className="p-4">Actions</th>
              </tr>
            </thead>
            <tbody>
              {leads.map((lead) => (
                <tr key={lead.id} className="border-b border-neutral-900 hover:bg-neutral-900/50">
                  <td className="p-4 cursor-pointer" onClick={() => { setSelected(lead); setNotesDraft(lead.notes || ""); }}>
                    {lead.fullName}
                  </td>
                  <td className="p-4">{lead.mobile}</td>
                  <td className="p-4">{lead.email}</td>
                  <td className="p-4">{lead.fitnessGoal}</td>
                  <td className="p-4">{new Date(lead.createdAt).toLocaleDateString()}</td>
                  <td className="p-4">
                    <select
                      value={lead.status}
                      onChange={(e) => updateStatus(lead, e.target.value)}
                      className={`text-xs rounded-full px-2 py-1 border-0 ${STATUS_COLORS[lead.status]}`}
                    >
                      {STATUSES.map((s) => (
                        <option key={s} value={s} className="bg-neutral-900 text-white">
                          {s.replace("_", " ")}
                        </option>
                      ))}
                    </select>
                  </td>
                  <td className="p-4">
                    <div className="flex gap-3 text-xs">
                      <a href={`tel:${lead.mobile}`} className="hover:text-lime-400">
                        Call
                      </a>
                      <a
                        href={`https://wa.me/${lead.mobile.replace(/[^\d]/g, "")}`}
                        target="_blank"
                        rel="noopener noreferrer"
                        className="hover:text-lime-400"
                      >
                        WhatsApp
                      </a>
                      <a href={`mailto:${lead.email}`} className="hover:text-lime-400">
                        Email
                      </a>
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        )}
      </div>

      {totalPages > 1 && (
        <div className="flex justify-center gap-2 mt-4">
          <button
            disabled={page <= 1}
            onClick={() => setPage((p) => p - 1)}
            className="px-3 py-1.5 rounded-lg border border-neutral-700 disabled:opacity-40 text-sm"
          >
            Previous
          </button>
          <span className="text-sm text-neutral-400 px-2 py-1.5">
            Page {page} of {totalPages}
          </span>
          <button
            disabled={page >= totalPages}
            onClick={() => setPage((p) => p + 1)}
            className="px-3 py-1.5 rounded-lg border border-neutral-700 disabled:opacity-40 text-sm"
          >
            Next
          </button>
        </div>
      )}

      {selected && (
        <div className="fixed inset-0 z-[150] flex justify-end bg-black/60" onClick={() => setSelected(null)}>
          <div className="w-full max-w-md bg-neutral-950 border-l border-neutral-800 h-full overflow-y-auto p-6" onClick={(e) => e.stopPropagation()}>
            <div className="flex justify-between items-center mb-6">
              <h2 className="text-lg font-semibold">Lead Details</h2>
              <button onClick={() => setSelected(null)} className="text-neutral-400 hover:text-white text-xl">
                ✕
              </button>
            </div>

            <div className="space-y-3 text-sm mb-6">
              <div>
                <div className="text-neutral-500">Name</div>
                <div>{selected.fullName}</div>
              </div>
              <div>
                <div className="text-neutral-500">Mobile</div>
                <div>{selected.mobile}</div>
              </div>
              <div>
                <div className="text-neutral-500">Email</div>
                <div>{selected.email}</div>
              </div>
              <div>
                <div className="text-neutral-500">Gender</div>
                <div>{selected.gender}</div>
              </div>
              <div>
                <div className="text-neutral-500">Fitness Goal</div>
                <div>{selected.fitnessGoal}</div>
              </div>
              <div>
                <div className="text-neutral-500">Submitted</div>
                <div>{new Date(selected.createdAt).toLocaleString()}</div>
              </div>
            </div>

            <div className="flex gap-3 mb-6">
              <a href={`tel:${selected.mobile}`} className="flex-1 text-center bg-neutral-800 hover:bg-neutral-700 py-2 rounded-lg text-sm">
                Call
              </a>
              <a
                href={`https://wa.me/${selected.mobile.replace(/[^\d]/g, "")}`}
                target="_blank"
                rel="noopener noreferrer"
                className="flex-1 text-center bg-neutral-800 hover:bg-neutral-700 py-2 rounded-lg text-sm"
              >
                WhatsApp
              </a>
              <a href={`mailto:${selected.email}`} className="flex-1 text-center bg-neutral-800 hover:bg-neutral-700 py-2 rounded-lg text-sm">
                Email
              </a>
            </div>

            <label className="block text-sm mb-1 text-neutral-300">Notes</label>
            <textarea
              value={notesDraft}
              onChange={(e) => setNotesDraft(e.target.value)}
              rows={5}
              className="w-full bg-neutral-900 border border-neutral-700 rounded-lg px-4 py-2.5 mb-3"
            />
            <button onClick={saveNotes} className="w-full bg-lime-400 text-black font-semibold py-2.5 rounded-lg hover:bg-lime-300 mb-3">
              Save Notes
            </button>
            <button
              onClick={() => deleteLead(selected.id)}
              className="w-full border border-red-500/50 text-red-400 py-2.5 rounded-lg hover:bg-red-500/10"
            >
              Delete Lead
            </button>
          </div>
        </div>
      )}
    </div>
  );
}
