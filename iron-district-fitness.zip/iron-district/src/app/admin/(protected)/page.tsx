import { prisma } from "@/lib/prisma";
import Link from "next/link";

function startOfDay(d: Date) {
  const x = new Date(d);
  x.setHours(0, 0, 0, 0);
  return x;
}
function startOfWeek(d: Date) {
  const x = startOfDay(d);
  const day = x.getDay();
  x.setDate(x.getDate() - day);
  return x;
}

export default async function AdminDashboard() {
  const now = new Date();
  const todayStart = startOfDay(now);
  const weekStart = startOfWeek(now);

  const [total, newCount, contacted, followUp, converted, today, thisWeek, recent] = await Promise.all([
    prisma.lead.count(),
    prisma.lead.count({ where: { status: "NEW" } }),
    prisma.lead.count({ where: { status: "CONTACTED" } }),
    prisma.lead.count({ where: { status: "FOLLOW_UP" } }),
    prisma.lead.count({ where: { status: "CONVERTED" } }),
    prisma.lead.count({ where: { createdAt: { gte: todayStart } } }),
    prisma.lead.count({ where: { createdAt: { gte: weekStart } } }),
    prisma.lead.findMany({ orderBy: { createdAt: "desc" }, take: 8 })
  ]);

  const conversionRate = total > 0 ? Math.round((converted / total) * 100) : 0;

  const cards = [
    { label: "Total Leads", value: total, color: "text-white" },
    { label: "New", value: newCount, color: "text-blue-400" },
    { label: "Contacted", value: contacted, color: "text-amber-400" },
    { label: "Follow-up", value: followUp, color: "text-purple-400" },
    { label: "Converted", value: converted, color: "text-lime-400" },
    { label: "Today", value: today, color: "text-white" },
    { label: "This Week", value: thisWeek, color: "text-white" },
    { label: "Conversion Rate", value: `${conversionRate}%`, color: "text-lime-400" }
  ];

  return (
    <div>
      <h1 className="text-2xl font-bold mb-1">Dashboard</h1>
      <p className="text-neutral-400 text-sm mb-8">Overview of your gym's enquiries and website activity.</p>

      <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-10">
        {cards.map((c) => (
          <div key={c.label} className="bg-neutral-950 border border-neutral-800 rounded-xl p-5">
            <div className={`text-3xl font-bold ${c.color}`}>{c.value}</div>
            <div className="text-neutral-400 text-sm mt-1">{c.label}</div>
          </div>
        ))}
      </div>

      <div className="flex flex-wrap gap-3 mb-10">
        <Link href="/admin/builder" className="bg-neutral-800 hover:bg-neutral-700 px-4 py-2 rounded-lg text-sm">
          🧱 Edit Homepage
        </Link>
        <Link href="/admin/programs" className="bg-neutral-800 hover:bg-neutral-700 px-4 py-2 rounded-lg text-sm">
          🏋️ Manage Programs
        </Link>
        <Link href="/admin/leads" className="bg-neutral-800 hover:bg-neutral-700 px-4 py-2 rounded-lg text-sm">
          📥 View All Leads
        </Link>
        <Link href="/admin/theme" className="bg-neutral-800 hover:bg-neutral-700 px-4 py-2 rounded-lg text-sm">
          🎨 Edit Theme
        </Link>
      </div>

      <div className="bg-neutral-950 border border-neutral-800 rounded-xl overflow-hidden">
        <div className="p-5 border-b border-neutral-800 flex items-center justify-between">
          <h2 className="font-semibold">Recent Enquiries</h2>
          <Link href="/admin/leads" className="text-sm text-lime-400 hover:underline">
            View all →
          </Link>
        </div>
        {recent.length === 0 ? (
          <div className="p-8 text-center text-neutral-500">No enquiries yet.</div>
        ) : (
          <table className="w-full text-sm">
            <thead>
              <tr className="text-neutral-400 text-left border-b border-neutral-900">
                <th className="p-4">Name</th>
                <th className="p-4">Goal</th>
                <th className="p-4">Status</th>
                <th className="p-4">Date</th>
              </tr>
            </thead>
            <tbody>
              {recent.map((lead) => (
                <tr key={lead.id} className="border-b border-neutral-900">
                  <td className="p-4">{lead.fullName}</td>
                  <td className="p-4">{lead.fitnessGoal}</td>
                  <td className="p-4">{lead.status.replace("_", " ")}</td>
                  <td className="p-4">{new Date(lead.createdAt).toLocaleDateString()}</td>
                </tr>
              ))}
            </tbody>
          </table>
        )}
      </div>
    </div>
  );
}
