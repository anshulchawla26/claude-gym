"use client";

import { useEffect, useState } from "react";
import toast from "react-hot-toast";
import ImageUploadField from "@/components/admin/ImageUploadField";

interface Hour {
  day: string;
  hours: string;
}

export default function GlobalSettingsPage() {
  const [settings, setSettings] = useState<any>(null);
  const [hours, setHours] = useState<Hour[]>([]);
  const [saving, setSaving] = useState(false);

  useEffect(() => {
    fetch("/api/admin/settings/site")
      .then((r) => r.json())
      .then((data) => {
        setSettings(data);
        try {
          setHours(JSON.parse(data.openingHours || "[]"));
        } catch {
          setHours([]);
        }
      });
  }, []);

  function update(key: string, value: any) {
    setSettings((prev: any) => ({ ...prev, [key]: value }));
  }

  function updateHour(i: number, field: keyof Hour, value: string) {
    const next = [...hours];
    next[i] = { ...next[i], [field]: value };
    setHours(next);
  }

  async function save() {
    setSaving(true);
    try {
      const res = await fetch("/api/admin/settings/site", {
        method: "PATCH",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ ...settings, openingHours: JSON.stringify(hours) })
      });
      if (!res.ok) throw new Error();
      toast.success("Settings updated");
    } catch {
      toast.error("Failed to save settings");
    } finally {
      setSaving(false);
    }
  }

  if (!settings) return <div className="text-neutral-500">Loading...</div>;

  return (
    <div className="max-w-2xl space-y-10">
      <div>
        <h1 className="text-2xl font-bold mb-1">Global Settings</h1>
        <p className="text-neutral-400 text-sm">Gym identity and contact details used across the entire website.</p>
      </div>

      <section className="space-y-4">
        <h2 className="font-semibold">Identity</h2>
        <div>
          <label className="block text-sm mb-1 text-neutral-300">Gym Name</label>
          <input value={settings.gymName ?? ""} onChange={(e) => update("gymName", e.target.value)} className="w-full bg-neutral-900 border border-neutral-700 rounded-lg px-4 py-2.5" />
        </div>
        <div>
          <label className="block text-sm mb-1 text-neutral-300">Tagline</label>
          <input value={settings.tagline ?? ""} onChange={(e) => update("tagline", e.target.value)} className="w-full bg-neutral-900 border border-neutral-700 rounded-lg px-4 py-2.5" />
        </div>
        <ImageUploadField label="Logo" value={settings.logoUrl} onChange={(v) => update("logoUrl", v)} />
        <ImageUploadField label="Favicon" value={settings.faviconUrl} onChange={(v) => update("faviconUrl", v)} />
      </section>

      <section className="space-y-4">
        <h2 className="font-semibold">Contact</h2>
        <div>
          <label className="block text-sm mb-1 text-neutral-300">Phone</label>
          <input value={settings.phone ?? ""} onChange={(e) => update("phone", e.target.value)} className="w-full bg-neutral-900 border border-neutral-700 rounded-lg px-4 py-2.5" />
        </div>
        <div>
          <label className="block text-sm mb-1 text-neutral-300">Email</label>
          <input value={settings.email ?? ""} onChange={(e) => update("email", e.target.value)} className="w-full bg-neutral-900 border border-neutral-700 rounded-lg px-4 py-2.5" />
        </div>
        <div>
          <label className="block text-sm mb-1 text-neutral-300">WhatsApp Number</label>
          <input value={settings.whatsapp ?? ""} onChange={(e) => update("whatsapp", e.target.value)} className="w-full bg-neutral-900 border border-neutral-700 rounded-lg px-4 py-2.5" />
        </div>
        <div>
          <label className="block text-sm mb-1 text-neutral-300">Address</label>
          <textarea value={settings.address ?? ""} onChange={(e) => update("address", e.target.value)} rows={2} className="w-full bg-neutral-900 border border-neutral-700 rounded-lg px-4 py-2.5" />
        </div>
        <div>
          <label className="block text-sm mb-1 text-neutral-300">Google Maps Embed URL</label>
          <input value={settings.mapEmbedUrl ?? ""} onChange={(e) => update("mapEmbedUrl", e.target.value)} className="w-full bg-neutral-900 border border-neutral-700 rounded-lg px-4 py-2.5" />
        </div>
        <div>
          <label className="block text-sm mb-1 text-neutral-300">Google Maps Directions Link</label>
          <input value={settings.mapLink ?? ""} onChange={(e) => update("mapLink", e.target.value)} className="w-full bg-neutral-900 border border-neutral-700 rounded-lg px-4 py-2.5" />
        </div>
      </section>

      <section className="space-y-4">
        <h2 className="font-semibold">Social</h2>
        <input placeholder="Instagram URL" value={settings.instagram ?? ""} onChange={(e) => update("instagram", e.target.value)} className="w-full bg-neutral-900 border border-neutral-700 rounded-lg px-4 py-2.5" />
        <input placeholder="Facebook URL" value={settings.facebook ?? ""} onChange={(e) => update("facebook", e.target.value)} className="w-full bg-neutral-900 border border-neutral-700 rounded-lg px-4 py-2.5" />
        <input placeholder="YouTube URL" value={settings.youtube ?? ""} onChange={(e) => update("youtube", e.target.value)} className="w-full bg-neutral-900 border border-neutral-700 rounded-lg px-4 py-2.5" />
      </section>

      <section className="space-y-3">
        <h2 className="font-semibold">Opening Hours</h2>
        {hours.map((h, i) => (
          <div key={i} className="flex gap-2">
            <input value={h.day} onChange={(e) => updateHour(i, "day", e.target.value)} placeholder="Day" className="flex-1 bg-neutral-900 border border-neutral-700 rounded-lg px-3 py-2 text-sm" />
            <input value={h.hours} onChange={(e) => updateHour(i, "hours", e.target.value)} placeholder="6:00 AM - 10:00 PM" className="flex-1 bg-neutral-900 border border-neutral-700 rounded-lg px-3 py-2 text-sm" />
            <button onClick={() => setHours(hours.filter((_, idx) => idx !== i))} className="text-red-400 text-sm px-2">
              ✕
            </button>
          </div>
        ))}
        <button onClick={() => setHours([...hours, { day: "Monday", hours: "6:00 AM - 10:00 PM" }])} className="text-sm bg-neutral-800 hover:bg-neutral-700 px-3 py-2 rounded-lg">
          + Add Day
        </button>
      </section>

      <section className="space-y-4">
        <h2 className="font-semibold">Footer</h2>
        <div>
          <label className="block text-sm mb-1 text-neutral-300">Copyright Text</label>
          <input value={settings.copyrightText ?? ""} onChange={(e) => update("copyrightText", e.target.value)} className="w-full bg-neutral-900 border border-neutral-700 rounded-lg px-4 py-2.5" />
        </div>
      </section>

      <button onClick={save} disabled={saving} className="bg-lime-400 text-black font-semibold px-6 py-2.5 rounded-lg hover:bg-lime-300 disabled:opacity-60">
        {saving ? "Saving..." : "Save Settings"}
      </button>
    </div>
  );
}
