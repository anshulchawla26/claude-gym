"use client";

import EntityManager from "@/components/admin/EntityManager";

export default function TrainersAdminPage() {
  return (
    <EntityManager
      title="Trainers"
      description="Your coaching team, shown on the homepage and /trainers."
      apiBase="/api/admin/trainers"
      emptyMessage="No trainers added yet."
      defaultValues={{
        name: "",
        photo: "",
        designation: "",
        experienceYears: 1,
        bio: "",
        specializations: [],
        certifications: [],
        instagram: "",
        facebook: "",
        otherSocial: "",
        visible: true
      }}
      columns={[
        { key: "name", label: "Name" },
        { key: "designation", label: "Designation" },
        { key: "experienceYears", label: "Experience (yrs)" }
      ]}
      fields={[
        { name: "name", label: "Name", type: "text", required: true },
        { name: "photo", label: "Photo", type: "image" },
        { name: "designation", label: "Designation", type: "text", required: true },
        { name: "experienceYears", label: "Experience (years)", type: "number" },
        { name: "bio", label: "Biography", type: "textarea", required: true },
        { name: "specializations", label: "Specializations", type: "tags" },
        { name: "certifications", label: "Certifications", type: "tags" },
        { name: "instagram", label: "Instagram URL", type: "text" },
        { name: "facebook", label: "Facebook URL", type: "text" },
        { name: "otherSocial", label: "Other Social URL", type: "text" },
        { name: "visible", label: "Visible on site", type: "checkbox" }
      ]}
    />
  );
}
