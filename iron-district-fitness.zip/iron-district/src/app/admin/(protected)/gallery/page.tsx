"use client";

import EntityManager from "@/components/admin/EntityManager";

export default function GalleryAdminPage() {
  return (
    <EntityManager
      title="Gallery"
      description="Photos shown in the site gallery, filterable by category."
      apiBase="/api/admin/gallery"
      emptyMessage="No gallery images added yet."
      defaultValues={{ image: "", caption: "", category: "General", visible: true }}
      columns={[
        { key: "caption", label: "Caption" },
        { key: "category", label: "Category" }
      ]}
      fields={[
        { name: "image", label: "Image", type: "image", required: true },
        { name: "caption", label: "Caption", type: "text" },
        { name: "category", label: "Category", type: "text", helpText: "e.g. Equipment, Classes, Events" },
        { name: "visible", label: "Visible on site", type: "checkbox" }
      ]}
    />
  );
}
