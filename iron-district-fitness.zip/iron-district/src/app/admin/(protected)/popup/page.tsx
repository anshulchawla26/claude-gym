"use client";

import { useEffect, useState } from "react";
import toast from "react-hot-toast";
import ImageUploadField from "@/components/admin/ImageUploadField";

export default function PopupSettingsPage() {
  const [settings, setSettings] = useState<any>(null);
  const [saving, setSaving] = useState(false);

  useEffect(() => {
    fetch("/api/admin/settings/popup")
      .then((r) => r.json())
      .then(setSettings);
  }, []);

  function update(key: string, value: any) {
    setSettings((prev: any) => ({ ...prev, [key]: value }));
  }

  async function save() {
    setSaving(true);
    try {
      const res = await fetch("/api/admin/settings/popup", {
        method: "PATCH",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(settings)
      });
      if (!res.ok) throw new Error();
      toast.success("Popup settings saved");
    } catch {
      toast.error("Failed to save");
    } finally {
      setSaving(false);
    }
  }

  if (!settings) return <div className="text-neutral-500">Loading...</div>;

  return (
    <div className="max-w-xl space-y-6">
      <div>
        <h1 className="text-2xl font-bold mb-1">Popup</h1>
        <p className="text-neutral-400 text-sm">A delayed popup that nudges visitors toward JOIN NOW.</p>
      </div>

      <label className="flex items-center gap-2 text-sm">
        <input type="checkbox" checked={!!settings.enabled} onChange={(e) => update("enabled", e.target.checked)} />
        Enable popup
      </label>

      <div>
        <label className="block text-sm mb-1 text-neutral-300">Heading</label>
        <input value={settings.heading ?? ""} onChange={(e) => update("heading", e.target.value)} className="w-full bg-neutral-900 border border-neutral-700 rounded-lg px-4 py-2.5" />
      </div>
      <div>
        <label className="block text-sm mb-1 text-neutral-300">Description</label>
        <textarea value={settings.description ?? ""} onChange={(e) => update("description", e.target.value)} rows={3} className="w-full bg-neutral-900 border border-neutral-700 rounded-lg px-4 py-2.5" />
      </div>
      <ImageUploadField label="Image (optional)" value={settings.image} onChange={(v) => update("image", v)} />
      <div>
        <label className="block text-sm mb-1 text-neutral-300">Button Text</label>
        <input value={settings.buttonText ?? ""} onChange={(e) => update("buttonText", e.target.value)} className="w-full bg-neutral-900 border border-neutral-700 rounded-lg px-4 py-2.5" />
      </div>
      <div>
        <label className="block text-sm mb-1 text-neutral-300">Delay (seconds)</label>
        <input type="number" value={settings.delaySeconds ?? 6} onChange={(e) => update("delaySeconds", Number(e.target.value))} className="w-full bg-neutral-900 border border-neutral-700 rounded-lg px-4 py-2.5" />
      </div>
      <div>
        <label className="block text-sm mb-1 text-neutral-300">Frequency</label>
        <select value={settings.frequency ?? "once_per_session"} onChange={(e) => update("frequency", e.target.value)} className="w-full bg-neutral-900 border border-neutral-700 rounded-lg px-4 py-2.5">
          <option value="once_per_session">Once per session</option>
          <option value="every_visit">Every visit</option>
        </select>
      </div>
      <div className="flex gap-6">
        <label className="flex items-center gap-2 text-sm">
          <input type="checkbox" checked={!!settings.desktopVisible} onChange={(e) => update("desktopVisible", e.target.checked)} />
          Show on desktop
        </label>
        <label className="flex items-center gap-2 text-sm">
          <input type="checkbox" checked={!!settings.mobileVisible} onChange={(e) => update("mobileVisible", e.target.checked)} />
          Show on mobile
        </label>
      </div>

      <button onClick={save} disabled={saving} className="bg-lime-400 text-black font-semibold px-6 py-2.5 rounded-lg hover:bg-lime-300 disabled:opacity-60">
        {saving ? "Saving..." : "Save Popup Settings"}
      </button>
    </div>
  );
}
