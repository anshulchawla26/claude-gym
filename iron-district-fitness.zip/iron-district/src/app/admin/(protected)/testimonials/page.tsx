"use client";

import EntityManager from "@/components/admin/EntityManager";

export default function TestimonialsAdminPage() {
  return (
    <EntityManager
      title="Testimonials"
      description="Member reviews shown on the homepage."
      apiBase="/api/admin/testimonials"
      emptyMessage="No testimonials added yet."
      defaultValues={{ name: "", photo: "", review: "", rating: 5, visible: true }}
      columns={[
        { key: "name", label: "Name" },
        { key: "review", label: "Review" },
        { key: "rating", label: "Rating" }
      ]}
      fields={[
        { name: "name", label: "Member Name", type: "text", required: true },
        { name: "photo", label: "Photo", type: "image" },
        { name: "review", label: "Review", type: "textarea", required: true },
        { name: "rating", label: "Rating (1-5)", type: "number" },
        { name: "visible", label: "Visible on site", type: "checkbox" }
      ]}
    />
  );
}
