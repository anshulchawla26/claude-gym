"use client";

import { useEffect, useState } from "react";
import toast from "react-hot-toast";

const COLOR_FIELDS = [
  ["colorPrimary", "Primary"],
  ["colorSecondary", "Secondary"],
  ["colorAccent", "Accent"],
  ["colorBackground", "Background"],
  ["colorSurface", "Surface"],
  ["colorText", "Text"],
  ["colorTextMuted", "Muted Text"],
  ["colorBorder", "Border"],
  ["colorButton", "Button"],
  ["colorButtonHover", "Button Hover"]
];

export default function ThemeSettingsPage() {
  const [theme, setTheme] = useState<any>(null);
  const [saving, setSaving] = useState(false);

  useEffect(() => {
    fetch("/api/admin/settings/theme")
      .then((r) => r.json())
      .then(setTheme);
  }, []);

  function update(key: string, value: any) {
    setTheme((prev: any) => ({ ...prev, [key]: value }));
  }

  async function save() {
    setSaving(true);
    try {
      const res = await fetch("/api/admin/settings/theme", {
        method: "PATCH",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(theme)
      });
      if (!res.ok) throw new Error();
      toast.success("Theme updated — changes are live on the site immediately.");
    } catch {
      toast.error("Failed to save theme");
    } finally {
      setSaving(false);
    }
  }

  if (!theme) return <div className="text-neutral-500">Loading...</div>;

  return (
    <div className="max-w-3xl">
      <h1 className="text-2xl font-bold mb-1">Theme / Design</h1>
      <p className="text-neutral-400 text-sm mb-8">
        Changing these values updates colors, fonts and spacing across the entire public website instantly.
      </p>

      <section className="mb-10">
        <h2 className="font-semibold mb-4">Colors</h2>
        <div className="grid grid-cols-2 md:grid-cols-3 gap-4">
          {COLOR_FIELDS.map(([key, label]) => (
            <div key={key}>
              <label className="block text-sm mb-1 text-neutral-300">{label}</label>
              <div className="flex items-center gap-2">
                <input type="color" value={theme[key] ?? "#000000"} onChange={(e) => update(key, e.target.value)} className="w-10 h-10 rounded bg-transparent border border-neutral-700" />
                <input value={theme[key] ?? ""} onChange={(e) => update(key, e.target.value)} className="flex-1 bg-neutral-900 border border-neutral-700 rounded-lg px-3 py-2 text-sm" />
              </div>
            </div>
          ))}
        </div>
      </section>

      <section className="mb-10">
        <h2 className="font-semibold mb-4">Typography</h2>
        <div className="grid grid-cols-2 gap-4">
          <div>
            <label className="block text-sm mb-1 text-neutral-300">Heading Font (Google Font name)</label>
            <input value={theme.headingFont ?? ""} onChange={(e) => update("headingFont", e.target.value)} className="w-full bg-neutral-900 border border-neutral-700 rounded-lg px-3 py-2 text-sm" />
          </div>
          <div>
            <label className="block text-sm mb-1 text-neutral-300">Body Font (Google Font name)</label>
            <input value={theme.bodyFont ?? ""} onChange={(e) => update("bodyFont", e.target.value)} className="w-full bg-neutral-900 border border-neutral-700 rounded-lg px-3 py-2 text-sm" />
          </div>
          <div>
            <label className="block text-sm mb-1 text-neutral-300">Base Font Size</label>
            <input value={theme.baseFontSize ?? ""} onChange={(e) => update("baseFontSize", e.target.value)} className="w-full bg-neutral-900 border border-neutral-700 rounded-lg px-3 py-2 text-sm" />
          </div>
          <div>
            <label className="block text-sm mb-1 text-neutral-300">Letter Spacing</label>
            <input value={theme.letterSpacing ?? ""} onChange={(e) => update("letterSpacing", e.target.value)} className="w-full bg-neutral-900 border border-neutral-700 rounded-lg px-3 py-2 text-sm" />
          </div>
        </div>
      </section>

      <section className="mb-10">
        <h2 className="font-semibold mb-4">Layout &amp; Shape</h2>
        <div className="grid grid-cols-2 gap-4">
          <div>
            <label className="block text-sm mb-1 text-neutral-300">Base Border Radius</label>
            <input value={theme.radiusBase ?? ""} onChange={(e) => update("radiusBase", e.target.value)} className="w-full bg-neutral-900 border border-neutral-700 rounded-lg px-3 py-2 text-sm" />
          </div>
          <div>
            <label className="block text-sm mb-1 text-neutral-300">Button Radius</label>
            <input value={theme.radiusButton ?? ""} onChange={(e) => update("radiusButton", e.target.value)} className="w-full bg-neutral-900 border border-neutral-700 rounded-lg px-3 py-2 text-sm" />
          </div>
          <div>
            <label className="block text-sm mb-1 text-neutral-300">Card Radius</label>
            <input value={theme.radiusCard ?? ""} onChange={(e) => update("radiusCard", e.target.value)} className="w-full bg-neutral-900 border border-neutral-700 rounded-lg px-3 py-2 text-sm" />
          </div>
          <div>
            <label className="block text-sm mb-1 text-neutral-300">Section Spacing</label>
            <input value={theme.sectionSpacing ?? ""} onChange={(e) => update("sectionSpacing", e.target.value)} className="w-full bg-neutral-900 border border-neutral-700 rounded-lg px-3 py-2 text-sm" />
          </div>
          <div>
            <label className="block text-sm mb-1 text-neutral-300">Container Width</label>
            <input value={theme.containerWidth ?? ""} onChange={(e) => update("containerWidth", e.target.value)} className="w-full bg-neutral-900 border border-neutral-700 rounded-lg px-3 py-2 text-sm" />
          </div>
        </div>
      </section>

      <button onClick={save} disabled={saving} className="bg-lime-400 text-black font-semibold px-6 py-2.5 rounded-lg hover:bg-lime-300 disabled:opacity-60">
        {saving ? "Saving..." : "Save Theme"}
      </button>
    </div>
  );
}
