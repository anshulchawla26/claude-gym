import { prisma } from "@/lib/prisma";

export default async function AuditLogPage() {
  const logs = await prisma.auditLog.findMany({
    orderBy: { timestamp: "desc" },
    take: 200,
    include: { user: { select: { name: true, email: true } } }
  });

  return (
    <div>
      <h1 className="text-2xl font-bold mb-1">Activity Log</h1>
      <p className="text-neutral-400 text-sm mb-8">A record of important actions taken across the admin panel.</p>

      <div className="bg-neutral-950 border border-neutral-800 rounded-xl overflow-hidden">
        {logs.length === 0 ? (
          <div className="p-10 text-center text-neutral-500">No activity recorded yet.</div>
        ) : (
          <table className="w-full text-sm">
            <thead>
              <tr className="border-b border-neutral-800 text-neutral-400 text-left">
                <th className="p-4">User</th>
                <th className="p-4">Action</th>
                <th className="p-4">Details</th>
                <th className="p-4">Timestamp</th>
              </tr>
            </thead>
            <tbody>
              {logs.map((log) => (
                <tr key={log.id} className="border-b border-neutral-900">
                  <td className="p-4">{log.user?.name ?? "System"}</td>
                  <td className="p-4">{log.action.replace(/_/g, " ")}</td>
                  <td className="p-4 text-neutral-400 max-w-xs truncate">{log.details}</td>
                  <td className="p-4 text-neutral-400">{new Date(log.timestamp).toLocaleString()}</td>
                </tr>
              ))}
            </tbody>
          </table>
        )}
      </div>
    </div>
  );
}
