"use client";

import { useEffect, useState } from "react";
import toast from "react-hot-toast";
import Link from "next/link";

interface Page {
  id: string;
  title: string;
  slug: string;
  published: boolean;
  isSystem: boolean;
  seoTitle: string | null;
  seoDescription: string | null;
  content: string;
}

export default function PagesAdminPage() {
  const [pages, setPages] = useState<Page[]>([]);
  const [loading, setLoading] = useState(true);
  const [editing, setEditing] = useState<Page | null>(null);
  const [form, setForm] = useState<any>({});
  const [creating, setCreating] = useState(false);
  const [newPage, setNewPage] = useState({ title: "", slug: "" });
  const [saving, setSaving] = useState(false);

  async function load() {
    setLoading(true);
    try {
      const res = await fetch("/api/admin/pages");
      const json = await res.json();
      setPages(json.items || []);
    } catch {
      toast.error("Failed to load pages");
    } finally {
      setLoading(false);
    }
  }

  useEffect(() => {
    load();
  }, []);

  function openEdit(page: Page) {
    setEditing(page);
    setForm({ ...page });
  }

  async function save() {
    if (!editing) return;
    setSaving(true);
    try {
      const res = await fetch(`/api/admin/pages/${editing.id}`, {
        method: "PATCH",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(form)
      });
      if (!res.ok) {
        const json = await res.json();
        toast.error(json.message || "Save failed");
        return;
      }
      toast.success("Page updated");
      setEditing(null);
      load();
    } finally {
      setSaving(false);
    }
  }

  async function createPage() {
    if (!newPage.title || !newPage.slug) {
      toast.error("Title and slug are required");
      return;
    }
    const res = await fetch("/api/admin/pages", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(newPage)
    });
    const json = await res.json();
    if (!res.ok) {
      toast.error(json.message || "Failed to create page");
      return;
    }
    toast.success("Page created");
    setCreating(false);
    setNewPage({ title: "", slug: "" });
    load();
  }

  async function togglePublish(page: Page) {
    await fetch(`/api/admin/pages/${page.id}`, {
      method: "PATCH",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ published: !page.published })
    });
    load();
  }

  async function deletePage(page: Page) {
    if (!confirm(`Delete page "${page.title}"? This cannot be undone.`)) return;
    const res = await fetch(`/api/admin/pages/${page.id}`, { method: "DELETE" });
    if (!res.ok) {
      const json = await res.json();
      toast.error(json.message || "Delete failed");
      return;
    }
    toast.success("Page deleted");
    load();
  }

  return (
    <div>
      <div className="flex items-start justify-between mb-6 flex-wrap gap-4">
        <div>
          <h1 className="text-2xl font-bold">Pages</h1>
          <p className="text-neutral-400 text-sm mt-1">Manage every page on your site, including custom pages you add.</p>
        </div>
        <button onClick={() => setCreating(true)} className="bg-lime-400 text-black font-semibold px-4 py-2 rounded-lg hover:bg-lime-300">
          + Add Page
        </button>
      </div>

      <div className="bg-neutral-950 border border-neutral-800 rounded-xl overflow-hidden">
        {loading ? (
          <div className="p-10 text-center text-neutral-500">Loading...</div>
        ) : (
          <table className="w-full text-sm">
            <thead>
              <tr className="border-b border-neutral-800 text-neutral-400 text-left">
                <th className="p-4">Title</th>
                <th className="p-4">Slug</th>
                <th className="p-4">Published</th>
                <th className="p-4 w-48">Actions</th>
              </tr>
            </thead>
            <tbody>
              {pages.map((page) => (
                <tr key={page.id} className="border-b border-neutral-900 hover:bg-neutral-900/50">
                  <td className="p-4">
                    {page.title} {page.isSystem && <span className="text-xs text-neutral-500 ml-1">(system)</span>}
                  </td>
                  <td className="p-4 text-neutral-400">/{page.slug === "home" ? "" : page.slug}</td>
                  <td className="p-4">
                    <button onClick={() => togglePublish(page)} className={`w-10 h-6 rounded-full relative ${page.published ? "bg-lime-400" : "bg-neutral-700"}`}>
                      <span className={`absolute top-0.5 w-5 h-5 bg-white rounded-full transition-transform ${page.published ? "translate-x-4" : "translate-x-0.5"}`} />
                    </button>
                  </td>
                  <td className="p-4">
                    <div className="flex gap-3">
                      {page.slug === "home" ? (
                        <Link href="/admin/builder" className="text-lime-400 hover:underline">
                          Open Builder
                        </Link>
                      ) : (
                        <button onClick={() => openEdit(page)} className="text-neutral-300 hover:text-lime-400">
                          Edit
                        </button>
                      )}
                      {!page.isSystem && (
                        <button onClick={() => deletePage(page)} className="text-neutral-300 hover:text-red-400">
                          Delete
                        </button>
                      )}
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        )}
      </div>

      {editing && (
        <div className="fixed inset-0 z-[150] flex justify-end bg-black/60" onClick={() => setEditing(null)}>
          <div className="w-full max-w-lg bg-neutral-950 border-l border-neutral-800 h-full overflow-y-auto p-6" onClick={(e) => e.stopPropagation()}>
            <div className="flex justify-between items-center mb-6">
              <h2 className="text-lg font-semibold">Edit Page</h2>
              <button onClick={() => setEditing(null)} className="text-neutral-400 hover:text-white text-xl">
                ✕
              </button>
            </div>
            <div className="space-y-4">
              <div>
                <label className="block text-sm mb-1 text-neutral-300">Title</label>
                <input value={form.title ?? ""} onChange={(e) => setForm({ ...form, title: e.target.value })} className="w-full bg-neutral-900 border border-neutral-700 rounded-lg px-4 py-2.5" />
              </div>
              <div>
                <label className="block text-sm mb-1 text-neutral-300">Page Content</label>
                <textarea value={form.content ?? ""} onChange={(e) => setForm({ ...form, content: e.target.value })} rows={10} className="w-full bg-neutral-900 border border-neutral-700 rounded-lg px-4 py-2.5" />
                <p className="text-xs text-neutral-500 mt-1">Separate paragraphs with a blank line.</p>
              </div>
              <div>
                <label className="block text-sm mb-1 text-neutral-300">SEO Title</label>
                <input value={form.seoTitle ?? ""} onChange={(e) => setForm({ ...form, seoTitle: e.target.value })} className="w-full bg-neutral-900 border border-neutral-700 rounded-lg px-4 py-2.5" />
              </div>
              <div>
                <label className="block text-sm mb-1 text-neutral-300">SEO Description</label>
                <textarea value={form.seoDescription ?? ""} onChange={(e) => setForm({ ...form, seoDescription: e.target.value })} rows={2} className="w-full bg-neutral-900 border border-neutral-700 rounded-lg px-4 py-2.5" />
              </div>
            </div>
            <div className="flex gap-3 mt-8">
              <button onClick={save} disabled={saving} className="flex-1 bg-lime-400 text-black font-semibold py-2.5 rounded-lg hover:bg-lime-300 disabled:opacity-60">
                {saving ? "Saving..." : "Save"}
              </button>
              <button onClick={() => setEditing(null)} className="px-5 py-2.5 rounded-lg border border-neutral-700 text-neutral-300">
                Cancel
              </button>
            </div>
          </div>
        </div>
      )}

      {creating && (
        <div className="fixed inset-0 z-[150] bg-black/70 flex items-center justify-center p-4" onClick={() => setCreating(false)}>
          <div className="bg-neutral-950 border border-neutral-800 rounded-xl p-6 max-w-sm w-full" onClick={(e) => e.stopPropagation()}>
            <h3 className="font-semibold mb-4">New Page</h3>
            <div className="space-y-3 mb-4">
              <input placeholder="Title" value={newPage.title} onChange={(e) => setNewPage({ ...newPage, title: e.target.value })} className="w-full bg-neutral-900 border border-neutral-700 rounded-lg px-4 py-2.5" />
              <input placeholder="slug-like-this" value={newPage.slug} onChange={(e) => setNewPage({ ...newPage, slug: e.target.value })} className="w-full bg-neutral-900 border border-neutral-700 rounded-lg px-4 py-2.5" />
            </div>
            <div className="flex gap-3">
              <button onClick={createPage} className="flex-1 bg-lime-400 text-black font-semibold py-2 rounded-lg">
                Create
              </button>
              <button onClick={() => setCreating(false)} className="px-4 py-2 rounded-lg border border-neutral-700 text-neutral-300">
                Cancel
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
