"use client";

import { useEffect, useState } from "react";
import { useSession } from "next-auth/react";
import toast from "react-hot-toast";

interface User {
  id: string;
  name: string;
  email: string;
  role: string;
  active: boolean;
}

const ROLES = ["SUPER_ADMIN", "GYM_ADMIN", "STAFF"];

export default function UsersAdminPage() {
  const { data: session } = useSession();
  const [users, setUsers] = useState<User[]>([]);
  const [loading, setLoading] = useState(true);
  const [creating, setCreating] = useState(false);
  const [newUser, setNewUser] = useState({ name: "", email: "", password: "", role: "STAFF" });

  const isSuperAdmin = (session?.user as any)?.role === "SUPER_ADMIN";

  async function load() {
    setLoading(true);
    const res = await fetch("/api/admin/users");
    const json = await res.json();
    setUsers(json.items || []);
    setLoading(false);
  }

  useEffect(() => {
    load();
  }, []);

  async function createUser() {
    const res = await fetch("/api/admin/users", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(newUser)
    });
    const json = await res.json();
    if (!res.ok) {
      toast.error(json.message || "Failed to create user");
      return;
    }
    toast.success("User created");
    setCreating(false);
    setNewUser({ name: "", email: "", password: "", role: "STAFF" });
    load();
  }

  async function toggleActive(user: User) {
    await fetch(`/api/admin/users/${user.id}`, {
      method: "PATCH",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ active: !user.active })
    });
    load();
  }

  async function changeRole(user: User, role: string) {
    await fetch(`/api/admin/users/${user.id}`, {
      method: "PATCH",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ role })
    });
    load();
  }

  async function deleteUser(user: User) {
    if (!confirm(`Delete user "${user.name}"?`)) return;
    const res = await fetch(`/api/admin/users/${user.id}`, { method: "DELETE" });
    if (!res.ok) {
      const json = await res.json();
      toast.error(json.message || "Delete failed");
      return;
    }
    toast.success("User deleted");
    load();
  }

  return (
    <div>
      <div className="flex items-start justify-between mb-6 flex-wrap gap-4">
        <div>
          <h1 className="text-2xl font-bold">Users / Admins</h1>
          <p className="text-neutral-400 text-sm mt-1">
            SUPER ADMIN has full access · GYM ADMIN manages website, content, leads &amp; settings · STAFF manages leads only.
          </p>
        </div>
        {isSuperAdmin && (
          <button onClick={() => setCreating(true)} className="bg-lime-400 text-black font-semibold px-4 py-2 rounded-lg hover:bg-lime-300">
            + Add User
          </button>
        )}
      </div>

      <div className="bg-neutral-950 border border-neutral-800 rounded-xl overflow-hidden">
        {loading ? (
          <div className="p-10 text-center text-neutral-500">Loading...</div>
        ) : (
          <table className="w-full text-sm">
            <thead>
              <tr className="border-b border-neutral-800 text-neutral-400 text-left">
                <th className="p-4">Name</th>
                <th className="p-4">Email</th>
                <th className="p-4">Role</th>
                <th className="p-4">Active</th>
                {isSuperAdmin && <th className="p-4">Actions</th>}
              </tr>
            </thead>
            <tbody>
              {users.map((user) => (
                <tr key={user.id} className="border-b border-neutral-900">
                  <td className="p-4">{user.name}</td>
                  <td className="p-4 text-neutral-400">{user.email}</td>
                  <td className="p-4">
                    {isSuperAdmin ? (
                      <select value={user.role} onChange={(e) => changeRole(user, e.target.value)} className="bg-neutral-900 border border-neutral-700 rounded-lg px-2 py-1 text-xs">
                        {ROLES.map((r) => (
                          <option key={r} value={r}>
                            {r.replace("_", " ")}
                          </option>
                        ))}
                      </select>
                    ) : (
                      user.role.replace("_", " ")
                    )}
                  </td>
                  <td className="p-4">
                    {isSuperAdmin ? (
                      <button onClick={() => toggleActive(user)} className={`w-10 h-6 rounded-full relative ${user.active ? "bg-lime-400" : "bg-neutral-700"}`}>
                        <span className={`absolute top-0.5 w-5 h-5 bg-white rounded-full transition-transform ${user.active ? "translate-x-4" : "translate-x-0.5"}`} />
                      </button>
                    ) : user.active ? (
                      "Yes"
                    ) : (
                      "No"
                    )}
                  </td>
                  {isSuperAdmin && (
                    <td className="p-4">
                      <button onClick={() => deleteUser(user)} className="text-neutral-300 hover:text-red-400">
                        Delete
                      </button>
                    </td>
                  )}
                </tr>
              ))}
            </tbody>
          </table>
        )}
      </div>

      {creating && (
        <div className="fixed inset-0 z-[150] bg-black/70 flex items-center justify-center p-4" onClick={() => setCreating(false)}>
          <div className="bg-neutral-950 border border-neutral-800 rounded-xl p-6 max-w-sm w-full" onClick={(e) => e.stopPropagation()}>
            <h3 className="font-semibold mb-4">New User</h3>
            <div className="space-y-3 mb-4">
              <input placeholder="Name" value={newUser.name} onChange={(e) => setNewUser({ ...newUser, name: e.target.value })} className="w-full bg-neutral-900 border border-neutral-700 rounded-lg px-4 py-2.5" />
              <input placeholder="Email" type="email" value={newUser.email} onChange={(e) => setNewUser({ ...newUser, email: e.target.value })} className="w-full bg-neutral-900 border border-neutral-700 rounded-lg px-4 py-2.5" />
              <input placeholder="Password (min 8 characters)" type="password" value={newUser.password} onChange={(e) => setNewUser({ ...newUser, password: e.target.value })} className="w-full bg-neutral-900 border border-neutral-700 rounded-lg px-4 py-2.5" />
              <select value={newUser.role} onChange={(e) => setNewUser({ ...newUser, role: e.target.value })} className="w-full bg-neutral-900 border border-neutral-700 rounded-lg px-4 py-2.5">
                {ROLES.map((r) => (
                  <option key={r} value={r}>
                    {r.replace("_", " ")}
                  </option>
                ))}
              </select>
            </div>
            <div className="flex gap-3">
              <button onClick={createUser} className="flex-1 bg-lime-400 text-black font-semibold py-2 rounded-lg">
                Create
              </button>
              <button onClick={() => setCreating(false)} className="px-4 py-2 rounded-lg border border-neutral-700 text-neutral-300">
                Cancel
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
