"use client";

import { useEffect, useState } from "react";
import toast from "react-hot-toast";

export default function NotificationsSettingsPage() {
  const [settings, setSettings] = useState<any>(null);
  const [saving, setSaving] = useState(false);
  const [testing, setTesting] = useState<string | null>(null);

  useEffect(() => {
    fetch("/api/admin/settings/notifications")
      .then((r) => r.json())
      .then(setSettings);
  }, []);

  function update(key: string, value: any) {
    setSettings((prev: any) => ({ ...prev, [key]: value }));
  }

  async function save() {
    setSaving(true);
    try {
      const res = await fetch("/api/admin/settings/notifications", {
        method: "PATCH",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(settings)
      });
      if (!res.ok) throw new Error();
      toast.success("Notification settings saved");
    } catch {
      toast.error("Failed to save");
    } finally {
      setSaving(false);
    }
  }

  async function test(channel: "whatsapp" | "email") {
    setTesting(channel);
    try {
      const res = await fetch("/api/admin/settings/notifications/test", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ channel })
      });
      const json = await res.json();
      if (json.sent) {
        toast.success(`Test ${channel} message sent successfully.`);
      } else {
        toast.error(json.message || `Test ${channel} message could not be sent.`);
      }
    } catch {
      toast.error("Test failed — network error");
    } finally {
      setTesting(null);
    }
  }

  if (!settings) return <div className="text-neutral-500">Loading...</div>;

  return (
    <div className="max-w-2xl space-y-10">
      <div>
        <h1 className="text-2xl font-bold mb-1">Notifications</h1>
        <p className="text-neutral-400 text-sm">Get notified instantly whenever a new lead submits the JOIN NOW form.</p>
      </div>

      <section className="space-y-4 bg-neutral-950 border border-neutral-800 rounded-xl p-6">
        <div className="flex items-center justify-between">
          <h2 className="font-semibold">WhatsApp Notifications</h2>
          <label className="flex items-center gap-2 text-sm">
            <input type="checkbox" checked={!!settings.whatsappEnabled} onChange={(e) => update("whatsappEnabled", e.target.checked)} />
            Enabled
          </label>
        </div>

        {!settings.whatsappConfigured && (
          <div className="bg-amber-500/10 border border-amber-500/30 text-amber-400 text-sm rounded-lg p-3">
            WhatsApp notifications are not configured. Add <code>WHATSAPP_API_TOKEN</code> and{" "}
            <code>WHATSAPP_PHONE_NUMBER_ID</code> to your server environment (WhatsApp Business Cloud API credentials) to enable real
            delivery.
          </div>
        )}

        <div>
          <label className="block text-sm mb-1 text-neutral-300">Destination WhatsApp Number</label>
          <input value={settings.whatsappNumber ?? ""} onChange={(e) => update("whatsappNumber", e.target.value)} placeholder="+91 98765 43210" className="w-full bg-neutral-900 border border-neutral-700 rounded-lg px-4 py-2.5" />
        </div>
        <div>
          <label className="block text-sm mb-1 text-neutral-300">Provider</label>
          <select value={settings.whatsappProvider ?? "meta"} onChange={(e) => update("whatsappProvider", e.target.value)} className="w-full bg-neutral-900 border border-neutral-700 rounded-lg px-4 py-2.5">
            <option value="meta">WhatsApp Cloud API (Meta)</option>
          </select>
        </div>
        <div>
          <label className="block text-sm mb-1 text-neutral-300">Message Template</label>
          <textarea value={settings.whatsappTemplate ?? ""} onChange={(e) => update("whatsappTemplate", e.target.value)} rows={6} className="w-full bg-neutral-900 border border-neutral-700 rounded-lg px-4 py-2.5 font-mono text-sm" />
          <p className="text-xs text-neutral-500 mt-1">
            Available variables: {"{{name}}"} {"{{mobile}}"} {"{{email}}"} {"{{gender}}"} {"{{fitnessGoal}}"}
          </p>
        </div>
        <button onClick={() => test("whatsapp")} disabled={testing === "whatsapp"} className="text-sm bg-neutral-800 hover:bg-neutral-700 px-4 py-2 rounded-lg disabled:opacity-60">
          {testing === "whatsapp" ? "Sending..." : "Send Test Notification"}
        </button>
      </section>

      <section className="space-y-4 bg-neutral-950 border border-neutral-800 rounded-xl p-6">
        <div className="flex items-center justify-between">
          <h2 className="font-semibold">Email Notifications</h2>
          <label className="flex items-center gap-2 text-sm">
            <input type="checkbox" checked={!!settings.emailEnabled} onChange={(e) => update("emailEnabled", e.target.checked)} />
            Enabled
          </label>
        </div>

        {!settings.emailConfigured && (
          <div className="bg-amber-500/10 border border-amber-500/30 text-amber-400 text-sm rounded-lg p-3">
            Email notifications are not configured. Add <code>SMTP_HOST</code>, <code>SMTP_USER</code> and{" "}
            <code>SMTP_PASSWORD</code> to your server environment to enable real delivery.
          </div>
        )}

        <div>
          <label className="block text-sm mb-1 text-neutral-300">Destination Email</label>
          <input value={settings.destinationEmail ?? ""} onChange={(e) => update("destinationEmail", e.target.value)} placeholder="owner@irondistrict.example" className="w-full bg-neutral-900 border border-neutral-700 rounded-lg px-4 py-2.5" />
        </div>
        <div>
          <label className="block text-sm mb-1 text-neutral-300">Email Template</label>
          <textarea value={settings.emailTemplate ?? ""} onChange={(e) => update("emailTemplate", e.target.value)} rows={6} className="w-full bg-neutral-900 border border-neutral-700 rounded-lg px-4 py-2.5 font-mono text-sm" />
        </div>
        <button onClick={() => test("email")} disabled={testing === "email"} className="text-sm bg-neutral-800 hover:bg-neutral-700 px-4 py-2 rounded-lg disabled:opacity-60">
          {testing === "email" ? "Sending..." : "Send Test Notification"}
        </button>
      </section>

      <button onClick={save} disabled={saving} className="bg-lime-400 text-black font-semibold px-6 py-2.5 rounded-lg hover:bg-lime-300 disabled:opacity-60">
        {saving ? "Saving..." : "Save Notification Settings"}
      </button>
    </div>
  );
}
