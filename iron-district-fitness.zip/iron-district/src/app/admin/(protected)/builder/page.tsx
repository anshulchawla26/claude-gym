"use client";

import { useEffect, useState } from "react";
import toast from "react-hot-toast";
import SectionEditor, { SECTION_LABELS } from "@/components/admin/SectionEditor";

interface Section {
  id: string;
  type: string;
  order: number;
  visible: boolean;
  data: string;
}

const ADDABLE_TYPES = Object.keys(SECTION_LABELS);

export default function WebsiteBuilderPage() {
  const [sections, setSections] = useState<Section[]>([]);
  const [loading, setLoading] = useState(true);
  const [editingSection, setEditingSection] = useState<Section | null>(null);
  const [addType, setAddType] = useState(ADDABLE_TYPES[0]);

  async function load() {
    setLoading(true);
    try {
      const res = await fetch("/api/admin/sections");
      const json = await res.json();
      setSections((json.items || []).sort((a: Section, b: Section) => a.order - b.order));
    } catch {
      toast.error("Failed to load sections");
    } finally {
      setLoading(false);
    }
  }

  useEffect(() => {
    load();
  }, []);

  async function toggleVisible(section: Section) {
    await fetch(`/api/admin/sections/${section.id}`, {
      method: "PATCH",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ visible: !section.visible })
    });
    load();
  }

  async function move(section: Section, direction: -1 | 1) {
    const idx = sections.findIndex((s) => s.id === section.id);
    const swapIdx = idx + direction;
    if (swapIdx < 0 || swapIdx >= sections.length) return;
    const a = sections[idx];
    const b = sections[swapIdx];

    await Promise.all([
      fetch(`/api/admin/sections/${a.id}`, {
        method: "PATCH",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ order: b.order })
      }),
      fetch(`/api/admin/sections/${b.id}`, {
        method: "PATCH",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ order: a.order })
      })
    ]);
    load();
  }

  async function duplicate(section: Section) {
    await fetch(`/api/admin/sections/${section.id}`, { method: "POST" });
    toast.success("Section duplicated");
    load();
  }

  async function remove(section: Section) {
    if (!confirm("Remove this section from the homepage?")) return;
    await fetch(`/api/admin/sections/${section.id}`, { method: "DELETE" });
    toast.success("Section removed");
    load();
  }

  async function addSection() {
    await fetch("/api/admin/sections", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ type: addType, data: {} })
    });
    toast.success("Section added");
    load();
  }

  async function saveEditor(data: any) {
    if (!editingSection) return;
    await fetch(`/api/admin/sections/${editingSection.id}`, {
      method: "PATCH",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ data })
    });
    toast.success("Section saved");
    setEditingSection(null);
    load();
  }

  function safeParse(json: string) {
    try {
      return JSON.parse(json);
    } catch {
      return {};
    }
  }

  return (
    <div>
      <div className="flex items-start justify-between mb-6 flex-wrap gap-4">
        <div>
          <h1 className="text-2xl font-bold">Website Builder</h1>
          <p className="text-neutral-400 text-sm mt-1">Control the homepage: reorder, hide, edit or duplicate any section.</p>
        </div>
        <a href="/" target="_blank" className="bg-neutral-800 hover:bg-neutral-700 px-4 py-2 rounded-lg text-sm">
          Preview Site ↗
        </a>
      </div>

      <div className="flex gap-3 mb-6">
        <select value={addType} onChange={(e) => setAddType(e.target.value)} className="bg-neutral-900 border border-neutral-700 rounded-lg px-4 py-2 text-sm">
          {ADDABLE_TYPES.map((t) => (
            <option key={t} value={t}>
              {SECTION_LABELS[t]}
            </option>
          ))}
        </select>
        <button onClick={addSection} className="bg-lime-400 text-black font-semibold px-4 py-2 rounded-lg hover:bg-lime-300 text-sm">
          + Add Section
        </button>
      </div>

      {loading ? (
        <div className="text-neutral-500">Loading...</div>
      ) : (
        <div className="space-y-3">
          {sections.map((section, i) => (
            <div key={section.id} className="bg-neutral-950 border border-neutral-800 rounded-xl p-4 flex items-center gap-4">
              <div className="flex flex-col gap-1">
                <button disabled={i === 0} onClick={() => move(section, -1)} className="text-neutral-500 hover:text-white disabled:opacity-30">
                  ▲
                </button>
                <button disabled={i === sections.length - 1} onClick={() => move(section, 1)} className="text-neutral-500 hover:text-white disabled:opacity-30">
                  ▼
                </button>
              </div>

              <div className="flex-1">
                <div className="font-medium">{SECTION_LABELS[section.type] || section.type}</div>
                <div className="text-xs text-neutral-500">Position {i + 1}</div>
              </div>

              <button
                onClick={() => toggleVisible(section)}
                className={`w-10 h-6 rounded-full transition-colors relative ${section.visible ? "bg-lime-400" : "bg-neutral-700"}`}
                title={section.visible ? "Visible" : "Hidden"}
              >
                <span className={`absolute top-0.5 w-5 h-5 bg-white rounded-full transition-transform ${section.visible ? "translate-x-4" : "translate-x-0.5"}`} />
              </button>

              <div className="flex gap-2 text-sm">
                <button onClick={() => setEditingSection(section)} className="text-neutral-300 hover:text-lime-400">
                  Edit
                </button>
                <button onClick={() => duplicate(section)} className="text-neutral-300 hover:text-lime-400">
                  Duplicate
                </button>
                <button onClick={() => remove(section)} className="text-neutral-300 hover:text-red-400">
                  Delete
                </button>
              </div>
            </div>
          ))}
        </div>
      )}

      {editingSection && (
        <SectionEditor
          type={editingSection.type}
          initialData={safeParse(editingSection.data)}
          onSave={saveEditor}
          onClose={() => setEditingSection(null)}
        />
      )}
    </div>
  );
}
