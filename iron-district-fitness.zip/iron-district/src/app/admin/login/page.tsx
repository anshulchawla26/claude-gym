"use client";

import { useState, FormEvent } from "react";
import { signIn } from "next-auth/react";
import { useRouter } from "next/navigation";

export default function AdminLoginPage() {
  const router = useRouter();
  const [error, setError] = useState("");
  const [loading, setLoading] = useState(false);

  async function handleSubmit(e: FormEvent<HTMLFormElement>) {
    e.preventDefault();
    setLoading(true);
    setError("");

    const form = e.currentTarget;
    const email = (form.elements.namedItem("email") as HTMLInputElement).value;
    const password = (form.elements.namedItem("password") as HTMLInputElement).value;

    const res = await signIn("credentials", { email, password, redirect: false });

    if (res?.error) {
      setError("Invalid email or password.");
      setLoading(false);
      return;
    }

    router.push("/admin");
    router.refresh();
  }

  return (
    <div className="min-h-screen flex items-center justify-center px-4">
      <div className="w-full max-w-sm bg-neutral-950 border border-neutral-800 rounded-2xl p-8">
        <div className="text-center mb-8">
          <div className="text-3xl mb-2">🏋️</div>
          <h1 className="text-xl font-bold">Iron District Admin</h1>
          <p className="text-neutral-500 text-sm mt-1">Sign in to manage your website</p>
        </div>

        <form onSubmit={handleSubmit} className="space-y-4">
          <div>
            <label className="block text-sm mb-1 text-neutral-300">Email</label>
            <input
              name="email"
              type="email"
              required
              defaultValue="admin@irondistrict.example"
              className="w-full bg-neutral-900 border border-neutral-700 rounded-lg px-4 py-2.5 focus:outline-none focus:border-lime-400"
            />
          </div>
          <div>
            <label className="block text-sm mb-1 text-neutral-300">Password</label>
            <input
              name="password"
              type="password"
              required
              className="w-full bg-neutral-900 border border-neutral-700 rounded-lg px-4 py-2.5 focus:outline-none focus:border-lime-400"
            />
          </div>

          {error && <p className="text-red-400 text-sm">{error}</p>}

          <button
            type="submit"
            disabled={loading}
            className="w-full bg-lime-400 text-black font-semibold py-2.5 rounded-lg hover:bg-lime-300 transition-colors disabled:opacity-60"
          >
            {loading ? "Signing in..." : "Sign In"}
          </button>
        </form>

        <p className="text-neutral-500 text-xs text-center mt-6">
          Demo credentials: admin@irondistrict.example / Admin@12345
        </p>
      </div>
    </div>
  );
}
