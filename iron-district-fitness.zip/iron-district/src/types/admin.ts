import type { ReactNode } from "react";

export type FieldType = "text" | "textarea" | "number" | "checkbox" | "select" | "image" | "tags";

export interface FieldConfig {
  name: string;
  label: string;
  type: FieldType;
  options?: string[];
  required?: boolean;
  helpText?: string;
  fullWidth?: boolean;
}

export interface ColumnConfig<T = any> {
  key: string;
  label: string;
  render?: (item: T) => ReactNode;
}
