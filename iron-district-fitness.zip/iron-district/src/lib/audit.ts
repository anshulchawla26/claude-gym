import { prisma } from "@/lib/prisma";

export async function logAction(userId: string | null, action: string, details?: string) {
  try {
    await prisma.auditLog.create({
      data: { userId: userId ?? undefined, action, details }
    });
  } catch {
    // Auditing must never break the primary action it's logging.
  }
}
