import { NextRequest, NextResponse } from "next/server";
import { getServerSession } from "next-auth";
import { authOptions, roleCan } from "@/lib/auth";
import { prisma } from "@/lib/prisma";
import { logAction } from "@/lib/audit";

type ModelDelegate = {
  findMany: (args?: any) => Promise<any[]>;
  create: (args: any) => Promise<any>;
  update: (args: any) => Promise<any>;
  delete: (args: any) => Promise<any>;
};

interface CrudOptions {
  modelName: string; // e.g. "program" — must match prisma client property name
  orderBy?: Record<string, "asc" | "desc">;
  auditLabel: string; // e.g. "Program"
  // JSON string fields (e.g. specializations stored as JSON) get stringified on write.
  jsonArrayFields?: string[];
}

async function requireEditPermission() {
  const session = await getServerSession(authOptions);
  if (!session) return { ok: false as const, res: NextResponse.json({ message: "Unauthorized" }, { status: 401 }) };
  if (!roleCan((session.user as any).role, "content:edit")) {
    return { ok: false as const, res: NextResponse.json({ message: "Forbidden" }, { status: 403 }) };
  }
  return { ok: true as const, session };
}

function stringifyJsonFields(data: Record<string, any>, fields: string[] = []) {
  const out = { ...data };
  for (const f of fields) {
    if (Array.isArray(out[f])) out[f] = JSON.stringify(out[f]);
  }
  return out;
}

export function makeListCreateHandlers(opts: CrudOptions) {
  async function GET() {
    const session = await getServerSession(authOptions);
    if (!session) return NextResponse.json({ message: "Unauthorized" }, { status: 401 });

    const model = (prisma as any)[opts.modelName] as ModelDelegate;
    const items = await model.findMany({ orderBy: opts.orderBy ?? { order: "asc" } });
    return NextResponse.json({ items });
  }

  async function POST(req: NextRequest) {
    const check = await requireEditPermission();
    if (!check.ok) return check.res;

    const body = await req.json().catch(() => null);
    if (!body) return NextResponse.json({ message: "Invalid request body." }, { status: 400 });

    const model = (prisma as any)[opts.modelName] as ModelDelegate;
    const data = stringifyJsonFields(body, opts.jsonArrayFields);
    delete data.id;

    const item = await model.create({ data });
    await logAction((check.session.user as any).id, `${opts.auditLabel.toLowerCase()}_created`, item.id);

    return NextResponse.json(item, { status: 201 });
  }

  return { GET, POST };
}

export function makeItemHandlers(opts: CrudOptions) {
  async function PATCH(req: NextRequest, { params }: { params: { id: string } }) {
    const check = await requireEditPermission();
    if (!check.ok) return check.res;

    const body = await req.json().catch(() => null);
    if (!body) return NextResponse.json({ message: "Invalid request body." }, { status: 400 });

    const model = (prisma as any)[opts.modelName] as ModelDelegate;
    const data = stringifyJsonFields(body, opts.jsonArrayFields);
    delete data.id;

    const item = await model.update({ where: { id: params.id }, data });
    await logAction((check.session.user as any).id, `${opts.auditLabel.toLowerCase()}_updated`, item.id);

    return NextResponse.json(item);
  }

  async function DELETE(_req: NextRequest, { params }: { params: { id: string } }) {
    const check = await requireEditPermission();
    if (!check.ok) return check.res;

    const model = (prisma as any)[opts.modelName] as ModelDelegate;
    await model.delete({ where: { id: params.id } });
    await logAction((check.session.user as any).id, `${opts.auditLabel.toLowerCase()}_deleted`, params.id);

    return NextResponse.json({ ok: true });
  }

  return { PATCH, DELETE };
}
