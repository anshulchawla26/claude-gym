import { z } from "zod";

// Indian-friendly but generally permissive mobile validation: 7-15 digits,
// optional leading +, allows spaces/dashes which are stripped before check.
const mobileRegex = /^\+?[0-9]{7,15}$/;

export const leadSchema = z.object({
  fullName: z.string().trim().min(2, "Please enter your full name").max(100),
  mobile: z
    .string()
    .trim()
    .transform((v) => v.replace(/[\s-]/g, ""))
    .refine((v) => mobileRegex.test(v), "Please enter a valid mobile number"),
  email: z.string().trim().toLowerCase().email("Please enter a valid email address"),
  gender: z.enum(["Male", "Female", "Prefer not to say"]),
  fitnessGoal: z.enum([
    "Weight Loss",
    "Muscle Gain",
    "Strength Training",
    "General Fitness",
    "Body Transformation",
    "Personal Training",
    "Other"
  ]),
  // Honeypot field — real users never fill this in.
  website: z.string().max(0, "Spam detected").optional().or(z.literal(""))
});

export type LeadInput = z.infer<typeof leadSchema>;

export const programSchema = z.object({
  name: z.string().min(2),
  slug: z.string().min(2).regex(/^[a-z0-9-]+$/, "Slug must be lowercase, letters/numbers/dashes only"),
  shortDesc: z.string().min(2),
  fullDesc: z.string().min(2),
  image: z.string().optional().nullable(),
  icon: z.string().default("dumbbell"),
  ctaText: z.string().default("Learn More"),
  ctaLink: z.string().default("/programs"),
  visible: z.boolean().default(true),
  order: z.number().default(0)
});

export const trainerSchema = z.object({
  name: z.string().min(2),
  photo: z.string().optional().nullable(),
  designation: z.string().min(2),
  experienceYears: z.number().min(0).default(0),
  bio: z.string().min(2),
  specializations: z.array(z.string()).default([]),
  certifications: z.array(z.string()).default([]),
  instagram: z.string().optional().nullable(),
  facebook: z.string().optional().nullable(),
  otherSocial: z.string().optional().nullable(),
  visible: z.boolean().default(true),
  order: z.number().default(0)
});
