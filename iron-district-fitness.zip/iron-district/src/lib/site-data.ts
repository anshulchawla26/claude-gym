import { prisma } from "@/lib/prisma";

export async function getSiteSettings() {
  const settings = await prisma.siteSettings.findUnique({ where: { id: "default" } });
  return settings;
}

export async function getThemeSettings() {
  const theme = await prisma.themeSettings.findUnique({ where: { id: "default" } });
  return theme;
}

export async function getNavigation() {
  return prisma.navigationItem.findMany({
    where: { visible: true },
    orderBy: { order: "asc" }
  });
}

export async function getPopupSettings() {
  return prisma.popupSettings.findUnique({ where: { id: "default" } });
}

export async function getAnnouncementBar() {
  return prisma.announcementBar.findUnique({ where: { id: "default" } });
}

export function themeToCssVars(
  theme: NonNullable<Awaited<ReturnType<typeof getThemeSettings>>>
): Record<string, string> {
  return {
    "--color-primary": theme.colorPrimary,
    "--color-secondary": theme.colorSecondary,
    "--color-accent": theme.colorAccent,
    "--color-background": theme.colorBackground,
    "--color-surface": theme.colorSurface,
    "--color-text": theme.colorText,
    "--color-text-muted": theme.colorTextMuted,
    "--color-border": theme.colorBorder,
    "--color-button": theme.colorButton,
    "--color-button-hover": theme.colorButtonHover,
    "--font-heading": theme.headingFont,
    "--font-body": theme.bodyFont,
    "--radius-base": theme.radiusBase,
    "--radius-button": theme.radiusButton,
    "--radius-card": theme.radiusCard,
    "--container-width": theme.containerWidth,
    "--letter-spacing": theme.letterSpacing,
    "--section-spacing": theme.sectionSpacing
  };
}
