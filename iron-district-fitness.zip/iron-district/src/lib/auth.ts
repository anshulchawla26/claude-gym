import { type NextAuthOptions } from "next-auth";
import CredentialsProvider from "next-auth/providers/credentials";
import bcrypt from "bcryptjs";
import { prisma } from "@/lib/prisma";

export const authOptions: NextAuthOptions = {
  session: { strategy: "jwt" },
  pages: {
    signIn: "/admin/login"
  },
  providers: [
    CredentialsProvider({
      name: "Credentials",
      credentials: {
        email: { label: "Email", type: "email" },
        password: { label: "Password", type: "password" }
      },
      async authorize(credentials) {
        if (!credentials?.email || !credentials?.password) return null;

        const user = await prisma.user.findUnique({
          where: { email: credentials.email.toLowerCase().trim() }
        });

        if (!user || !user.active) return null;

        const valid = await bcrypt.compare(credentials.password, user.password);
        if (!valid) return null;

        return {
          id: user.id,
          name: user.name,
          email: user.email,
          role: user.role
        };
      }
    })
  ],
  callbacks: {
    async jwt({ token, user }) {
      if (user) {
        token.role = (user as any).role;
        token.id = (user as any).id;
      }
      return token;
    },
    async session({ session, token }) {
      if (session.user) {
        (session.user as any).role = token.role;
        (session.user as any).id = token.id;
      }
      return session;
    }
  },
  secret: process.env.NEXTAUTH_SECRET
};

// Role hierarchy helpers used by server-side permission checks.
// IMPORTANT: permission checks must always be re-verified on the server
// (API routes / server actions) — never trust the client-side role alone.
export type AppRole = "SUPER_ADMIN" | "GYM_ADMIN" | "STAFF";

const permissionMatrix: Record<AppRole, string[]> = {
  SUPER_ADMIN: ["*"],
  GYM_ADMIN: [
    "website:edit",
    "content:edit",
    "leads:edit",
    "settings:edit",
    "media:edit"
  ],
  STAFF: ["leads:edit"]
};

export function roleCan(role: AppRole | undefined, permission: string): boolean {
  if (!role) return false;
  const perms = permissionMatrix[role] || [];
  return perms.includes("*") || perms.includes(permission);
}
