// Lightweight in-memory rate limiter. Good enough for a single-instance
// deployment / demo. For multi-instance production hosting, swap this for
// a shared store (Upstash Redis, etc) — the call sites don't need to change.

const hits = new Map<string, number[]>();

export function isRateLimited(key: string, limit = 5, windowMs = 60_000): boolean {
  const now = Date.now();
  const timestamps = (hits.get(key) || []).filter((t) => now - t < windowMs);
  timestamps.push(now);
  hits.set(key, timestamps);
  return timestamps.length > limit;
}
