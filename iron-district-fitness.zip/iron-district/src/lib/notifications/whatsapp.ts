/**
 * WhatsApp notification service.
 *
 * A normal personal WhatsApp account CANNOT receive arbitrary messages via
 * API. Real delivery requires the WhatsApp Business Platform (Meta Cloud
 * API) or a BSP (Twilio, 360dialog, Gupshup, etc). This module is written
 * as a clean abstraction so any provider can be plugged in later by adding
 * a case to `sendViaProvider` — nothing else in the app needs to change.
 *
 * If credentials are not configured, this returns a explicit
 * `{ sent: false, reason: "not_configured" }` result. The app NEVER
 * pretends a message was sent when it wasn't.
 */

export type WhatsAppResult =
  | { sent: true; provider: string; providerMessageId?: string }
  | { sent: false; reason: "not_configured" | "disabled" | "provider_error"; error?: string };

interface SendArgs {
  toNumber: string;
  message: string;
  provider: string;
}

export async function sendWhatsAppMessage({ toNumber, message, provider }: SendArgs): Promise<WhatsAppResult> {
  const token = process.env.WHATSAPP_API_TOKEN;
  const phoneNumberId = process.env.WHATSAPP_PHONE_NUMBER_ID;

  if (!token || !phoneNumberId) {
    return { sent: false, reason: "not_configured" };
  }

  try {
    return await sendViaProvider(provider, { toNumber, message, token, phoneNumberId });
  } catch (err: any) {
    return { sent: false, reason: "provider_error", error: err?.message ?? "Unknown error" };
  }
}

async function sendViaProvider(
  provider: string,
  args: { toNumber: string; message: string; token: string; phoneNumberId: string }
): Promise<WhatsAppResult> {
  switch (provider) {
    case "meta":
      return sendViaMetaCloudApi(args);
    // To add another BSP (Twilio, 360dialog, Gupshup...), implement a new
    // function here and add a case. The rest of the app is unaffected.
    default:
      return { sent: false, reason: "provider_error", error: `Unknown provider: ${provider}` };
  }
}

async function sendViaMetaCloudApi(args: {
  toNumber: string;
  message: string;
  token: string;
  phoneNumberId: string;
}): Promise<WhatsAppResult> {
  const url = `https://graph.facebook.com/v20.0/${args.phoneNumberId}/messages`;

  const res = await fetch(url, {
    method: "POST",
    headers: {
      Authorization: `Bearer ${args.token}`,
      "Content-Type": "application/json"
    },
    body: JSON.stringify({
      messaging_product: "whatsapp",
      to: args.toNumber.replace(/[^\d+]/g, ""),
      type: "text",
      text: { body: args.message }
    })
  });

  if (!res.ok) {
    const errText = await res.text().catch(() => "");
    return { sent: false, reason: "provider_error", error: `Meta API error ${res.status}: ${errText}` };
  }

  const json = await res.json().catch(() => ({}));
  return {
    sent: true,
    provider: "meta",
    providerMessageId: json?.messages?.[0]?.id
  };
}

export function renderTemplate(template: string, vars: Record<string, string>): string {
  return template.replace(/\{\{(\w+)\}\}/g, (_, key) => vars[key] ?? "");
}
