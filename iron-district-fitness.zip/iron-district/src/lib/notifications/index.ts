import { prisma } from "@/lib/prisma";
import { sendWhatsAppMessage, renderTemplate } from "./whatsapp";
import { sendEmail } from "./email";

interface LeadNotificationVars {
  name: string;
  mobile: string;
  email: string;
  gender: string;
  fitnessGoal: string;
}

/**
 * Called right after a lead is saved to the database. Independently
 * attempts WhatsApp + email notification based on admin-configured
 * settings. Never throws — a notification failure must never roll back
 * or block the lead save, but is logged so it's visible in the admin.
 */
export async function notifyNewLead(vars: LeadNotificationVars) {
  const settings = await prisma.notificationSettings.findUnique({ where: { id: "default" } });

  const results = { whatsapp: null as any, email: null as any };

  if (settings?.whatsappEnabled && settings.whatsappNumber) {
    const message = renderTemplate(settings.whatsappTemplate, vars);
    results.whatsapp = await sendWhatsAppMessage({
      toNumber: settings.whatsappNumber,
      message,
      provider: settings.whatsappProvider
    });
  } else {
    results.whatsapp = { sent: false, reason: settings?.whatsappEnabled ? "not_configured" : "disabled" };
  }

  if (settings?.emailEnabled && settings.destinationEmail) {
    const body = renderTemplate(settings.emailTemplate, vars);
    results.email = await sendEmail(settings.destinationEmail, `New Gym Enquiry — ${vars.name}`, body);
  } else {
    results.email = { sent: false, reason: settings?.emailEnabled ? "not_configured" : "disabled" };
  }

  return results;
}
