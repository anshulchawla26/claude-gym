import nodemailer from "nodemailer";

export type EmailResult =
  | { sent: true }
  | { sent: false; reason: "not_configured" | "provider_error"; error?: string };

export async function sendEmail(to: string, subject: string, body: string): Promise<EmailResult> {
  const { SMTP_HOST, SMTP_PORT, SMTP_USER, SMTP_PASSWORD, SMTP_FROM } = process.env;

  if (!SMTP_HOST || !SMTP_USER || !SMTP_PASSWORD) {
    return { sent: false, reason: "not_configured" };
  }

  try {
    const transporter = nodemailer.createTransport({
      host: SMTP_HOST,
      port: Number(SMTP_PORT || 587),
      secure: Number(SMTP_PORT || 587) === 465,
      auth: { user: SMTP_USER, pass: SMTP_PASSWORD }
    });

    await transporter.sendMail({
      from: SMTP_FROM || SMTP_USER,
      to,
      subject,
      text: body
    });

    return { sent: true };
  } catch (err: any) {
    return { sent: false, reason: "provider_error", error: err?.message ?? "Unknown error" };
  }
}
