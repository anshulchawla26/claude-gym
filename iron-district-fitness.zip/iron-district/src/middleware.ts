import { withAuth } from "next-auth/middleware";
import { NextResponse } from "next/server";

export default withAuth(
  function middleware(req) {
    // The login page itself must stay public — everything else under
    // /admin requires a valid session (enforced by withAuth below).
    if (req.nextUrl.pathname === "/admin/login") {
      return NextResponse.next();
    }
    return NextResponse.next();
  },
  {
    pages: { signIn: "/admin/login" },
    callbacks: {
      authorized: ({ req, token }) => {
        if (req.nextUrl.pathname === "/admin/login") return true;
        return !!token;
      }
    }
  }
);

export const config = {
  matcher: ["/admin/:path*"]
};
