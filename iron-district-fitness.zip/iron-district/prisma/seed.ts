import { PrismaClient } from "@prisma/client";
import bcrypt from "bcryptjs";

const prisma = new PrismaClient();

// Unsplash source images — free to use, good stand-ins for a gym demo.
const IMG = {
  heroBg: "https://images.unsplash.com/photo-1517836357463-d25dfeac3438?w=1600&q=80",
  about1: "https://images.unsplash.com/photo-1571019613454-1cb2f99b2d8b?w=800&q=80",
  about2: "https://images.unsplash.com/photo-1534438327276-14e5300c3a48?w=400&q=80",
  ctaBg: "https://images.unsplash.com/photo-1571902943202-507ec2618e8f?w=1600&q=80",
  strength: "https://images.unsplash.com/photo-1526506118085-60ce8714f8c5?w=800&q=80",
  muscle: "https://images.unsplash.com/photo-1583454110551-21f2fa2afe61?w=800&q=80",
  weightloss: "https://images.unsplash.com/photo-1517838277536-f5f99be501cd?w=800&q=80",
  personal: "https://images.unsplash.com/photo-1571731956672-f2b94d7dd0cb?w=800&q=80",
  functional: "https://images.unsplash.com/photo-1594381898411-846e7d193883?w=800&q=80",
  group: "https://images.unsplash.com/photo-1518611012118-696072aa579a?w=800&q=80",
  facility1: "https://images.unsplash.com/photo-1540497077202-7c8a3999166f?w=600&q=80",
  facility2: "https://images.unsplash.com/photo-1583454110551-21f2fa2afe61?w=600&q=80",
  facility3: "https://images.unsplash.com/photo-1571008887538-b36bb32f4571?w=600&q=80",
  facility4: "https://images.unsplash.com/photo-1591741535018-d042766c62eb?w=600&q=80",
  trainer1: "https://images.unsplash.com/photo-1567013127542-490d757e6349?w=500&q=80",
  trainer2: "https://images.unsplash.com/photo-1552196563-55cd4e45efb3?w=500&q=80",
  trainer3: "https://images.unsplash.com/photo-1571019613454-1cb2f99b2d8b?w=500&q=80",
  trainer4: "https://images.unsplash.com/photo-1544367567-0f2fcb009e0b?w=500&q=80",
  gallery: [
    "https://images.unsplash.com/photo-1534438327276-14e5300c3a48?w=600&q=80",
    "https://images.unsplash.com/photo-1571902943202-507ec2618e8f?w=600&q=80",
    "https://images.unsplash.com/photo-1517836357463-d25dfeac3438?w=600&q=80",
    "https://images.unsplash.com/photo-1526506118085-60ce8714f8c5?w=600&q=80",
    "https://images.unsplash.com/photo-1583454110551-21f2fa2afe61?w=600&q=80",
    "https://images.unsplash.com/photo-1518611012118-696072aa579a?w=600&q=80",
    "https://images.unsplash.com/photo-1540497077202-7c8a3999166f?w=600&q=80",
    "https://images.unsplash.com/photo-1594381898411-846e7d193883?w=600&q=80"
  ],
  transformBefore1: "https://images.unsplash.com/photo-1571731956672-f2b94d7dd0cb?w=400&q=80",
  transformAfter1: "https://images.unsplash.com/photo-1583454110551-21f2fa2afe61?w=400&q=80"
};

async function main() {
  console.log("Seeding Iron District Fitness demo data...");

  // ---------- Users ----------
  const passwordHash = await bcrypt.hash("Admin@12345", 10);
  await prisma.user.upsert({
    where: { email: "admin@irondistrict.example" },
    update: {},
    create: { name: "Alex Rivera", email: "admin@irondistrict.example", password: passwordHash, role: "SUPER_ADMIN" }
  });
  await prisma.user.upsert({
    where: { email: "manager@irondistrict.example" },
    update: {},
    create: { name: "Priya Sharma", email: "manager@irondistrict.example", password: passwordHash, role: "GYM_ADMIN" }
  });
  await prisma.user.upsert({
    where: { email: "staff@irondistrict.example" },
    update: {},
    create: { name: "Rohan Mehta", email: "staff@irondistrict.example", password: passwordHash, role: "STAFF" }
  });

  // ---------- Site + Theme settings ----------
  await prisma.siteSettings.upsert({
    where: { id: "default" },
    update: {},
    create: {
      id: "default",
      gymName: "Iron District Fitness",
      tagline: "Train Hard. Transform Fully.",
      phone: "+91 98765 43210",
      email: "hello@irondistrict.example",
      whatsapp: "+91 98765 43210",
      address: "12 Cyber Hub Road, Gurugram, Haryana, India",
      mapEmbedUrl: "https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3507.478!2d77.088!3d28.494!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1",
      mapLink: "https://maps.google.com/?q=Cyber+Hub+Gurugram",
      instagram: "https://instagram.com",
      facebook: "https://facebook.com",
      youtube: "https://youtube.com",
      openingHours: JSON.stringify([
        { day: "Monday - Friday", hours: "5:00 AM - 11:00 PM" },
        { day: "Saturday", hours: "6:00 AM - 9:00 PM" },
        { day: "Sunday", hours: "7:00 AM - 6:00 PM" }
      ]),
      copyrightText: "Iron District Fitness. All rights reserved."
    }
  });

  await prisma.themeSettings.upsert({ where: { id: "default" }, update: {}, create: { id: "default" } });
  await prisma.notificationSettings.upsert({ where: { id: "default" }, update: {}, create: { id: "default" } });
  await prisma.popupSettings.upsert({
    where: { id: "default" },
    update: {},
    create: {
      id: "default",
      enabled: true,
      heading: "Ready to Transform?",
      description: "Book a free trial session with our team today — no commitment required.",
      buttonText: "JOIN NOW",
      delaySeconds: 8
    }
  });
  await prisma.announcementBar.upsert({
    where: { id: "default" },
    update: {},
    create: {
      id: "default",
      enabled: true,
      text: "Your fitness journey starts today —",
      linkText: "JOIN NOW",
      linkUrl: "#join-now"
    }
  });

  // ---------- Navigation ----------
  const navItems = [
    { label: "Home", url: "/", order: 0 },
    { label: "About", url: "/about", order: 1 },
    { label: "Programs", url: "/programs", order: 2 },
    { label: "Trainers", url: "/trainers", order: 3 },
    { label: "Gallery", url: "/gallery", order: 4 },
    { label: "Contact", url: "/contact", order: 5 }
  ];
  for (const item of navItems) {
    const existing = await prisma.navigationItem.findFirst({ where: { label: item.label } });
    if (!existing) await prisma.navigationItem.create({ data: { ...item, visible: true } });
  }

  // ---------- Programs ----------
  const programs = [
    {
      name: "Strength Training",
      slug: "strength-training",
      shortDesc: "Build raw power with progressive barbell programming.",
      fullDesc:
        "Our Strength Training program is built around the big compound lifts — squat, deadlift, bench and overhead press — with structured progressive overload tracked every session. Coached in small groups so form is never compromised, this program is ideal for anyone who wants to get measurably stronger, not just tired.",
      image: IMG.strength,
      icon: "🏋️",
      order: 0
    },
    {
      name: "Muscle Building",
      slug: "muscle-building",
      shortDesc: "Hypertrophy-focused training to build lean, functional mass.",
      fullDesc:
        "A structured hypertrophy program combining volume training, targeted isolation work and nutrition guidance to help you build visible, functional muscle. Includes bi-weekly check-ins and progress photos so you can see exactly what's working.",
      image: IMG.muscle,
      icon: "💪",
      order: 1
    },
    {
      name: "Weight Loss",
      slug: "weight-loss",
      shortDesc: "Sustainable fat loss through smart training and habit coaching.",
      fullDesc:
        "This program pairs metabolic conditioning circuits with realistic, sustainable habit coaching — no crash diets. Our coaches track your progress weekly and adjust your plan so the results actually stick long after the program ends.",
      image: IMG.weightloss,
      icon: "🔥",
      order: 2
    },
    {
      name: "Personal Training",
      slug: "personal-training",
      shortDesc: "One-on-one coaching built entirely around your goals.",
      fullDesc:
        "Work directly with a dedicated coach who builds your program from scratch around your goals, schedule and any injury history. Every session is fully customized, with direct feedback on form and real-time programming adjustments.",
      image: IMG.personal,
      icon: "🎯",
      order: 3
    },
    {
      name: "Functional Training",
      slug: "functional-training",
      shortDesc: "Real-world strength, mobility and conditioning.",
      fullDesc:
        "Functional Training builds strength and conditioning that transfers directly to daily life and sport — think kettlebells, sled work, carries and mobility flows, all programmed to keep you moving well for the long term.",
      image: IMG.functional,
      icon: "⚡",
      order: 4
    },
    {
      name: "Group Classes",
      slug: "group-classes",
      shortDesc: "High-energy coached classes for every fitness level.",
      fullDesc:
        "Our group classes bring the energy of a full room with the structure of expert coaching. From HIIT to strength circuits, every class is scalable to your level while keeping the whole room moving together.",
      image: IMG.group,
      icon: "👥",
      order: 5
    }
  ];
  for (const p of programs) {
    await prisma.program.upsert({ where: { slug: p.slug }, update: {}, create: { ...p, ctaText: "Learn More", ctaLink: `/programs/${p.slug}`, visible: true } });
  }

  // ---------- Trainers ----------
  const trainerCount = await prisma.trainer.count();
  if (trainerCount === 0) {
    await prisma.trainer.createMany({
      data: [
        {
          name: "Vikram Singh",
          photo: IMG.trainer1,
          designation: "Head Strength Coach",
          experienceYears: 9,
          bio: "Vikram specializes in powerlifting and progressive strength programming, having coached over 200 members to their first bodyweight lifts.",
          specializations: JSON.stringify(["Powerlifting", "Strength Training", "Olympic Lifting"]),
          certifications: JSON.stringify(["NSCA-CSCS", "USAW Level 1"]),
          instagram: "https://instagram.com",
          order: 0
        },
        {
          name: "Ananya Kapoor",
          photo: IMG.trainer2,
          designation: "Transformation Coach",
          experienceYears: 6,
          bio: "Ananya focuses on sustainable fat-loss and body recomposition coaching, blending training with practical nutrition habits.",
          specializations: JSON.stringify(["Weight Loss", "Nutrition Coaching", "Body Recomposition"]),
          certifications: JSON.stringify(["ACE-CPT", "Precision Nutrition L1"]),
          instagram: "https://instagram.com",
          order: 1
        },
        {
          name: "Karan Malhotra",
          photo: IMG.trainer3,
          designation: "Functional Training Specialist",
          experienceYears: 7,
          bio: "Karan brings a background in athletic conditioning, helping members build strength that carries over into sport and daily life.",
          specializations: JSON.stringify(["Functional Training", "Mobility", "Athletic Conditioning"]),
          certifications: JSON.stringify(["NASM-CPT", "FRC Mobility Specialist"]),
          instagram: "https://instagram.com",
          order: 2
        },
        {
          name: "Simran Kaur",
          photo: IMG.trainer4,
          designation: "Group Fitness Lead",
          experienceYears: 5,
          bio: "Simran leads our highest-energy group classes, known for keeping every session challenging, scalable and genuinely fun.",
          specializations: JSON.stringify(["Group Classes", "HIIT", "Dance Fitness"]),
          certifications: JSON.stringify(["ACE Group Fitness Instructor"]),
          instagram: "https://instagram.com",
          order: 3
        }
      ]
    });
  }

  // ---------- Facilities ----------
  const facilityCount = await prisma.facility.count();
  if (facilityCount === 0) {
    await prisma.facility.createMany({
      data: [
        { name: "Free Weights Zone", description: "Full range of barbells, dumbbells and plates up to 60kg.", image: IMG.facility1, icon: "🏋️", order: 0 },
        { name: "Cardio Deck", description: "Treadmills, rowers, bikes and stair climbers with entertainment screens.", image: IMG.facility2, icon: "🏃", order: 1 },
        { name: "Functional Zone", description: "Turf lane, sleds, battle ropes and kettlebells for conditioning work.", image: IMG.facility3, icon: "⚡", order: 2 },
        { name: "Locker Rooms", description: "Clean, spacious locker rooms with showers and complimentary towels.", image: IMG.facility4, icon: "🚿", order: 3 }
      ]
    });
  }

  // ---------- Testimonials ----------
  const testimonialCount = await prisma.testimonial.count();
  if (testimonialCount === 0) {
    await prisma.testimonial.createMany({
      data: [
        { name: "Rahul Verma", review: "The coaching here is genuinely different — every session has a plan and the trainers actually watch your form. Down 14kg in 6 months.", rating: 5, order: 0 },
        { name: "Neha Gupta", review: "I've tried three other gyms in the city and none had this level of structure. The strength program completely changed how I train.", rating: 5, order: 1 },
        { name: "Arjun Desai", review: "Great facility, great energy, and the group classes never feel repetitive. Highly recommend Iron District to anyone serious about training.", rating: 4, order: 2 }
      ]
    });
  }

  // ---------- Transformations ----------
  const transformationCount = await prisma.transformation.count();
  if (transformationCount === 0) {
    await prisma.transformation.createMany({
      data: [
        { beforeImage: IMG.transformBefore1, afterImage: IMG.transformAfter1, memberName: "Amit K.", goal: "Weight Loss", duration: "16 weeks", description: "Lost 18kg through consistent strength training and coached nutrition.", order: 0 },
        { beforeImage: IMG.transformBefore1, afterImage: IMG.transformAfter1, memberName: "Sneha R.", goal: "Muscle Gain", duration: "20 weeks", description: "Built visible lean muscle through structured hypertrophy programming.", order: 1 },
        { beforeImage: IMG.transformBefore1, afterImage: IMG.transformAfter1, memberName: "Manoj T.", goal: "Body Transformation", duration: "24 weeks", description: "Complete body recomposition combining strength work and metabolic conditioning.", order: 2 }
      ]
    });
  }

  // ---------- Gallery ----------
  const galleryCount = await prisma.galleryItem.count();
  if (galleryCount === 0) {
    const categories = ["Equipment", "Classes", "Facility", "Events"];
    await prisma.galleryItem.createMany({
      data: IMG.gallery.map((url, i) => ({
        image: url,
        caption: null,
        category: categories[i % categories.length],
        order: i
      }))
    });
  }

  // ---------- FAQs ----------
  const faqCount = await prisma.fAQ.count();
  if (faqCount === 0) {
    await prisma.fAQ.createMany({
      data: [
        { question: "Do I need to be experienced to join?", answer: "Not at all — our coaches work with complete beginners through advanced athletes. Every program is scaled to your current level.", order: 0 },
        { question: "Can I try a session before committing?", answer: "Yes, submit a JOIN NOW enquiry and our team will set up a free trial session for you.", order: 1 },
        { question: "What should I bring on my first visit?", answer: "Comfortable workout clothes, athletic shoes and a water bottle. We provide everything else.", order: 2 },
        { question: "Do you offer nutrition guidance?", answer: "Yes, several of our programs include nutrition coaching as part of the package.", order: 3 },
        { question: "What are your busiest hours?", answer: "Early mornings (6-8 AM) and evenings (6-9 PM) tend to be busiest. Midday hours are usually quieter.", order: 4 }
      ]
    });
  }

  // ---------- Home page + sections ----------
  const homePage = await prisma.page.upsert({
    where: { slug: "home" },
    update: {},
    create: { title: "Home", slug: "home", isSystem: true, seoTitle: "Iron District Fitness — Train Hard. Transform Fully.", seoDescription: "Premium strength, transformation and functional training in Gurugram." }
  });

  const existingSections = await prisma.pageSection.count({ where: { pageId: homePage.id } });
  if (existingSections === 0) {
    const sectionDefs: { type: string; data: any }[] = [
      {
        type: "hero",
        data: {
          heading: "Forge Your Strongest Self",
          subheading: "Premium strength and transformation coaching in the heart of Gurugram. Real coaches, real programming, real results.",
          backgroundImage: IMG.heroBg,
          overlayOpacity: 60,
          align: "left",
          primaryButtonText: "JOIN NOW",
          secondaryButtonText: "Explore Programs",
          secondaryButtonLink: "#programs",
          secondaryButtonVisible: true
        }
      },
      {
        type: "stats",
        data: {
          items: [
            { icon: "🏆", number: "500+", label: "Members Trained" },
            { icon: "💪", number: "9+", label: "Years Running" },
            { icon: "🎯", number: "50+", label: "Transformations" },
            { icon: "⭐", number: "4.9", label: "Average Rating" }
          ]
        }
      },
      {
        type: "about",
        data: {
          heading: "More Than a Gym",
          description:
            "Iron District Fitness was built on one idea: training should be coached, not guessed. Every member gets structured programming, form correction and a team that actually tracks their progress — not just a room full of equipment.\n\nWhether you're chasing your first pull-up or your tenth competition, our coaches meet you exactly where you are.",
          image: IMG.about1,
          secondaryImage: IMG.about2,
          ctaText: "More About Us",
          ctaLink: "/about"
        }
      },
      {
        type: "whyChooseUs",
        data: {
          heading: "Why Train With Us",
          cards: [
            { icon: "🏅", title: "Certified Coaches", description: "Every trainer is certified and hands-on in every session — no wandering the floor alone." },
            { icon: "📈", title: "Tracked Progress", description: "Structured programming with progress check-ins, not guesswork." },
            { icon: "🏢", title: "Premium Facility", description: "Full free-weights zone, functional turf, and a dedicated cardio deck." }
          ]
        }
      },
      { type: "programs", data: { heading: "Our Programs" } },
      { type: "facilities", data: { heading: "World-Class Facilities" } },
      { type: "trainers", data: { heading: "Meet Our Trainers" } },
      { type: "transformations", data: { heading: "Real Transformations" } },
      { type: "testimonials", data: { heading: "What Our Members Say" } },
      { type: "gallery", data: { heading: "Gallery" } },
      { type: "faq", data: { heading: "Frequently Asked Questions" } },
      {
        type: "cta",
        data: {
          heading: "Your Transformation Starts Today",
          description: "Submit an enquiry and our team will reach out within 24 hours to get you started.",
          buttonText: "JOIN NOW",
          backgroundImage: IMG.ctaBg
        }
      },
      { type: "location", data: {} }
    ];

    await prisma.pageSection.createMany({
      data: sectionDefs.map((s, i) => ({
        pageId: homePage.id,
        type: s.type,
        order: i,
        visible: true,
        data: JSON.stringify(s.data)
      }))
    });
  }

  // ---------- Legal pages ----------
  const privacyPage = await prisma.page.upsert({
    where: { slug: "privacy-policy" },
    update: {},
    create: { title: "Privacy Policy", slug: "privacy-policy", isSystem: true, seoTitle: "Privacy Policy — Iron District Fitness" }
  });
  const privacySectionCount = await prisma.pageSection.count({ where: { pageId: privacyPage.id } });
  if (privacySectionCount === 0) {
    await prisma.pageSection.create({
      data: {
        pageId: privacyPage.id,
        type: "richtext",
        order: 0,
        visible: true,
        data: JSON.stringify({
          heading: "Privacy Policy",
          content:
            "Iron District Fitness (\"we\", \"us\") respects your privacy. This page explains what information we collect through this website and how we use it.\n\nWhen you submit an enquiry through our JOIN NOW form, we collect your name, mobile number, email address, gender and fitness goal. This information is used solely to contact you about our programs and membership options.\n\nWe do not sell or share your personal information with third parties for marketing purposes. Your data is stored securely and access is restricted to authorized staff.\n\nYou may request that we delete your information at any time by contacting us using the details on our Contact page.\n\nThis is placeholder policy text — replace it with your own legally reviewed privacy policy from the admin Pages screen before going live."
        })
      }
    });
  }

  const termsPage = await prisma.page.upsert({
    where: { slug: "terms" },
    update: {},
    create: { title: "Terms & Conditions", slug: "terms", isSystem: true, seoTitle: "Terms & Conditions — Iron District Fitness" }
  });
  const termsSectionCount = await prisma.pageSection.count({ where: { pageId: termsPage.id } });
  if (termsSectionCount === 0) {
    await prisma.pageSection.create({
      data: {
        pageId: termsPage.id,
        type: "richtext",
        order: 0,
        visible: true,
        data: JSON.stringify({
          heading: "Terms & Conditions",
          content:
            "By submitting an enquiry or visiting Iron District Fitness, you agree to the following terms.\n\nAll training programs are subject to availability and trainer scheduling. Membership terms, cancellation policies and payment details will be communicated directly by our team after your initial enquiry.\n\nIron District Fitness is not liable for injuries sustained as a result of improper use of equipment outside of coached sessions. Please follow all posted gym safety guidelines.\n\nThis is placeholder terms text — replace it with your own legally reviewed terms from the admin Pages screen before going live."
        })
      }
    });
  }

  // Ensure the other system pages exist as entries too (About/Programs/Trainers/Gallery/Contact
  // are rendered by dedicated routes, not the generic section renderer, but still listed here
  // so they're manageable from the admin Pages screen for SEO purposes).
  const systemPages = [
    { title: "About", slug: "about" },
    { title: "Programs", slug: "programs" },
    { title: "Trainers", slug: "trainers" },
    { title: "Gallery", slug: "gallery" },
    { title: "Contact", slug: "contact" }
  ];
  for (const sp of systemPages) {
    await prisma.page.upsert({ where: { slug: sp.slug }, update: {}, create: { ...sp, isSystem: true } });
  }

  // ---------- Sample leads ----------
  const leadCount = await prisma.lead.count();
  if (leadCount === 0) {
    await prisma.lead.createMany({
      data: [
        { fullName: "Sample Lead — Aditi Rao", mobile: "+919812345670", email: "aditi.demo@example.com", gender: "Female", fitnessGoal: "Weight Loss", status: "NEW" },
        { fullName: "Sample Lead — Rajesh Kumar", mobile: "+919812345671", email: "rajesh.demo@example.com", gender: "Male", fitnessGoal: "Muscle Gain", status: "CONTACTED" },
        { fullName: "Sample Lead — Divya Nair", mobile: "+919812345672", email: "divya.demo@example.com", gender: "Female", fitnessGoal: "General Fitness", status: "CONVERTED" }
      ]
    });
  }

  console.log("Seed complete.");
  console.log("Admin login: admin@irondistrict.example / Admin@12345");
}

main()
  .catch((e) => {
    console.error(e);
    process.exit(1);
  })
  .finally(async () => {
    await prisma.$disconnect();
  });
