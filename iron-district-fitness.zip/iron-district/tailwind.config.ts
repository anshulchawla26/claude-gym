import type { Config } from "tailwindcss";

const config: Config = {
  darkMode: "class",
  content: ["./src/**/*.{js,ts,jsx,tsx,mdx}"],
  theme: {
    extend: {
      colors: {
        primary: "var(--color-primary)",
        secondary: "var(--color-secondary)",
        accent: "var(--color-accent)",
        background: "var(--color-background)",
        surface: "var(--color-surface)",
        "text-base": "var(--color-text)",
        "text-muted": "var(--color-text-muted)",
        "border-base": "var(--color-border)",
        button: "var(--color-button)",
        "button-hover": "var(--color-button-hover)"
      },
      fontFamily: {
        heading: "var(--font-heading)",
        body: "var(--font-body)"
      },
      borderRadius: {
        base: "var(--radius-base)",
        button: "var(--radius-button)",
        card: "var(--radius-card)"
      },
      maxWidth: {
        container: "var(--container-width)"
      },
      letterSpacing: {
        tight2: "var(--letter-spacing)"
      }
    }
  },
  plugins: []
};

export default config;
