# Iron District Fitness — Gym Website + Custom Admin CMS

A full-stack gym website with a completely custom-built admin panel/CMS. No Sanity, no Contentful, no Strapi, no WordPress — every piece of content, styling, and layout on the public site is stored in your own database and edited through your own admin panel.

**Stack:** Next.js 14 (App Router) · TypeScript · Tailwind CSS · Prisma · NextAuth · SQLite (dev) / Postgres (production)

---

## 1. Quick Start (local demo)

```bash
npm install
cp .env.example .env
# Generate a real secret and paste it into .env as NEXTAUTH_SECRET:
openssl rand -base64 32

npm run setup      # creates the SQLite database + seeds demo data
npm run dev
```

Open:
- **Public site:** http://localhost:3000
- **Admin panel:** http://localhost:3000/admin

**Demo login:**
| Email | Password | Role |
|---|---|---|
| `admin@irondistrict.example` | `Admin@12345` | SUPER_ADMIN |
| `manager@irondistrict.example` | `Admin@12345` | GYM_ADMIN |
| `staff@irondistrict.example` | `Admin@12345` | STAFF |

The site loads immediately with realistic sample content for a fictional gym, **Iron District Fitness** — replace every piece of it from the admin panel.

---

## 2. What you can do without touching code

Everything in the "50 requirements" brief is wired up end-to-end:

- **Website Builder** (`/admin/builder`) — reorder, hide/show, edit, duplicate or delete every homepage section (Hero, Stats, About, Why Choose Us, Programs, Facilities, Trainers, Transformations, Testimonials, Gallery, FAQ, CTA, Location).
- **Theme / Design** (`/admin/theme`) — colors, fonts, border radius, spacing, container width. Changes apply site-wide immediately.
- **Programs / Trainers / Facilities / Testimonials / Transformations / Gallery / FAQs** — full CRUD with image upload, visibility toggle, and reordering.
- **Pages** (`/admin/pages`) — edit Privacy Policy / Terms content, or add brand-new pages (they're automatically served at `/your-slug`).
- **Navigation** (`/admin/navigation`) — add/remove/reorder header & footer links.
- **Media Library** (`/admin/media`) — upload, browse, and reuse images across every content screen.
- **SEO** (`/admin/seo`) — per-page meta title/description/OG image/canonical/robots.
- **Global Settings** (`/admin/settings`) — gym name, logo, favicon, phone, email, WhatsApp, address, map, socials, opening hours.
- **Notifications** (`/admin/notifications`) — WhatsApp + Email toggles, destination number/email, editable templates, and a **Test** button that performs a real send attempt (never fakes success).
- **Popup** and **Announcement Bar** — fully configurable, including frequency and delay.
- **Leads** (`/admin/leads`) — search, filter, status pipeline, notes, CSV export, one-click Call/WhatsApp/Email.
- **Users** (`/admin/users`, Super Admin only) — create staff/admin accounts with role-based permissions enforced server-side.
- **Activity Log** (`/admin/audit-log`) — who changed what, when.

---

## 3. Architecture notes

- **Multiple root layouts:** the public site (`src/app/(site)`) and the admin panel (`src/app/admin`) are separate Next.js route groups, each with its own `<html>`/`<body>` — so the admin's dark SaaS UI never leaks into (or gets leaked into by) the public site's theme.
- **Everything editable = database-driven:** the Prisma schema (`prisma/schema.prisma`) has a model for every content type. The homepage itself is built from a `Page` → `PageSection[]` structure, where each section has a `type`, `order`, `visible` flag, and a JSON `data` blob — that's what the Website Builder edits.
- **Auth:** NextAuth credentials provider, bcrypt-hashed passwords, JWT sessions. Route protection happens **twice**: once in `src/middleware.ts` and again server-side in `src/app/admin/(protected)/layout.tsx` — client-side role checks are never trusted alone; every admin API route re-verifies the session and role server-side (`src/lib/auth.ts` → `roleCan()`).
- **WhatsApp notifications are real, not simulated.** `src/lib/notifications/whatsapp.ts` calls the actual Meta WhatsApp Cloud API. If `WHATSAPP_API_TOKEN` / `WHATSAPP_PHONE_NUMBER_ID` aren't set, every send attempt returns `{ sent: false, reason: "not_configured" }` and the admin UI says so plainly — it never pretends a message went out.
- **Email notifications** use standard SMTP via `nodemailer` — works with Gmail app passwords, Resend, Postmark, SES SMTP, etc.
- **Anti-spam:** honeypot field + in-memory rate limiting (`src/lib/rateLimit.ts`) + duplicate-submission guard (same mobile+email within 2 minutes is silently deduped) on the lead form.
- **Reusable for other gym clients:** every brand-specific value (name, logo, colors, contact info, content) lives in the database, not in code — spin up a new client by pointing at a fresh database and re-seeding with their content.

---

## 4. Environment variables

See `.env.example` for the full list with comments. Minimum to run locally:

```
DATABASE_URL="file:./dev.db"
NEXTAUTH_SECRET="<generate with: openssl rand -base64 32>"
NEXTAUTH_URL="http://localhost:3000"
```

Optional (enable real notification delivery):
```
WHATSAPP_PROVIDER="meta"
WHATSAPP_API_TOKEN="..."
WHATSAPP_PHONE_NUMBER_ID="..."

SMTP_HOST="..."
SMTP_PORT="587"
SMTP_USER="..."
SMTP_PASSWORD="..."
SMTP_FROM="Iron District Fitness <no-reply@yourdomain.com>"
```

A normal personal WhatsApp number **cannot** receive arbitrary API messages — real delivery requires WhatsApp Business Platform access (Meta Cloud API, used here) or a BSP like Twilio/360dialog/Gupshup. The notification service is abstracted (`src/lib/notifications/`) so swapping providers later doesn't touch the lead-creation code path.

---

## 5. Deploying to production (Vercel example)

1. **Switch the database.** SQLite is great for local demo but Vercel's filesystem is ephemeral/read-only at runtime. Provision a hosted Postgres (Vercel Postgres, Neon, Supabase — any works), then in `prisma/schema.prisma` change:
   ```prisma
   datasource db {
     provider = "postgresql"
     url      = env("DATABASE_URL")
   }
   ```
2. Set `DATABASE_URL`, `NEXTAUTH_SECRET`, `NEXTAUTH_URL` (your production URL) and any notification env vars in the Vercel project settings.
3. Push the schema and seed once against production: `npx prisma db push && npx tsx prisma/seed.ts` (run locally with the production `DATABASE_URL`, or via a one-off script).
4. Deploy. `postinstall` already runs `prisma generate` automatically.

**Media uploads on serverless:** the built-in Media Library (`src/app/api/admin/media/route.ts`) writes to `public/uploads` on disk, which works great for local/VM hosting but **not** on Vercel's serverless functions (read-only, ephemeral filesystem). For production on Vercel, swap the upload handler to a blob store — Vercel Blob is the natural fit and requires only a few lines of change in that one file; the rest of the app (Media model, ImageUploadField component, every content screen) is unaffected because they only ever deal with a `url` string.

---

## 6. Known simplifications (by design, given scope)

These are reasonable, clearly-marked simplifications rather than missing functionality — each is straightforward to extend:

- **Icons are emoji text fields**, not an icon-library picker. Keeps every content type free of an extra dependency; swap for `lucide-react` + a picker if desired.
- **Rich text (Privacy Policy, Terms, custom pages)** is plain paragraphs (blank-line-separated), not a full WYSIWYG editor. Good enough for legal boilerplate; add TipTap/Lexical if you need bold/links/lists.
- **Section/list reordering** uses up/down buttons rather than pointer-based drag-and-drop — same end result, less client-side complexity and dependency weight.
- **Rate limiting is in-memory**, fine for a single instance; swap for Upstash Redis if you deploy multiple serverless instances.
- **Image "optimization on upload"** relies on Next's built-in `<Image>` on-the-fly optimization at render time rather than a separate resize-on-upload pipeline (e.g. `sharp`) — simpler ops, same end-user experience.

Everything else in the original brief — full CRUD, draft/visibility per item, dynamic homepage assembly, real notification architecture, RBAC enforced server-side, audit logging, CSV export, SEO, responsive everywhere — is implemented and working, not mocked.
